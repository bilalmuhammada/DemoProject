<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Zone extends Model
{
    use HasFactory;
    protected $fillable = [
        'zone_code',
        'zone_name',
        'is_active'
    ];


    public function terrories()
    {
        return $this->hasMany(Territory::class, 'zone_code');
    }

}

<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Product;
use App\CustomerGroup;
class Price_structure extends Model
{
    use HasFactory;

    protected $fillable =[

        "group_id", "product_id", "is_active", "distributor_margin", "retailer_margin", "factory_price", "offer_value", "buy", "get_free","is_regular"
    ];

    public function Product()
    {
        return $this->belongsTo(Product::class,'product_id');
    }

  

    public function CustomerGroup()
    {
        return $this->belongsTo(CustomerGroup::class,'group_id');
    }
}

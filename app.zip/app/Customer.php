<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use App\order_detail;
use App\Online_cash;
use App\Product_Sale;
use App\add_claim;
class Customer extends Model
{
    protected $fillable =[
        
        "customer_group_id", "user_id", "name", "distribution_name","company_name","reqular_account","bulk_account","start_date",
        "email", "phone_number", "cont_person", "address", "city","cust_num",
        "ntn", "postal_code","opening_bal","warehouse_id","supervised_cust","distributor_type", "cnic", "points", "deposit", "expense","registor", "is_active","territory","zone"
    ];

    public function user()
    {
    	return $this->belongsTo('App\User');
    }
    public function CustomerGroup()
    {
    	return $this->belongsTo('App\CustomerGroup');
    }
    
    public function orderdetail()
    {
        return $this->hasMany(order_detail::class,'cust_id','id');
    }
    public function productSale()
    {
        return $this->hasMany(Product_Sale::class,'dist_id','id');
    }

    public function town()
    {
        return $this->hasMany('App\Town'::class,'id');
    }
    public function addcliam()
    {
        return $this->hasMany(add_cliam::class,'distid','id');
    }

    public function onlinecash()
    {
        return $this->hasMany(Online_cash::class,'distid','id');
    }
}

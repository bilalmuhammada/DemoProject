<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class add_stock extends Model
{
    use HasFactory;

    
    public function product()
    {
        return $this->belongsTo(Product::class,'prod_id');
    }

    
    



}

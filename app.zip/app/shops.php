<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class shops extends Model
{
    protected $fillable =[
        "name", "sectors","dist_id","shop_code", "address",'orderbooker_id','phone_number', "is_active"
    ];
    use HasFactory;

    public function local_distr_orderdetail()
    {
        return $this->hasMany(local_distr_orderdetail::class,'shop_id','id');
    }
    public function local_distr_return_orderdetail()
    {
        return $this->hasMany(local_distr_return_orderdetail::class,'shop_id','id');
    }
}

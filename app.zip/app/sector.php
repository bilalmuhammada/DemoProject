<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class sector extends Model
{

    protected $fillable =[
        "name", "code", "town","dist_id", "is_active"
    ];
    use HasFactory;


    public function towns()
    {
        return $this->belongsTo(Town::class,'town');
    }
}

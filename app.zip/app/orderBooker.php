<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class orderBooker extends Model
{
    use HasFactory;



    protected $fillable = ["name","phone_number", "designation", "emp_code", "sectors","area","dist_id", "is_active"];
}

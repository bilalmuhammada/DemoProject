<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Price_structure;
use App\Customer;
class CustomerGroup extends Model
{
    protected $fillable =[

        "name", "percentage", "is_active"
    ];


    public function customer()
    {
        return $this->hasMany(Customer::class,'customer_group_id','id');
    }
    public function Price_structure()
    {
        return $this->hasMany(Price_structure::class,'group_id','id');
    }
}

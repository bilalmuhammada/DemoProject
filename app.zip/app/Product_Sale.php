<?php

namespace App;
use App\order_detail;
use App\Product;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product_Sale extends Model
{
    use HasFactory;

	protected $table = 'product_sales';
    protected $fillable =[
        "sale_id", "user_id", "product_batch_id", "variant_id", 'imei_number', "qty", "sale_unit_id", "net_unit_price", "discount", "tax_rate", "tax", "total"
    ];


    public function orderdetail()
    {
        return $this->hasMany(order_detail::class,'prod_sale_id');
    }

    
    public function customer()
    {
        return $this->hasOne(Customer::class, 'id','dist_id');
    }
    
    

    // public function product()
    // {
    //     return $this->belongsTo(Product::class,'product_id');
    // }

}

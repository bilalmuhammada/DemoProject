<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\CliamHead;
class add_cliam extends Model
{
    use HasFactory;

    public function Customer()
    {
    	return $this->belongsTo('App\Customer','distid');
    }
   
    public function cliamtype()
    {
    	return $this->hasMany(CliamHead::class,'id','claimtype');
    }
}

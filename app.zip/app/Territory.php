<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Territory extends Model
{
        use HasFactory;
        protected $table = 'territories';
        protected $fillable = [
            'zone_code',
            'territory_code',
            'territory_name',
            'is_active'
        ];

        public function towns()
        {
            return $this->hasMany(Town::class, 'territory_name');
            
        }
 

        public function zone()
        {
            return $this->belongsTo(Zone::class, 'zone_code', 'zone_code');
        }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CategoryDiscount extends Model
{
    protected $table = 'categorydiscounts';
    use HasFactory;
    protected $fillable = ['customer_id','category_id','percentage'];
}

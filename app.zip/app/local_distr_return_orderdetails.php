<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class local_distr_return_orderdetails extends Model
{
    use HasFactory;
    public function Product()
    {
        return $this->belongsTo(Product::class, 'prod_id', 'id');
    }

    public function shop()
    {
        return $this->belongsTo(shops::class, 'shop_id','id');
    }
      
    public function local_distr_product_sales()
    {
        return $this->belongsTo(local_distr_product_sales::class,'prod_sale_id','id');
    }
}

<?php

namespace App;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Town extends Model
{
    use HasFactory;
    protected $fillable = [
        'territory_name',
        'town_code',
        'town_name',
        'is_active'
    ];

    
    public function customers()
    {
    	return $this->hasMany(Customer::class,'city');
    }

    public function sectors()
    {
    	return $this->hasMany(sector::class,'town');
    }


    public function territory()
    {
        return $this->belongsTo(Territory::class,'territory_name', 'territory_name');
    }
    public function zone()
    {
        return $this->belongsTo(Zone::class,'territory_code', 'territory_code');
    }

      
}

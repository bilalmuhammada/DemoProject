<?php
namespace App\Classes;

use P4lv\ExcelGoalSeek\ExcelGoalSeek;

class GoalSeek extends ExcelGoalSeek {

    function callbackTest($input) {
        $inputForCallbackTest2 = $input * 8;
        return $this->callbackTest2($inputForCallbackTest2);
    }

    function callbackTest2($input) {
        $solution = $input +3;
        return $solution;
    }
}

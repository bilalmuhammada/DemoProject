<?php
namespace App\Classes;
class GSeek
{
    public $A6;
    public $A2;
    public $A5;
    public $A3;
    public $A4;
    public $goal_found;
    public $goal_target;
    public $GST = 17;
    public $Distributor_Margin_Percentage=11;
    public $Retailer_Margin_Percentage=10.5;
    public $is_Sale_TAX_On_Retail_Price=false;
    public $buy=0;
    public $get_free=0;

    public function __construct($target=0, $gst=17, $Dist_Margin=11, $Retailer_Margin=10.5, $TAX_On_RP=false)
    {
        $this->goal_target=$target;
        $this->GST=$gst;
        $this->Distributor_Margin_Percentage=$Dist_Margin;
        $this->Retailer_Margin_Percentage=$Retailer_Margin;
        $this->is_Sale_TAX_On_Retail_Price=$TAX_On_RP;

    }
    public function calculate($target='')
    {
        try
        {
            if(empty($target))
            {
                $target=$this->goal_target;
            }

          

            // Retail Price
           $this->A1= $target;

            // Factory Price
            $this->A2 = 0;


            $this->setGST_A3($this->GST);
            $this->setDM_A4($this->Distributor_Margin_Percentage);
            $this->setRM_A5($this->Retailer_Margin_Percentage);

            $this->A6 = $this->sumA6();

            $delta = 0.1;
            $previousDistance = 0.0;
            $val = $target; // 70.0
            $currentdistance;
            $Counter = 1;
            $Diffr = array();
            $Vals = array();
            $Factor = array();

            while (abs($this->A6 - $val) > 0.001)
            {
               
                $this->A2 = $this->A2 + $delta;
                
                $this->updateAll();
                $this->updateAll();
                $this->array_insert($Diffr,$Counter-1,abs($this->A6- $val));
                $this->array_insert($Vals,$Counter-1,$this->A6);
                $this->array_insert($Factor,$Counter-1,$this->A2);
           
                $currentdistance = abs($this->A6 - $val);
                //dd($Diffr);

                $delta = $currentdistance * $delta / ($previousDistance - $currentdistance);

                $previousDistance = $currentdistance;

                $Counter += 1;

                if ($Counter > 20)
                {
                    $ind = array_search(min($Diffr),$Diffr);
                    $nearestVal = $Vals[$ind];
                    $FactPrice = $Factor[$ind];
                    //dd($Factor);
                   
                    $this->goal_found=$FactPrice;
                    return $FactPrice;
                }
              
            }

            $ind = array_search(min($Diffr),$Diffr);
            $nearestVal = $Vals[$ind];
            $FactPrice = $Factor[$ind];
        
            $this->goal_found=$FactPrice;
         
            return $FactPrice;

        }catch (Exception $ex)
        {
            $s='';
        }

    }

    public function setGST_A3($taxVal)
    {
        if($this->is_Sale_TAX_On_Retail_Price===false)
        {
           // dd( $this->A3);
            $this->A3=round((($this->A1* $taxVal) /($taxVal + 100)),2);
        } else{

            $this->A3=round((($this->A2* $taxVal) /($taxVal + 100)),2);
        }

        $cal_GST = $this->A3;
    }

    public function setDM_A4($taxVal)
    {
        $this->A4=round((($this->A2 + $this->A3)*($taxVal/100)),2);

        $cal_DM=$this->A4;
    }

    public function setRM_A5($taxVal)
    {
        
        $this->A5=round((($this->A2 + $this->A3 + $this->A4)* ($taxVal/100)),2);

    //    $cal_RM=$this->A5;
    }

    public function sumA6()

    {
        
        $this->A6=(($this->A2 + $this->A3 + $this->A4 + $this->A5));
    //   $cal_sum = $this->A6;
    }

    public function updateAll()
    {

        //GST
        if($this->is_Sale_TAX_On_Retail_Price===false)
        {
            
            $this->A3=round((($this->GST/100) * ($this->A2)),2);
        } else{
          //dd($this->GST);
        //  $this->A3=round((($this->GST*$this->A1/117)),2);
          
            $this->A3=round((($this->GST/($this->GST+100)) * ($this->A1)),2);
        }

        //Update Factory Price immediatly
        $this->sumA6();


        //Distributor Margin
        $this->A4=round((($this->A2 + $this->A3)*($this->Distributor_Margin_Percentage/100)),2);
        
        //Update Factory Price immediatly
        $this->sumA6();

        //Retailer Margin
        $this->A5=round((($this->A2 + $this->A3 + $this->A4)* ($this->Retailer_Margin_Percentage/100)),2);
       
       //Update Factory Price immediatly
        $this->sumA6();
     //   dd( $this->sumA6());
    }


    public function updateAll_bak()
    {

        //GST
        if($this->is_Sale_TAX_On_Retail_Price===false)
        {
            $this->A3=round((($this->GST/100) * ($this->A2)),2);
        } else{

            $this->A3=round((($this->GST/($this->GST+100)) * ($this->A2)),2);
        }

        //Distributor Margin
        $this->A4=round((($this->A2 + $this->A3)*($this->Distributor_Margin_Percentage/100)),2);
        
        //Retailer Margin
        $this->A5=round((($this->A2 + $this->A3 + $this->A4)* ($this->Retailer_Margin_Percentage/100)),2);
       
       //Result
        $this->A6=(($this->A2 + $this->A3 + $this->A4 + $this->A5));
    }

    function array_insert(&$array, $position, $insert)
    {
        if (is_int($position)) {
            array_splice($array, $position, 0, $insert);
        } else {
            $pos   = array_search($position, array_keys($array));
            $array = array_merge(
                array_slice($array, 0, $pos),
                $insert,
                array_slice($array, $pos)
            );
        }
    }



    public function calc_trade_offer()
    {
       
        
        $rtnValue = 0.0;

        if (empty($this->goal_target) || empty($this->buy) || empty($this->get_free) || empty($this->GST) || empty($this->Distributor_Margin_Percentage)  || empty($this->Retailer_Margin_Percentage))
        {
            return false;
        }
           
        try
        {
            $factoryPrice = $this->calculate();

            $gst = 0;

             //GST
        
            $result_gst = ($this->is_Sale_TAX_On_Retail_Price===true) ? ($this->goal_target * ($this->GST / ($this->GST + 100))) : ($factoryPrice * ($this->GST / 100));
            $result_dist_margin = ($factoryPrice + $result_gst) * ($this->Distributor_Margin_Percentage / 100);
            $result_retailer_margin = ($factoryPrice + $result_gst + $result_dist_margin) * ($this->Retailer_Margin_Percentage / 100);
          
            $TradePriceIncGST = $result_gst + $result_dist_margin  + $factoryPrice;
            $ToCalculated = ($TradePriceIncGST * doubleval($this->buy)) / (doubleval($this->buy) + doubleval($this->get_free));

            $ToCalculated = $TradePriceIncGST - $ToCalculated;

            $FractionalPart = $ToCalculated - floor($ToCalculated);

            $ValABS =$FractionalPart;

          

            // if(($ValABS>=0.0) && ($ValABS <= 0.12))
            // {
            //     $FractionalPart = 0;
            // }

             if(($ValABS>=0.0) && ($ValABS <= 0.24))
            {
                $FractionalPart = 0;
            }
            if(($ValABS>=0.25) && ($ValABS <= 0.49))
            {
                $FractionalPart = 0.25;
            }

            // if(($ValABS>=0.13) && ($ValABS <= 0.38))
            // {
            //     $FractionalPart = 0.25;
            // }

            // if(($ValABS>=0.39) && ($ValABS <= 0.62))
            // {
            //     $FractionalPart = 0.5;
            // }

              if(($ValABS>=0.50) && ($ValABS <= 0.74))
            {
                $FractionalPart = 0.5;
            }

if(($ValABS>=0.75) && ($ValABS <= 0.99))
            {
                $FractionalPart = 0.75;
            }

            // if(($ValABS>=0.63) && ($ValABS <= 0.87))
            // {
            //     $FractionalPart = 0.75;
            // }

            // if(($ValABS>0.99))
            // {
            //     $FractionalPart = 0.0;
            //     $ToCalculated = abs($ToCalculated) + 1;

            // }



            
            $ToCalculated = floor($ToCalculated) + $FractionalPart;
            

            return  $ToCalculated;

        }
        catch (Exception $ex)
        {
            return 0.0;
        }

        return rtnValue;
    }



} 
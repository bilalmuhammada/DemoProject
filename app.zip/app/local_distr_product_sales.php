<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class local_distr_product_sales extends Model
{
    use HasFactory;
    public function local_distr_orderdetail()
    {
        return $this->hasMany(local_distr_orderdetail::class,'prod_sale_id');
    }

    public function customer()
    {
        return $this->hasOne(Customer::class, 'id','dist_id');
    }
    public function shops()
    {
        return $this->hasOne(shops::class, 'id','shop_id');
    }

}

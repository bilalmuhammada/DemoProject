<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\add_cliam;
class CliamHead extends Model
{
    use HasFactory;

    public function addcliam()
    {
    	return $this->belongsTo(add_cliam::class,'claimtype','id');
    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StockReturn extends Model
{
    use HasFactory;

    protected $fillable =[
        "return_type", "dist_id", "qty", "price", "date", "product_id", "remarks","is_active"
    ];
}

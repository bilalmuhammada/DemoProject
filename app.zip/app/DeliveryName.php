<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeliveryName extends Model
{
    protected $fillable =[
        "name", "code", "sector","dist_id","address", "phone_number", "town", "is_active"
    ];
    use HasFactory;
}

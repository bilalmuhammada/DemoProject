<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Product_Sale;
use App\Product;
class order_detail extends Model
{
    use HasFactory;

    public $timestamps = true;

    public function productsale()
    {
        return $this->belongsTo(Product_Sale::class,'prod_sale_id','id');
    }


      
     
        public function Product()
        {
            return $this->belongsTo(Product::class, 'prod_id', 'id');
        }
        
        public function customer()
        {
            return $this->belongsTo(Customer::class, 'cust_id','id');
        }
    
}

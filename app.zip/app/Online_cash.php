<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Online_cash extends Model
{
    use HasFactory;
    public function Customer()
    {
    	return $this->belongsTo('App\Customer','distid');
    }
    public function accounthead()
    {
    	return $this->belongsTo('App\Account_head','acchead');
    }
  
}

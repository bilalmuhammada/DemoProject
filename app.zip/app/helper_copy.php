<?php
use Illuminate\Support\Facades\DB;
use App\Zone;
use App\Territory;
use  Illuminate\Support\Facades\File;
use App\Town;

use APP\Unit;

use APP\order_detail;



 





function insert_token($refreshTok,$token){

 

   DB::table('tokens')->delete();

    DB::table('tokens')->insert(['refreshtoken'=>$refreshTok,'token'=> $token]);

}



// function valDash($val="")

// {

//     return (empty($val) || $val == 0) ? '--' : $val;

// }


function downloadfile()
    {
      $zip = new ZipArchive;
   
      $relativeNameInZipFile='';
      $fileName = 'invices.zip';
 
      if ($zip->open(public_path($fileName), ZipArchive::CREATE) === TRUE)
      {
          $files = File::files(public_path('invoice_data'));
 
          foreach ($files as $key => $value) {
              $relativeNameInZipFile = basename($value);
              $zip->addFile($value, $relativeNameInZipFile);
              return response()->download(public_path('invoice_data/'.$relativeNameInZipFile));
            }
          
          $zip->close();
      }
  
   
      // return Response::download($path); 
    }
   

function generate_serial_num($type)
{
    
    try{

    
        $counter_val = 0;
        $counter_pf = '';
        $month = date('m');
        $year = date('y');
        $separator = "-";

       
        //validate counter
        counter_resetter($type, $year,$month);


        $tbl_counter = DB::table('tbl_counter')->select('counter_value','counter_prefix','counter_year')->where('counter_name','=',$type)->first();

        if(isset($tbl_counter))
        {
            $counter_val= $tbl_counter->counter_value;
            $counter_pf= $tbl_counter->counter_prefix;
            $counter_year = $tbl_counter->counter_year;
            
            if(is_numeric($counter_val))
            {
                $counter_val = sprintf('%05d', $counter_val+1);

                return $counter_pf . '-' . $month . '-' . $year . '-' . $counter_val; 
                
            }else{
                return 0;
            }

        }else{
            return 0;
        }
    } catch(Exception $e){
            $a='';
    }

}


function counter_resetter($type,$year,$month)
{
   
   try{
   




        $circular_month=7;
        $tbl_counter = DB::table('tbl_counter')->select('counter_year','counter_month')->where('counter_name','=',$type)->first();
      //  dd( $tbl_counter);
        if(isset($tbl_counter))
        {
            
             
            $counter_year = $tbl_counter->counter_year;
            $counter_month = $tbl_counter->counter_month;
            if(($counter_month==null) || ($counter_month!=$month))
            {
                $tbl_counter = DB::update(DB::raw("UPDATE tbl_counter SET counter_month=" . $month . ",counter_year=" . $year . " WHERE counter_name ='" . $type . "'"));
                return true;
            }


            if(($counter_month==null) ||  ($circular_month==$counter_month))
            {
                $tbl_counter = DB::update(DB::raw("UPDATE tbl_counter SET counter_value = 0, counter_year=" . $year . " WHERE counter_name ='" . $type . "'"));
                return true;
            }

        }else{
            return false;
        }

    } catch (Exception $e) {
        return false;
    }

}


function increament_serial_num($type)
{
    $month = date('m');
   
    $tbl_counter = DB::update(DB::raw("UPDATE tbl_counter SET counter_value = counter_value + 1 , counter_month = ".$month."  WHERE counter_name ='" . $type . "'"));

    if(isset($tbl_counter))
    {
        return true;
    }else{
        return false;
    }

}

function editdata($id){





   

    $product=[];

    

    $lims_product_sale_data = order_detail::where('prod_sale_id', $id)->with('productsale')->get();

    //dd($lims_product_sale_data); 

    foreach($lims_product_sale_data as $value){

    $product[]= $value->prod_sale_id;

    $product[]= $value->prod_id;

    $product[]= $value->cust_id;

    $product[]= $value->prod_name;

    $product[]= $value->prod_code;

    $product[]= $value->ctunit;

    $product[]= $value->qty;

    $product[]= $value->qty_in_unit;

    $product[]= $value->price;

    $product[]= $value->vexc_tax;

    

    $product[]= $value->sale_tax;

    $product[]= $value->vinc_tax;

    $product[]= $value->fact_price;

    $product[]= $value->valueoffer;



    $product[]= $value->tval_tradeoff;

    $product[]= $value->tradeoffer;

    $product[]= $value->amount;

    $product[]= $value->vex_tradoff;

    $product[]= $value->subtotal;

  

}

            //    $inv=$lims_product_sale_data[0]->productsale->invoice;

            //    $total=$lims_product_sale_data[0]->productsale->total;

            //    $qty=$lims_product_sale_data[0]->productsale->qty;

            // //    foreach($lims_product_sale_data as $value)

            //    {

                   

            //        //array_push($months, "'" . get_month_name($value->month) . "'");

            //        array_push($product, $value->booking==null? 0 : $value->booking);

           

            //    }



           



             return  $returnArray=[

                "product" => $product

                

            ];

 }





function get_token_by_id($id=''){



    if(empty($id))

    {

        $id=auth()->user()->email;

    }



    $token = DB::table('tokens')->select('refreshtoken')->get();



    if(isset($token) && (count($token)>0))

    {

        return $token[0]->refreshtoken;

    }else{

        return '';

    }

    

}





function get_designation_color($designation_name)

{

    switch (strtolower($designation_name)) {

        case "nsm":

            return '#32CD32';

            break;

        case "zsm":

            return '#20B2AA';

            break;

        case "asm":

            return '#FFD700';

            break;

            break;

        case "tm":

            return '#F4A460';

            break;

            break;

        case "som":

            return '#D2691E';

            break;

            break;

        case "sc":

            return '#BC8F8F';

            break;

            break;

        case "tse":

            return '#00BFFF';

            break;

        case "mdo":

            return '#FF8C00';

            break;

        case "ss":

            return '#DC143C';

            break;

        case "se":

            return '#48D1CC';

            break;

        default:

            return '#32CD32';

    }

}





function get_category_color($designation_name)

{

    switch (strtolower($designation_name)) {

        case "nsm":

            return '#32CD32';

            break;

        case "zsm":

            return '#20B2AA';

            break;

        case "asm":

            return '#FFD700';

            break;

            break;

        case "tm":

            return '#F4A460';

            break;

            break;

        case "som":

            return '#D2691E';

            break;

            break;

        case "sc":

            return '#BC8F8F';

            break;

            break;

        case "tse":

            return '#00BFFF';

            break;

        case "mdo":

            return '#FF8C00';

            break;

        case "ss":

            return '#DC143C';

            break;

        case "se":

            return '#48D1CC';

            break;

        default:

            return '#32CD32';

    }

}



function get_colors_array()

{



    return array('nsm' => '32CD32', 'zsm' => '20B2AA', 'asm' => 'FFD700', 'tm' => 'F4A460', 'som' => 'D2691E', 'sc' => 'BC8F8F', 'tse' => '00BFFF', 'mdo' => 'FF8C00', 'ss' => 'DC143C', 'se' => '48D1CC', 'aliceblue' => 'f0f8ff', 'antiquewhite' => 'faebd7', 'aqua' => '00ffff', 'aquamarine' => '7fffd4', 'azure' => 'f0ffff', 'beige' => 'f5f5dc', 'bisque' => 'ffe4c4', 'black' => '000000', 'blanchedalmond' => 'ffebcd', 'blue' => '0000ff', 'blueviolet' => '8a2be2', 'brown' => 'a52a2a', 'burlywood' => 'deb887', 'cadetblue' => '5f9ea0', 'chartreuse' => '7fff00', 'chocolate' => 'd2691e', 'coral' => 'ff7f50', 'cornflowerblue' => '6495ed', 'cornsilk' => 'fff8dc', 'crimson' => 'dc143c', 'cyan' => '00ffff', 'darkblue' => '00008b', 'darkcyan' => '008b8b', 'darkgoldenrod' => 'b8860b', 'dkgray' => 'a9a9a9', 'darkgray' => 'a9a9a9', 'darkgrey' => 'a9a9a9', 'darkgreen' => '006400', 'darkkhaki' => 'bdb76b', 'darkmagenta' => '8b008b', 'darkolivegreen' => '556b2f', 'darkorange' => 'ff8c00', 'darkorchid' => '9932cc', 'darkred' => '8b0000', 'darksalmon' => 'e9967a', 'darkseagreen' => '8fbc8f', 'darkslateblue' => '483d8b', 'darkslategray' => '2f4f4f', 'darkslategrey' => '2f4f4f', 'darkturquoise' => '00ced1', 'darkviolet' => '9400d3', 'deeppink' => 'ff1493', 'deepskyblue' => '00bfff', 'dimgray' => '696969', 'dimgrey' => '696969', 'dodgerblue' => '1e90ff', 'firebrick' => 'b22222', 'floralwhite' => 'fffaf0', 'forestgreen' => '228b22', 'fuchsia' => 'ff00ff', 'gainsboro' => 'dcdcdc', 'ghostwhite' => 'f8f8ff', 'gold' => 'ffd700', 'goldenrod' => 'daa520', 'gray' => '808080', 'grey' => '808080', 'green' => '008000', 'greenyellow' => 'adff2f', 'honeydew' => 'f0fff0', 'hotpink' => 'ff69b4', 'indianred' => 'cd5c5c', 'indigo' => '4b0082', 'ivory' => 'fffff0', 'khaki' => 'f0e68c', 'lavender' => 'e6e6fa', 'lavenderblush' => 'fff0f5', 'lawngreen' => '7cfc00', 'lemonchiffon' => 'fffacd', 'lightblue' => 'add8e6', 'lightcoral' => 'f08080', 'lightcyan' => 'e0ffff', 'lightgoldenrodyellow' => 'fafad2', 'ltgray' => 'd3d3d3', 'lightgray' => 'd3d3d3', 'lightgrey' => 'd3d3d3', 'lightgreen' => '90ee90', 'lightpink' => 'ffb6c1', 'lightsalmon' => 'ffa07a', 'lightseagreen' => '20b2aa', 'lightskyblue' => '87cefa', 'lightslategray' => '778899', 'lightslategrey' => '778899', 'lightsteelblue' => 'b0c4de', 'lightyellow' => 'ffffe0', 'lime' => '00ff00', 'limegreen' => '32cd32', 'linen' => 'faf0e6', 'magenta' => 'ff00ff', 'maroon' => '800000', 'mediumaquamarine' => '66cdaa', 'mediumblue' => '0000cd', 'mediumorchid' => 'ba55d3', 'mediumpurple' => '9370d8', 'mediumseagreen' => '3cb371', 'mediumslateblue' => '7b68ee', 'mediumspringgreen' => '00fa9a', 'mediumturquoise' => '48d1cc', 'mediumvioletred' => 'c71585', 'midnightblue' => '191970', 'mintcream' => 'f5fffa', 'mistyrose' => 'ffe4e1', 'moccasin' => 'ffe4b5', 'navajowhite' => 'ffdead', 'navy' => '000080', 'oldlace' => 'fdf5e6', 'olive' => '808000', 'olivedrab' => '6b8e23', 'orange' => 'ffa500', 'orangered' => 'ff4500', 'orchid' => 'da70d6', 'palegoldenrod' => 'eee8aa', 'palegreen' => '98fb98', 'paleturquoise' => 'afeeee', 'palevioletred' => 'd87093', 'papayawhip' => 'ffefd5', 'peachpuff' => 'ffdab9', 'peru' => 'cd853f', 'pink' => 'ffc0cb', 'plum' => 'dda0dd', 'powderblue' => 'b0e0e6', 'purple' => '800080', 'red' => 'ff0000', 'rosybrown' => 'bc8f8f', 'royalblue' => '4169e1', 'saddlebrown' => '8b4513', 'salmon' => 'fa8072', 'sandybrown' => 'f4a460', 'seagreen' => '2e8b57', 'seashell' => 'fff5ee', 'sienna' => 'a0522d', 'silver' => 'c0c0c0', 'skyblue' => '87ceeb', 'slateblue' => '6a5acd', 'slategray' => '708090', 'slategrey' => '708090', 'snow' => 'fffafa', 'springgreen' => '00ff7f', 'steelblue' => '4682b4', 'tan' => 'd2b48c', 'teal' => '008080', 'thistle' => 'd8bfd8', 'tomato' => 'ff6347', 'turquoise' => '40e0d0', 'violet' => 'ee82ee', 'wheat' => 'f5deb3', 'white' => 'ffffff', 'whitesmoke' => 'f5f5f5', 'yellow' => 'ffff00', 'yellowgreen' => '9acd32');



}

  



function dateConvertFormtoDB($date)

{

    if (!empty($date)) {

        return date("Y-m-d", strtotime(str_replace('/', '-', $date)));

    }

}



function valDash($val)

{

    return (empty($val) || $val == 0) ? '--' : $val;

}



function setQueryLog()

{

    DB::connection()->enableQueryLog();

}



function getQueryLog()

{

    return DB::getQueryLog();

}



function centerme()

{

    return ' style=text-align:center';

}



function leftme()

{

    return ' style=text-align:left';

}



function rightme()

{

    return ' style=text-align:right';

}



 



function get_month_name($num)

{

    $months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

    if($num<1)

    {

        $num=1;

    }



    if($num>12)

    {

        $num=12;

    }



    return $months[$num-1];



}

 

function get_units()

{

    $unit = Unit::select('unit_name','id')->get();

    // dd($unit);

    $returnArray ='';

    if(isset($unit) && (count($unit)>0))

    {

        $returnArray=[

            'units' => $unit,

        ];

        

    }else{

        $returnArray=[

            'units' => array(),

        ];

    }

    return $returnArray;

}



function get_zones()

{

    // setQueryLog();

    $zones = Zone::where('is_active','=','1')->orderBy('zone_name')->get();

    // dd(getQueryLog());

    // dd($zones);

    $returnArray ='';

    if(isset($zones) && (count($zones)>0))

    {

        $returnArray=[

            'zones' => $zones,

        ];

        

    }else{

        $returnArray=[

            'zones' => array(),

        ];

    }

    



    return $returnArray;

}



function get_territories()

{

    // setQueryLog();

    $territory = Territory::where('is_active','=','1')->orderBy('territory_name')->get();

    // dd(getQueryLog());

    // dd($zones);

    $returnArray ='';

    if(isset($territory) && (count($territory)>0))

    {

        $returnArray=[

            'territories' => $territory,

        ];

        

    }else{

        $returnArray=[

            'territories' => array(),

        ];

    }

    



    return $returnArray;

}





function get_towns()

{

    // setQueryLog();

    $territory = Territory::where('is_active','=','1')->orderBy('town_name')->get();

    // dd(getQueryLog());

    // dd($zones);

    $returnArray ='';

    if(isset($zones) && (count($town)>0))

    {

        $returnArray=[

            'towns' => $town,

        ];

        

    }else{

        $returnArray=[

            'towns' => array(),

        ];

    }

    



    return $returnArray;

}





function get_last_year($format='Y-m-d')

{

    $currentDate = new DateTime(date($format));

    return $currentDate->modify('-1 year')->format($format);   

}

function get_yesterday($format='Y-m-d')

{

    $yesterday = new DateTime('yesterday');

    return $yesterday->format($format);

}

 



   



function validateDate($date, $format = 'Y-m-d')

{

    $d = DateTime::createFromFormat($format, $date);

    // The Y ( 4 digits year ) returns TRUE for any integer with any number of digits so changing the comparison from == to === fixes the issue.

    return $d && $d->format($format) === $date;

}





function formatAUDate($date, $inputFormat,$outputFormat)

{

    $test = new DateTimeZone('Australia/Sydney');

    $gmt = new DateTimeZone('AEDT');

    

    $dt =  DateTime::createFromFormat($inputFormat,$date, $test);

    // $date->setTimezone($gmt);

    return $dt->format($outputFormat);

}





function formatDate($date, $inputFormat, $outputFormat)

{



    if ($date instanceof DateTime) {



        return $date->format($outputFormat); 



    }



    // dd($date);

    if (strpos($inputFormat, '-') !== false) {

        $date = str_replace('/', '-', $date);

    }



    if (strpos($inputFormat, '/') !== false) {

        $date = str_replace('-', '/', $date);

    }





    try {

        $dt = DateTime::createFromFormat($inputFormat, $date);

        if ($dt instanceof DateTime) {



            return $dt->format($outputFormat);



        } else {

            return  date($outputFormat, strtotime($date));

        }

    } catch (Exception $e) {

            return  date($outputFormat, strtotime($date));

    }



    // dd('.');



}





function stringToDate($date, $inputFormat, $outputFormat)

{



    if ($date instanceof DateTime) {



        return DateTime::createFromFormat($inputFormat, $date->format($outputFormat));

         

    }



    // dd($date);

    if (strpos($inputFormat, '-') !== false) {

        $date = str_replace('/', '-', $date);

    }



    if (strpos($inputFormat, '/') !== false) {

        $date = str_replace('-', '/', $date);

    }





    try {

        $dt = DateTime::createFromFormat($inputFormat, $date);

        if ($dt instanceof DateTime) {



            return $dt;



        } else {

            return  date($outputFormat, strtotime($date));

        }

    } catch (Exception $e) {

            return  date($outputFormat, strtotime($date));

    }



    // dd('.');



}



 



function dateConvertDBtoForm($date)

{

    if (!empty($date)) {

        $date = strtotime($date);

        return date('d/m/Y', $date);

    }

}

  
<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Distributor extends Model
{
    use HasFactory;

    public function onlinecash()
    {
        return $this->hasMany(online_cash::class,'distid','id');
    }
}

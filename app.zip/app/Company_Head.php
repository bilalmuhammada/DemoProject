<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Company_Head extends Model
{
    use HasFactory;

    use HasFactory;
    protected $fillable = [
        'company_head'
        
        
    ];
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Account_head extends Model
{
    use HasFactory;
    protected $fillable =[

        "ACHCode", 'ACHName', "HeadType"
    ];

    public function onlinecash()
    {
        return $this->hasMany('App/Online_cash','acchead','id');
    }
}

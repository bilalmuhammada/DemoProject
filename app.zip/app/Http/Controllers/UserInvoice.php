<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Customer;
use App\Company_Head;
use App\Ledger;
use App\order_detail;
use App\Product_Sale;
use Auth;
class UserInvoice extends Controller
{
    public function index(Request  $request)
    {
               

       
               $start_date=  $request->start_date;
               $end_date=    $request->end_date;
        
        // $role = Role::find(Auth::user()->role_id);
        // if($role->hasPermissionTo('account-index')){
        //     $lims_account_all = Account::where('is_active', true)->get();
        $companyhead  = Company_Head::get();
       
      
      $Product_invoice=[];
      if($start_date!=null && $end_date!=null)
      {
       
       $Product_invoice = Product_Sale::where('dist_id',$request->cust_id)->whereBetween('created_at', [$start_date, $end_date])->get();
         
      }else{
      
         
          
      }

  

      
     

  

     // $ledger = Ledger::where([['distid',$dis_id]])->whereBetween('recdate', [$start_date, $end_date])->get();

   
    $companyhead  = Company_Head::get();

     $distributer_all = Customer::where('is_active',1)->with('town')->where('territory',Auth::user()->territory)->get();
 
     return view('user_report.user_inovice',[
       'distributer_all'=>$distributer_all,
       'cust_id'=>$request->cust_id,
       'companyhead'=>$companyhead,
       'Product_invoice'=>$Product_invoice,
       'start_date'=>$start_date,
      'end_date'=>$end_date


   ]);
        // }
        // else
        //     return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }



    
    //show transcation button order  detail to user
    
    public function ordeDetail(Request $request,$id)
    {

        
$order= order_detail::with('customer')->with('productsale')->with('product')->where('prod_sale_id',$id)->get();
   return $order;
}
//user Invoice
 public function print_invoice(Request $request,$id)
    {
      
                        //$prod_sale_data = Product_Sale::where('id',$id)->first();
           
                $order= order_detail::with('customer')->with('productsale')->with('product')->where('prod_sale_id',$id)->get();
               
                 
                $order_date=$order[0]->productsale->created_at;
                $order_invoice=$order[0]->productsale->invoice;
                $cust_name= $order[0]->customer->distribution_name;
                $cust_address= $order[0]->customer->address;
                $ntn= $order[0]->customer->ntn;
                $cust_city= $order[0]->customer->city;
                $cust_num= $order[0]->customer->cust_num;
                $cust_state= $order[0]->customer->state;
                $cust_pakistan= $order[0]->customer->country;
                $cust_phone= $order[0]->customer->phone_number;
                $regular= "S-F";
                  $data=[
                      'order'=>$order,
                      'regular'=>$regular,
                      'cust_name'=>$cust_name,
                      'cust_num'=>$cust_num,
                      'ntn'=>$ntn,
                      'order_invoice'=>$order_invoice,
                       'order_date'=>$order_date,
                      'cust_address'=>$cust_address,
                      'cust_city'=>$cust_city,
                      'cust_state'=>$cust_state,
                      'cust_pakistan'=>$cust_pakistan,
                      'cust_phone'=>$cust_phone,
                  ];
  
                 return view("sale.index1",$data); 
        //   }
        //   elseif($request->inv=="true" && $request->ft=="true"){
  
        //       $prod_sale_data = Product_Sale::where('invoice',$request->inv_id)->first();
        //      // 
        //         $order= order_detail::with('customer')->with('product')->with('productsale')->where('prod_sale_id',$prod_sale_data->id)->get();
               
                
        //         $order_date=$order[0]->productsale->created_at;
        //         $order_invoice=$order[0]->productsale->invoice;
        //         $cust_name= $order[0]->customer->distribution_name;
        //         $cust_num= $order[0]->customer->cust_num;
        //         $cust_address= $order[0]->customer->address;
        //         $cust_city= $order[0]->customer->city;
        //         $ntn= $order[0]->customer->ntn;
        //         $cust_state= $order[0]->customer->state;
        //         $cust_pakistan= $order[0]->customer->country;
        //         $cust_phone= $order[0]->customer->phone_number;
        //         $regular= "F-T";
        //           $data=[
        //               'order'=>$order,
        //               'regular'=>$regular,
        //               'cust_num'=>$cust_num,
        //               'cust_name'=>$cust_name,
        //               'ntn'=>$ntn,
        //               'order_invoice'=>$order_invoice,
        //                'order_date'=>$order_date,
        //               'cust_address'=>$cust_address,
        //               'cust_city'=>$cust_city,
        //               'cust_state'=>$cust_state,
        //               'cust_pakistan'=>$cust_pakistan,
        //               'cust_phone'=>$cust_phone,
        //           ];
  
        //          return view("sale.index1",$data); 


    
}
    public function ledgerReport(Request $request)
    {
        //cust_id == dist_id
        $data = $request->all();
        //dd($data);
       
         $ledger=[];
        $start_date='';
        $end_date='';
       if(isset($data['start_date']))
       {
        $cust_id=$data['cust_id'];
        $companyhead= $data['companyhead'];
        $start_date=$data['start_date'];
        $end_date= $data['end_date'];
        $ledger = Ledger::where([['distid',$cust_id],['baltype',$companyhead]])->whereBetween('recdate', [$start_date, $end_date])->get();
          
       }else{
           $start_date='';
           $end_date='';
       }

      // $ledger = Ledger::where([['distid',$dis_id]])->whereBetween('recdate', [$start_date, $end_date])->get();

    
     $companyhead  = Company_Head::get();

      $distributer_all = Customer::where('is_active',1)->get();
      return view('user_report.user_inovice',[
        'distributer_all'=>$distributer_all,
        'companyhead'=>$companyhead,
        'ledger'=>$ledger,
        'start_date'=>$start_date,
       'end_date'=>$end_date,


    ]);
        //dd( );
    }

    public function store(Request $request)
    {
        
        


       
    }

    public function makeDefault($id)
    {
        $lims_account_data = Account::where('is_default', true)->first();
        $lims_account_data->is_default = false;
        $lims_account_data->save();

        $lims_account_data = Account::find($id);
        $lims_account_data->is_default = true;
        $lims_account_data->save();

        return 'Account set as default successfully';
    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'account_no' => [
                'max:255',
                    Rule::unique('accounts')->ignore($request->account_id)->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
        ]);

        $data = $request->all();
        $lims_account_data = Account::find($data['account_id']);
        if($data['initial_balance'])
            $data['total_balance'] = $data['initial_balance'];
        else
            $data['total_balance'] = 0;
        $lims_account_data->update($data);
        return redirect('accounts')->with('message', 'Account updated successfully');
    }

    public function balanceSheet()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('balance-sheet')){
            $lims_account_list = Account::where('is_active', true)->get();
            $debit = [];
            $credit = [];
            foreach ($lims_account_list as $account) {
                $payment_recieved = Payment::whereNotNull('sale_id')->where('account_id', $account->id)->sum('amount');
                $payment_sent = Payment::whereNotNull('purchase_id')->where('account_id', $account->id)->sum('amount');
                $returns = DB::table('returns')->where('account_id', $account->id)->sum('grand_total');
                $return_purchase = DB::table('return_purchases')->where('account_id', $account->id)->sum('grand_total');
                $expenses = DB::table('expenses')->where('account_id', $account->id)->sum('amount');
                $payrolls = DB::table('payrolls')->where('account_id', $account->id)->sum('amount');
                $sent_money_via_transfer = MoneyTransfer::where('from_account_id', $account->id)->sum('amount');
                $recieved_money_via_transfer = MoneyTransfer::where('to_account_id', $account->id)->sum('amount');

                $credit[] = $payment_recieved + $return_purchase + $recieved_money_via_transfer + $account->initial_balance;
                $debit[] = $payment_sent + $returns + $expenses + $payrolls + $sent_money_via_transfer;

                /*$credit[] = $payment_recieved + $return_purchase + $account->initial_balance;
                $debit[] = $payment_sent + $returns + $expenses + $payrolls;*/
            }
            return view('account.balance_sheet', compact('lims_account_list', 'debit', 'credit'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function accountStatement(Request $request)
    {
        $data = $request->all();
        $lims_account_data = Account::find($data['account_id']);
        $credit_list = [];
        $debit_list = [];
        $expense_list = [];
        $return_list = [];
        $purchase_return_list = [];
        $payroll_list = [];
        $recieved_money_transfer_list = [];
        $sent_money_transfer_list = [];
        
        if($data['type'] == '0' || $data['type'] == '2') {
            $credit_list = Payment::whereNotNull('sale_id')->where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $recieved_money_transfer_list = MoneyTransfer::where('to_account_id', $data['account_id'])->get();
        }
        if($data['type'] == '0' || $data['type'] == '1'){
            $debit_list = Payment::whereNotNull('purchase_id')->where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $expense_list = Expense::where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $return_list = Returns::where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $purchase_return_list = ReturnPurchase::where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $payroll_list = Payroll::where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $sent_money_transfer_list = MoneyTransfer::where('from_account_id', $data['account_id'])->get();
        }
        $balance = 0;
        return view('account.account_statement', compact('lims_account_data', 'credit_list', 'debit_list', 'expense_list', 'return_list', 'purchase_return_list', 'payroll_list', 'recieved_money_transfer_list', 'sent_money_transfer_list', 'balance'));
    }

    public function destroy($id)
    {
        if(!env('USER_VERIFIED'))
            return redirect()->back()->with('not_permitted', 'This feature is disable for demo!');
        $lims_account_data = Account::find($id);
        if(!$lims_account_data->is_default){
            $lims_account_data->is_active = false;
            $lims_account_data->save();
            return redirect('accounts')->with('not_permitted', 'Account deleted successfully!');
        }
        else
            return redirect('accounts')->with('not_permitted', 'Please make another account default first!');
    }


    public function ledgeruserReport(Request $request)
    {
        $data = $request->all();
        //dd($data);
        
          $ledger=[];
         $start_date='';
         $end_date='';
        if(isset($data['start_date']))
        {
         $cust_id=$data['cust_id'];
         $companyhead= $data['companyhead'];
         $start_date=$data['start_date'];
         $end_date= $data['end_date'];
         $ledger = Ledger::where([['distid',$cust_id],['baltype',$companyhead]])->whereBetween('recdate', [$start_date, $end_date])->get();
           
        }else{
     
            
        }
 
      
      $companyhead  = Company_Head::get();
 
       $distributer_all = Customer::where('is_active',1)->where('territory',Auth::user()->territory)->get();
       
       return view('report.user_ledger',[
         'distributer_all'=>$distributer_all,
         'companyhead'=>$companyhead,
         'ledger'=>$ledger,
         'start_date'=>$start_date,
        'end_date'=>$end_date,
 
 
     ]);
         
    }
}

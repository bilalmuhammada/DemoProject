<?php

namespace App\Http\Controllers;

use App\Account_head;
use Illuminate\Http\Request;
use App\Distributor;
use App\Zone;
use App\CustomerGroup;
use App\Town;
use App\Http\Requests\StoreZoneRequest;
use App\Http\Requests\UpdateZoneRequest;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Auth;
class AccountHeadController extends Controller
{
  
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('unit')) {
            $distributer_all = Distributor::get();
            $town_all = Town::get();
            $custgrp_all = CustomerGroup::get();
            $Account_head=Account_head::get();
 
            return view('Account_head.create', 
            ['distributer_all'=>$distributer_all,
            'town_all'=> $town_all,
            'Account_head'=>$Account_head,
            'custgrp_all'=> $custgrp_all,
            
         ]);
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }
 
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
 
    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreZoneRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'ACHName' => [
                'max:255',
                    Rule::unique('account_heads')->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
           
        ]);
        $input = $request->all();
    
        $model = new Account_head();
        $model->ACHCode =$input['ac_code'];
        $model->ACHName =$input['ac_name'];
        $model->HeadType =$input['ac_num'];
       // $model->HeadType =$input['online'];
       
       
        $model->save();
        return redirect('account_head')->with('message', 'Data inserted successfully');
    }
 
 
    public function deleteBySelection(Request $request)
    {
        $distributer_id = $request['zoneIdArray'];
        foreach ($zone_id as $id) {
            $Distributor_data = Account_head::find($id);
            $Distributor_data->is_active = false;
            $Distributor_data->save();
        }
        return 'Distributor deleted successfully!';
    }
 
    /**
     * Display the specified resource.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function show(Zone $zone)
    {
        //
    }
 
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Account_head::findOrFail($id);
        return $data;
    }
   
    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateZoneRequest  $request
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
 
        // $this->validate($request, [
        //     'DistributorName' => [
        //         'max:255',
        //         Rule::unique('zones')->ignore($request->zone_id)->where(function ($query) {
        //             return $query->where('is_active', 1);
        //         }),
        //     ],
           
        // ]);
       
        $input = $request->all();

       // dd( $input);
        $data1=[];

        $data1['ACHCode'] =$input['ac_code'];
        $data1['ACHName'] =$input['ac_name'];
        $data1['HeadType'] =$input['ac_num'];


        Account_head::where('id', $request->id)->update($data1);
        
        return redirect('account_head')->with('message', 'Data updated successfully');
    }
 
    
    public function destroy($id)
    {
        $distributor_data = Account_head::find($id);
        //$distributor_data->is_active = false;
        $distributor_data->delete();
        return redirect('account_head')->with('not_permitted', 'Data deleted successfully');
    }
}

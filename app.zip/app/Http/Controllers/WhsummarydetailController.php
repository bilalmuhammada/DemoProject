<?php

namespace App\Http\Controllers;

use App\whsummarydetail;
use Illuminate\Http\Request;

class WhsummarydetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\whsummarydetail  $whsummarydetail
     * @return \Illuminate\Http\Response
     */
    public function show(whsummarydetail $whsummarydetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\whsummarydetail  $whsummarydetail
     * @return \Illuminate\Http\Response
     */
    public function edit(whsummarydetail $whsummarydetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\whsummarydetail  $whsummarydetail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, whsummarydetail $whsummarydetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\whsummarydetail  $whsummarydetail
     * @return \Illuminate\Http\Response
     */
    public function destroy(whsummarydetail $whsummarydetail)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Customer;
use App\Company_Head;
use App\Ledger;
use App\Product;
use App\add_cliam;
use PDF;
use App\Town;
use App\Online_cash;
use App\order_detail;
use File;

use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Repsonse;
use App\add_stock;
use App\Price_structure;
use App\StockReturn;
use App\Unit;
use App\Product_Sale;
use App\Warehouse;
use Auth;
class LedgerController extends Controller
{
    //
    
    public function index()
    {
        
        // $role = Role::find(Auth::user()->role_id);
        // if($role->hasPermissionTo('account-index')){
        //     $lims_account_all = Account::where('is_active', true)->get();
        $companyhead  = Company_Head::get();

        $distributer_all = Customer::get();
            return view('report.user_report',[
                'distributer_all'=>$distributer_all,
                'companyhead'=>$companyhead
            ]);
        // }
        // else
        //     return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function ledgerReport(Request $request)
    {
        //cust_id == dist_id
       
       if(Auth::user()->role_id > 2 ){
        $ledger=[];
        $ledger_pre=[];

       $customer_detail= Customer::where('warehouse_id',Auth::user()->warehouse_id )->first();
       
        $start_date=  $request->start_date ;
        $end_date=   $request->end_date ;
        $cust_id=    $customer_detail->id;
        $companyhead_user=    $request->companyhead;

       


        if($start_date!=null && $end_date!=null && $companyhead_user==null)
        {
      //dd('gg');

   //setQueryLog();
   $invoice = Ledger::where('distid',$cust_id)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',1)->sum('amount');
  
  
  $online = Ledger::where('distid',$cust_id)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',2)->sum('amount');
  $claim = Ledger::where('distid',$cust_id)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',3)->sum('amount');
  
  $ledger_pre=  ($claim +$online)-$invoice;
   //    $ledger_pre = Ledger::orderBy('recdate','ASC')->where([['distid',$cust_id]])
   //    ->whereRaw("recdate< STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d')")
   //    ->sum('amount');
      
      //dd(getQueryLog());

       $ledger = Ledger::orderBy('recdate','ASC')
       ->where([['distid',$cust_id]])
       ->whereRaw("recdate BETWEEN STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d') AND STR_TO_DATE('" . date('Y-m-d' , strtotime($end_date)) . "', '%Y-%m-%d')")
       ->get();
      
      }else if($start_date!=null && $end_date!=null && $companyhead_user!=null){
       
       $ledger = Ledger::orderBy('recdate','ASC')
       ->where([['distid',$cust_id],['baltype',$companyhead_user]])
       ->whereRaw("recdate BETWEEN STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d') AND STR_TO_DATE('" . date('Y-m-d' , strtotime($end_date)) . "', '%Y-%m-%d')")
       ->get();
       
      //setQueryLog();
       $ledger_pre = Ledger::orderBy('recdate','ASC')->where([['distid',$cust_id]])
       ->whereRaw("recdate< STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d')")
       ->sum('amount');
   // dd(getQueryLog());
      }else{
       
      }


      $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));
  
      if($end_date==null && $start_date==null){

       $end_date=date('Y-m-t');
       $start_date=date('Y-m-01');
   }







       
       }else{
         $ledger=[];
         $ledger_pre=[];
         $start_date=  $request->start_date ;
         $end_date=   $request->end_date ;
         $cust_id=    $request->user_id;
         $companyhead_user=    $request->companyhead;

        


         if($start_date!=null && $end_date!=null && $companyhead_user==null)
         {
       //dd('gg');

    //setQueryLog();
    $invoice = Ledger::where('distid',$cust_id)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',1)->sum('amount');
   
   
   $online = Ledger::where('distid',$cust_id)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',2)->sum('amount');
   $claim = Ledger::where('distid',$cust_id)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',3)->sum('amount');
   
   $ledger_pre=  ($claim +$online)-$invoice;
    //    $ledger_pre = Ledger::orderBy('recdate','ASC')->where([['distid',$cust_id]])
    //    ->whereRaw("recdate< STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d')")
    //    ->sum('amount');
       
       //dd(getQueryLog());

        $ledger = Ledger::orderBy('recdate','ASC')
        ->where([['distid',$cust_id]])
        ->whereRaw("recdate BETWEEN STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d') AND STR_TO_DATE('" . date('Y-m-d' , strtotime($end_date)) . "', '%Y-%m-%d')")
        ->get();
       
       }else if($start_date!=null && $end_date!=null && $companyhead_user!=null){
        
        $ledger = Ledger::orderBy('recdate','ASC')
        ->where([['distid',$cust_id],['baltype',$companyhead_user]])
        ->whereRaw("recdate BETWEEN STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d') AND STR_TO_DATE('" . date('Y-m-d' , strtotime($end_date)) . "', '%Y-%m-%d')")
        ->get();
        
       //setQueryLog();
        $ledger_pre = Ledger::orderBy('recdate','ASC')->where([['distid',$cust_id]])
        ->whereRaw("recdate< STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d')")
        ->sum('amount');
    // dd(getQueryLog());
       }else{
        
       }


       $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));
   
       if($end_date==null && $start_date==null){

        $end_date=date('Y-m-t');
        $start_date=date('Y-m-01');
    }
}
      
   
     $companyhead  = Company_Head::get();
     $townName='';
     $distributerName='';
      $distributer_all = Customer::where('is_active',1)->get();
      $customer = Customer::where('is_active',1)->where('id',$cust_id)->first();
      if($customer!=null){
       $distributerName= $customer->distribution_name;
        $town=Town::where('id',$customer->city)->first();
        $townName=$town->town_name;
      }
      
      return view('report.ledger',[
        'distributer_all'=>$distributer_all,
        
        'companyhead'=>$companyhead,
        'cust_id'=>$request->user_id,
        'companyhead_user'=>$companyhead_user,
        'ledger'=>$ledger,
        'customer'=>$distributerName,
        
        'town'=>$townName,
        'ledger_pre'=>$ledger_pre,
        'prevdate'=>$prevdate,
        'start_date'=>$start_date,
       'end_date'=>$end_date,


    ]);
        //dd( );
    }

    
    public function ledger_report_summary(Request $request)
    {
        
        $distributer_all = Customer::with('town')->where('is_active',true)->get();
        $start_date= $request->start_date;
        $end_date= $request->end_date;
        $invoice_type= $request->companyhead;
        ;
        if($start_date!=null && $end_date!=null && $invoice_type!=null)
        {
        $leger_summary=[];
      foreach($distributer_all as $customer){

        $data['town_id']= $customer->city;
        $data['distribution_name']= $customer->distribution_name;
        $data['online_cash'] = Online_cash::orderBy('id',"DESC")->whereBetween('recdate',[$start_date,$end_date])->where('distid',$customer->id)->where('baltype',$invoice_type)->sum('amount');

        
        $data['recent_sale'] = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->where('account',$invoice_type)->where('dist_id',$customer->id)->where('status',1)->sum('total');
          
        $data['addcliam'] = add_cliam::whereBetween('recdate',[$start_date,$end_date])->where('distid',$customer->id)->where('claim',$invoice_type)->sum('amount');
      
        $leger_summary[]=$data;
    }

   
}
    else if($start_date!=null && $end_date!=null && $invoice_type==null){
        $leger_summary=[];
        
      foreach($distributer_all as $customer){

        $data['town_id']= $customer->city;
        $data['distribution_name']= $customer->distribution_name;
        $data['online_cash'] = Online_cash::orderBy('id',"DESC")->whereBetween('recdate',[$start_date,$end_date])->where('distid',$customer->id)->sum('amount');

        
        $data['recent_sale'] = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->where('dist_id',$customer->id)->where('status',1)->sum('total');
          
        $data['addcliam'] = add_cliam::whereBetween('recdate',[$start_date,$end_date])->where('distid',$customer->id)->sum('amount');
      
        $leger_summary[]=$data;

    }}

    else
    {
        $leger_summary=[];
        
        foreach($distributer_all as $customer){
  
          $data['town_id']= $customer->city;
          $data['distribution_name']= $customer->distribution_name;
          $data['online_cash'] = Online_cash::orderBy('id',"DESC")->whereBetween('recdate',[$start_date,$end_date])->where('distid',$customer->id)->sum('amount');
  
          
          $data['recent_sale'] = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->where('dist_id',$customer->id)->where('status',1)->sum('total');
            
          $data['addcliam'] = add_cliam::whereBetween('recdate',[$start_date,$end_date])->where('distid',$customer->id)->sum('amount');
        
          $leger_summary[]=$data;

    }

    if($start_date==null && $end_date==null )
    {
        $end_date=date('Y-m-t');
        $start_date=date('Y-m-01');
    }
}


       
$companyhead  = Company_Head::get();
        

return view('report.reports.ledger_report_summary',[
    'leger_summary'=>$leger_summary,
    
    'companyhead'=>$companyhead,
//     'cust_id'=>$request->user_id,
  'invoice_type'=>$invoice_type,
//     'ledger'=>$ledger,
//     'customer'=>$distributerName,
    
//     'town'=>$townName,
//     'ledger_pre'=>$ledger_pre,
//     'prevdate'=>$prevdate,
    'start_date'=>$start_date,
   'end_date'=>$end_date,


]);
       
    }

    public function store(Request $request)
    {
        
        


       
    }

    public function makeDefault($id)
    {
        $lims_account_data = Account::where('is_default', true)->first();
        $lims_account_data->is_default = false;
        $lims_account_data->save();

        $lims_account_data = Account::find($id);
        $lims_account_data->is_default = true;
        $lims_account_data->save();

        return 'Account set as default successfully';
    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'account_no' => [
                'max:255',
                    Rule::unique('accounts')->ignore($request->account_id)->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
        ]);

        $data = $request->all();
        $lims_account_data = Account::find($data['account_id']);
        if($data['initial_balance'])
            $data['total_balance'] = $data['initial_balance'];
        else
            $data['total_balance'] = 0;
        $lims_account_data->update($data);
        return redirect('accounts')->with('message', 'Account updated successfully');
    }

    public function balanceSheet()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('balance-sheet')){
            $lims_account_list = Account::where('is_active', true)->get();
            $debit = [];
            $credit = [];
            foreach ($lims_account_list as $account) {
                $payment_recieved = Payment::whereNotNull('sale_id')->where('account_id', $account->id)->sum('amount');
                $payment_sent = Payment::whereNotNull('purchase_id')->where('account_id', $account->id)->sum('amount');
                $returns = DB::table('returns')->where('account_id', $account->id)->sum('grand_total');
                $return_purchase = DB::table('return_purchases')->where('account_id', $account->id)->sum('grand_total');
                $expenses = DB::table('expenses')->where('account_id', $account->id)->sum('amount');
                $payrolls = DB::table('payrolls')->where('account_id', $account->id)->sum('amount');
                $sent_money_via_transfer = MoneyTransfer::where('from_account_id', $account->id)->sum('amount');
                $recieved_money_via_transfer = MoneyTransfer::where('to_account_id', $account->id)->sum('amount');

                $credit[] = $payment_recieved + $return_purchase + $recieved_money_via_transfer + $account->initial_balance;
                $debit[] = $payment_sent + $returns + $expenses + $payrolls + $sent_money_via_transfer;

                /*$credit[] = $payment_recieved + $return_purchase + $account->initial_balance;
                $debit[] = $payment_sent + $returns + $expenses + $payrolls;*/
            }
            return view('account.balance_sheet', compact('lims_account_list', 'debit', 'credit'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function accountStatement(Request $request)
    {
        $data = $request->all();
        $lims_account_data = Account::find($data['account_id']);
        $credit_list = [];
        $debit_list = [];
        $expense_list = [];
        $return_list = [];
        $purchase_return_list = [];
        $payroll_list = [];
        $recieved_money_transfer_list = [];
        $sent_money_transfer_list = [];
        
        if($data['type'] == '0' || $data['type'] == '2') {
            $credit_list = Payment::whereNotNull('sale_id')->where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $recieved_money_transfer_list = MoneyTransfer::where('to_account_id', $data['account_id'])->get();
        }
        if($data['type'] == '0' || $data['type'] == '1'){
            $debit_list = Payment::whereNotNull('purchase_id')->where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $expense_list = Expense::where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $return_list = Returns::where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $purchase_return_list = ReturnPurchase::where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $payroll_list = Payroll::where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $sent_money_transfer_list = MoneyTransfer::where('from_account_id', $data['account_id'])->get();
        }
        $balance = 0;
        return view('account.account_statement', compact('lims_account_data', 'credit_list', 'debit_list', 'expense_list', 'return_list', 'purchase_return_list', 'payroll_list', 'recieved_money_transfer_list', 'sent_money_transfer_list', 'balance'));
    }

    public function destroy($id)
    {
        if(!env('USER_VERIFIED'))
            return redirect()->back()->with('not_permitted', 'This feature is disable for demo!');
        $lims_account_data = Account::find($id);
        if(!$lims_account_data->is_default){
            $lims_account_data->is_active = false;
            $lims_account_data->save();
            return redirect('accounts')->with('not_permitted', 'Account deleted successfully!');
        }
        else
            return redirect('accounts')->with('not_permitted', 'Please make another account default first!');
    }

// ledgeruserReport Report User
    public function ledgeruserReport(Request $request)
    {
        $data = $request->all();
        
        $ledger=[];
        $start_date=  $request->start_date ;
        $end_date=  $request->end_date ;
        $cust_id=    $request->user_id;
       
        if($start_date!=null && $end_date!=null )
        {
     
      
       $ledger = Ledger::orderBy('id','ASC')->where([['distid',$cust_id]])->whereBetween('recdate', [date('Y-m-d' , strtotime($start_date)), date('Y-m-d' , strtotime($end_date))])->get();
      
        }else{
       
      }
   
     
      if($start_date==null || $end_date==null){
        $start_date=date('01/m/Y');

        $end_date=date('t/m/Y');
      }
     
  // dd($start_date);
     // $ledger = Ledger::where([['distid',$dis_id]])->whereBetween('recdate', [$start_date, $end_date])->get();
    // dd($start_date);
 

          
 
      $distributer_all = Customer::where('is_active',1)->with('town')->where('territory',Auth::user()->territory)->get();
       
       return view('report.user_ledger',[
        'distributer_all'=>$distributer_all,
        
        
        'cust_id'=>$request->user_id,
       
        'ledger'=>$ledger,
        'start_date'=>$start_date,
       'end_date'=>$end_date,
 
     ]);
         
    }




// fgs Report admin
    public function fgs_Report(Request $request)
    {

       
        $data = $request->all();
        if(Auth::user()->role_id > 2){

            $ledger=[];

            $totalData = Product::where('is_active', true)->count();
            $lims_product_all = Product::select('id', 'name', 'price','ProductWeight','UnitPerCTRN','unit_id','qty', 'is_variant')
                                    ->where('is_active', true)
                                    ->limit($totalData)
                                    ->orderBy('code', 'ASC')
                                    ->get();
    
                                   
                                       
    
                                    
    $data=[];
    // foreach($lims_product_all as $product){
        
    //     $nestedData['key']=count($data);
    //     $nestedData['name']=$product->name;
    //     $nestedData['gms']=$product->ProductWeight;
    //     $nestedData['ctn']=$product->UnitPerCTRN;
    //     $nestedData['price']=$product->price;
    //     $nestedData['id']=$product->id;
    //     $nestedData['invoice_qty_prev'] = order_detail::select('qty')->whereDate('created_at',date('Y-m-d',strtotime("-1 days")))->where('prod_id', $product->id)->sum('qty');
                      
    //     $nestedData['stock_qty_prev'] = add_stock::select('stock_qty')->whereDate('date',date('Y-m-d',strtotime("-1 days")))->where('prod_id', $product->id)->sum('stock_qty');
    
    //     $nestedData['invoice_qty'] = order_detail::select('qty')->whereDate('created_at',date('Y-m-d'))->where('prod_id', $product->id)->sum('qty');
                      
    //     $nestedData['stock_qty'] = add_stock::select('stock_qty')->whereDate('date',date('Y-m-d'))->where('prod_id', $product->id)->sum('stock_qty');
    //     $nestedData['unit'] = Unit::where('id', $product->unit_id)->pluck('unit_code')->toArray();
    //     $nestedData['stockReturn']=  StockReturn::where('product_id',$nestedData['id'])->where('return_type',1)->first();
    //     $data[]=  $nestedData;
    // }
    
    
    
    
    
                            
            $start_date=  $request->start_date ;
            $end_date=  $request->end_date ;
          
            if($start_date!=null && $end_date!=null )
            {
        
          
          $data=[];
         $prod_sale= Product_Sale::where('warehouse',Auth::user()->warehouse_id)->whereDate('created_at','>=',$start_date)->whereDate('created_at','<=',$end_date)->get()->pluck('id')->toArray();
       
          foreach($lims_product_all as $product){
              
              $nestedData['key']=count($data);
              $nestedData['name']=$product->name;
              $nestedData['gms']=$product->ProductWeight;
              $nestedData['ctn']=$product->UnitPerCTRN;
              $nestedData['price']=$product->price;
              $nestedData['id']=$product->id;
              
           
            $nestedData['invoice_qty_prev'] = order_detail::select('qty')->whereDate('created_at','<',$start_date)->whereIn('prod_sale_id',$prod_sale)->where('prod_id', $product->id)->sum('qty');
                      
            $nestedData['stock_qty_prev'] = add_stock::select('stock_qty')->whereDate('date','<',$start_date)->where('prod_id', $product->id)->where('warehouse_id',8 )->sum('stock_qty');
      
            $nestedData['invoice_qty'] = order_detail::select('qty')->whereDate('created_at','>=',$start_date)->whereDate('created_at','<=',$end_date)->whereIn('prod_sale_id',$prod_sale)->where('prod_id', $product->id)->sum('qty');
                            
             $nestedData['stock_qty'] = add_stock::select('stock_qty')->whereDate('date','>=',$start_date)->whereDate('date','<=',$end_date)->where('prod_id', $product->id)->where('warehouse_id',8)->sum('stock_qty');
              $nestedData['unit'] = Unit::where('id', $product->unit_id)->pluck('unit_code')->toArray();
            //   $nestedData['stockReturn']=  StockReturn::where('product_id',$nestedData['id'])->where('return_type',1)->first();
              
            $nestedData['stockReturn']=0;
              $data[]=  $nestedData;
          }
          
        // dd($data);
       
              
          }else{
            $data=[];
            $start_date=  date('Y-m-d') ;
            $end_date=  date('Y-m-d');
            $prod_sale= Product_Sale::where('warehouse',Auth::user()->warehouse_id)->whereDate('created_at','>=',$start_date)->whereDate('created_at','<=',$end_date)->get()->pluck('id')->toArray();
         
            foreach($lims_product_all as $product){
                
                
                $nestedData['key']=count($data);
                $nestedData['name']=$product->name;
                $nestedData['gms']=$product->ProductWeight;
                $nestedData['ctn']=$product->UnitPerCTRN;
                $nestedData['price']=$product->price;
                $nestedData['id']=$product->id;
                $nestedData['invoice_qty_prev'] = order_detail::select('qty')->whereDate('created_at','<',date('Y-m-d'))->whereIn('prod_sale_id',$prod_sale)->where('prod_id', $product->id)->sum('qty');
                              
                $nestedData['stock_qty_prev'] = add_stock::select('stock_qty')->whereDate('date','<',date('Y-m-d'))->where('prod_id', $product->id)->where('warehouse_id',Auth::user()->warehouse_id )->sum('stock_qty');
               
                $nestedData['invoice_qty'] = order_detail::select('qty')->whereDate('created_at','>=',$start_date)->whereDate('created_at','<=',$end_date)->whereIn('prod_sale_id',$prod_sale)->where('prod_id', $product->id)->sum('qty');
                            
                $nestedData['stock_qty'] = add_stock::select('stock_qty')->whereDate('date','>=',$start_date)->whereDate('date','<=',$end_date)->where('prod_id', $product->id)->where('warehouse_id',Auth::user()->warehouse_id )->sum('stock_qty');
                $nestedData['unit'] = Unit::where('id', $product->unit_id)->pluck('unit_code')->toArray();
                // $nestedData['stockReturn']=  StockReturn::where('product_id',$nestedData['id'])->where('return_type',1)->first();
    
                $nestedData['stockReturn']=0;
                $data[]=  $nestedData;
            }
          
          }

        }else{
        $ledger=[];

        $totalData = Product::where('is_active', true)->count();
        $lims_product_all = Product::select('id', 'name', 'price','ProductWeight','UnitPerCTRN','unit_id','qty', 'is_variant')
                                ->where('is_active', true)
                                ->limit($totalData)
                                ->orderBy('code', 'ASC')
                                ->get();

                               
                                   

                                
$data=[];
// foreach($lims_product_all as $product){
    
//     $nestedData['key']=count($data);
//     $nestedData['name']=$product->name;
//     $nestedData['gms']=$product->ProductWeight;
//     $nestedData['ctn']=$product->UnitPerCTRN;
//     $nestedData['price']=$product->price;
//     $nestedData['id']=$product->id;
//     $nestedData['invoice_qty_prev'] = order_detail::select('qty')->whereDate('created_at',date('Y-m-d',strtotime("-1 days")))->where('prod_id', $product->id)->sum('qty');
                  
//     $nestedData['stock_qty_prev'] = add_stock::select('stock_qty')->whereDate('date',date('Y-m-d',strtotime("-1 days")))->where('prod_id', $product->id)->sum('stock_qty');

//     $nestedData['invoice_qty'] = order_detail::select('qty')->whereDate('created_at',date('Y-m-d'))->where('prod_id', $product->id)->sum('qty');
                  
//     $nestedData['stock_qty'] = add_stock::select('stock_qty')->whereDate('date',date('Y-m-d'))->where('prod_id', $product->id)->sum('stock_qty');
//     $nestedData['unit'] = Unit::where('id', $product->unit_id)->pluck('unit_code')->toArray();
//     $nestedData['stockReturn']=  StockReturn::where('product_id',$nestedData['id'])->where('return_type',1)->first();
//     $data[]=  $nestedData;
// }





                        
        $start_date=  $request->start_date ;
        $end_date=  $request->end_date ;
      
        if($start_date!=null && $end_date!=null && $request->warehouse_id!=null )
        {
       
      // dd($request->warehouse_id);
      $data=[];
      foreach($lims_product_all as $product){
          
          $nestedData['key']=count($data);
          $nestedData['name']=$product->name;
          $nestedData['gms']=$product->ProductWeight;
          $nestedData['ctn']=$product->UnitPerCTRN;
          $nestedData['price']=$product->price;
          $nestedData['id']=$product->id;
          // dd('dd');
         
      //   $nestedData['invoice_qty_prev'] = order_detail::select('qty')->whereDate('created_at','<',date('Y-m-d',strtotime($start_date)))->where('prod_id', $product->id)->whereHas('product_sales', function ($query) use($request)  {
      //     return $query->where('warehouse',$request->warehouse_id)
      //  ;})->get();

      if($request->warehouse_id==8){

      
       $nestedData['invoice_qty_prev'] = order_detail::join('product_sales','product_sales.id','=','order_details.prod_sale_id')
       ->whereDate('order_details.created_at','<',date('Y-m-d',strtotime($start_date)))
       ->where('order_details.prod_id', $product->id)
       ->where('product_sales.warehouse',$request->warehouse_id)->sum('order_details.qty');
         
        $nestedData['stock_qty_prev'] = add_stock::select('stock_qty')->whereDate('date','<',date('Y-m-d',strtotime($start_date)))->where('prod_id', $product->id)->where('warehouse_id',$request->warehouse_id)->sum('stock_qty');
  
        $nestedData['invoice_qty'] = order_detail::join('product_sales','product_sales.id','=','order_details.prod_sale_id')
        ->whereDate('order_details.created_at','>=',date('Y-m-d',strtotime($start_date)))
        ->whereDate('order_details.created_at','<=',date('Y-m-d',strtotime($end_date)))
        ->where('order_details.prod_id', $product->id)
        ->where('product_sales.warehouse',$request->warehouse_id)->sum('order_details.qty');
                     
        $nestedData['tpValue']=Price_structure::where('product_id',$product->id)->where('group_id',2)->pluck('txt_trade_price')->first();
       
$nestedData['invValue']=Price_structure::where('product_id',$product->id)->where('group_id',2)->pluck('inv_price')->first();
       
   
         $nestedData['stock_qty'] = add_stock::select('stock_qty')->whereDate('date','>=',date('Y-m-d',strtotime($start_date)))->whereDate('date','<=',date('Y-m-d',strtotime($end_date)))->where('prod_id', $product->id)->where('warehouse_id',$request->warehouse_id)->sum('stock_qty');
          $nestedData['unit'] = Unit::where('id', $product->unit_id)->pluck('unit_code')->toArray();
          $nestedData['stockReturn']=  StockReturn::where('product_id',$nestedData['id'])->where('return_type',1)->first();
          $data[]=  $nestedData;
      }else
      {
         if($request->warehouse_id==1){

          $user_id=102;
        }elseif($request->warehouse_id==9){

$user_id=66;
        }elseif($request->warehouse_id==10){
          $user_id=101;  
        }
       
        $nestedData['invoice_qty_prev'] = order_detail::join('product_sales','product_sales.id','=','order_details.prod_sale_id')
       ->whereDate('order_details.created_at','<',date('Y-m-d',strtotime($start_date)))
       ->where('order_details.prod_id', $product->id)
       ->where('product_sales.dist_id',$user_id)->sum('order_details.qty');
        
      

       $nestedData['stock_qty_prev_pro'] = add_stock::select('stock_qty')->whereDate('date','<',date('Y-m-d',strtotime($start_date)))->where('prod_id', $product->id)->where('warehouse_id',$request->warehouse_id)->sum('stock_qty');
  
       $nestedData['sale_qty_prev'] = order_detail::join('product_sales','product_sales.id','=','order_details.prod_sale_id')
       ->whereDate('order_details.created_at','<',date('Y-m-d',strtotime($start_date)))
       ->where('order_details.prod_id', $product->id)
       ->where('product_sales.warehouse',$request->warehouse_id)->sum('order_details.qty');
      //  dd($nestedData['invoice_qty_prev'] - $nestedData['sale_qty_prev']);
    //  dd(     $nestedData['invoice_qty_prev']+ $nestedData['stock_qty_prev_pro']- $nestedData['sale_qty_prev']  );
        $nestedData['stock_qty_prev'] = add_stock::select('stock_qty')->whereDate('date','<',date('Y-m-d',strtotime($start_date)))->where('prod_id', $product->id)->where('warehouse_id',$request->warehouse_id)->sum('stock_qty');
  
        $nestedData['invoice_qty'] = order_detail::join('product_sales','product_sales.id','=','order_details.prod_sale_id')
        ->whereDate('order_details.created_at','>=',date('Y-m-d',strtotime($start_date)))
        ->whereDate('order_details.created_at','<=',date('Y-m-d',strtotime($end_date)))
        // ->whereBetween('order_details.created_at',[date('Y-m-d',strtotime($end_date))." 00:00:00",date('Y-m-d',strtotime($end_date))." 23:59:59"])
        ->where('order_details.prod_id', $product->id)
        ->where('order_details.cust_id', $user_id)
    ->sum('order_details.qty');

   
    $nestedData['sale_qty'] = order_detail::join('product_sales','product_sales.id','=','order_details.prod_sale_id')
        ->whereDate('order_details.created_at','>=',date('Y-m-d',strtotime($start_date)))
        ->whereDate('order_details.created_at','<=',date('Y-m-d',strtotime($end_date)))
        // ->whereBetween('order_details.created_at',[date('Y-m-d',strtotime($end_date))." 00:00:00",date('Y-m-d',strtotime($end_date))." 23:59:59"])
        ->where('order_details.prod_id', $product->id)
        // ->where('order_details.cust_id', 102)
        ->where('product_sales.warehouse',$request->warehouse_id) ->sum('order_details.qty');

$nestedData['tpValue']=Price_structure::where('product_id',$product->id)->where('group_id',2)->pluck('txt_trade_price')->first();
       
$nestedData['invValue']=Price_structure::where('product_id',$product->id)->where('group_id',2)->pluck('inv_price')->first();
       
   
                   //  dd( $nestedData['invoice_qty'] );
         $nestedData['stock_qty'] = add_stock::select('stock_qty')->whereDate('date','>=',date('Y-m-d',strtotime($start_date)))->whereDate('date','<=',date('Y-m-d',strtotime($end_date)))->where('prod_id', $product->id)->where('warehouse_id',$request->warehouse_id)->sum('stock_qty');
          $nestedData['unit'] = Unit::where('id', $product->unit_id)->pluck('unit_code')->toArray();
          $nestedData['stockReturn']=  StockReturn::where('product_id',$nestedData['id'])->where('return_type',1)->first();
          $data[]=  $nestedData;

      }
      }
      
    // dd($data);
          
      }else{
        $data=[];
   
        foreach($lims_product_all as $product){
            $start_date=  date('Y-m-01') ;
            $end_date=  date('Y-m-t');
            
            $nestedData['key']=count($data);
            $nestedData['name']=$product->name;
            $nestedData['gms']=$product->ProductWeight;
            $nestedData['ctn']=$product->UnitPerCTRN;
            $nestedData['price']=$product->price;
            $nestedData['id']=$product->id;
            $nestedData['invoice_qty_prev'] = order_detail::select('qty')->whereDate('created_at','<',date('Y-m-d'))->where('prod_id', $product->id)->with(['product_sales' => function ($query)   {
              return $query->where('warehouse',8)
           ;},])->sum('qty');
                          
            $nestedData['stock_qty_prev'] = add_stock::select('stock_qty')->whereDate('date','<',date('Y-m-d'))->where('prod_id', $product->id)->where('warehouse_id',8)->sum('stock_qty');
           
            $nestedData['invoice_qty'] = order_detail::select('qty')->whereDate('created_at','>=',$start_date)->whereDate('created_at','<=',$end_date)->where('prod_id', $product->id)->with(['product_sales' => function ($query)   {
              return $query->where('warehouse',8)
           ;},])->sum('qty');
                        
            $nestedData['stock_qty'] = add_stock::select('stock_qty')->whereDate('date','>=',$start_date)->whereDate('date','<=',$end_date)->where('prod_id', $product->id)->where('warehouse_id',8)->sum('stock_qty');
            $nestedData['unit'] = Unit::where('id', $product->unit_id)->pluck('unit_code')->toArray();
            $nestedData['stockReturn']=  StockReturn::where('product_id',$nestedData['id'])->where('return_type',1)->first();
            $nestedData['tpValue']=Price_structure::where('product_id',$product->id)->where('group_id',2)->pluck('txt_trade_price')->first();
      
            $nestedData['invValue']=Price_structure::where('product_id',$product->id)->where('group_id',2)->pluck('inv_price')->first();
      
            $data[]=  $nestedData;
           
       
        }
      
      }
 
    }

      

     
     // $ledger = Ledger::where([['distid',$dis_id]])->whereBetween('recdate', [$start_date, $end_date])->get();
    // dd($start_date);
  
    $companyhead  = Company_Head::get();

          
    $warehouse  =  Warehouse::where('is_active',true)->get();
      $distributer_all = Customer::where('is_active',1)->with('town')->where('territory',Auth::user()->territory)->get();
       
       return view('report.fgs_report',[
        'distributer_all'=>$distributer_all,
        
        'companyhead'=>$companyhead,
         'warehouse_id'=>$request->warehouse_id,
        // 'companyhead_user'=>$companyhead_user,
        'fgs_report'=>$data,

        'warehouse'=>$warehouse,
        'start_date'=>date("d-m-Y", strtotime($start_date)),
       'end_date'=>date("d-m-Y", strtotime($end_date)),
 
     ]);
         
    }

    function  get_distributor_name_ledger($id)
{
      $distributor_detail=  Customer::where('id',$id)->first();
    // dd($distributor_detail);
    return $distributor_detail->distribution_name;
}


function  print_history(Request $request) 
{
    

    
    if(Auth::user()->role_id > 2){
    $recent_sale=[];
   
    $start_date= $request->start_date  ;
    $end_date=   $request->end_date ;
   
    $invoice_type=    $request->invoice_type;
    $payment_type=    1;



    if($payment_type==1){
    if($start_date!=null && $end_date!=null && $invoice_type==null)
    {
 

   
///setQueryLog();

$recent_sale = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->with('orderdetail')->where('warehouse',1)->where('status',1)->get();
  


  //dd(getQueryLog());

 
  
  }else if($start_date!=null && $end_date!=null && $invoice_type!=null){
   
   
$recent_sale = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->where('account',$invoice_type)->with('orderdetail')->where('warehouse',1)->where('status',1)->get();
  

// dd(getQueryLog());
  }else{
    $end_date=date('Y-m-t');
   $start_date=date('Y-m-01');
   
$recent_sale = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->with('orderdetail')->where('warehouse',1)->where('status',1)->get();
  


  }
  
 

  }

 

  $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));

  if($end_date==null && $start_date==null){

   $end_date=date('Y-m-t');
   $start_date=date('Y-m-01');
}





$companyhead  = Company_Head::get();
$townName='';
$distributerName='';
 $distributer_all = Customer::where('is_active',1)->get();
}else{
    $recent_sale=[];
   
    $start_date= $request->start_date  ;
    $end_date=   $request->end_date ;
   
    $invoice_type=    $request->invoice_type;
    $payment_type=    1;
    
   //dd($start_date);

if($payment_type==1){
    if($start_date!=null && $end_date!=null && $invoice_type==null)
    {
     
    
$recent_sale = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->with('orderdetail')->where('status',1)->get();
  


 
  
  }else if($start_date!=null && $end_date!=null && $invoice_type!=null){
   
   
$recent_sale = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->where('account',$invoice_type)->with('orderdetail')->where('status',1)->get();
  

// dd(getQueryLog());
  }else{
    // dd('admin');
    $end_date=date('Y-m-t');
   $start_date=date('Y-m-01');
   
$recent_sale = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->with('orderdetail')->where('status',1)->get();
  
// ->whereNotIn('dist_id',[102,33,66])


  }
  
 

  }

 

  $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));

  if($end_date==null && $start_date==null){

   $end_date=date('Y-m-t');
   $start_date=date('Y-m-01');
}





$companyhead  = Company_Head::get();
$townName='';
$distributerName='';
 $distributer_all = Customer::where('is_active',1)->get();

      
}
 
 
 return view('report.print_history',[
   'distributer_all'=>$distributer_all,
   
   'companyhead'=>$companyhead,
   'payment_type'=>$payment_type,
   'invoice_type'=>$invoice_type,
   
   'customer'=>$distributerName,
   'invoice'=>$recent_sale,
   
  
   'prevdate'=>$prevdate,
   'start_date'=>$start_date,
  'end_date'=>$end_date,


]);



}

public function deleteBySelection(Request $request){
  $invoiceIdArray1 = $request['invoiceIdArray'];
 // $prod_sale_data = [];
try{
       foreach ($invoiceIdArray1 as $id) {
        

       $prod_sale_data[] = Product_Sale::where('id',$id)->with('customer')
       ->with(['orderdetail'=>function($query){
            // $query->orderBy('prod_code','ASC')->orderBy('id',"ASC");
        }])->get();
          // dd($prod_sale_data);
        
          
            //  $order[]= order_detail::with('customer')->with('productsale')->with('product')->where('prod_sale_id',$id)
              
            //   ->with(['product'=>function($query){
            //     $query->with('category');
            //   }])
              
            //   ->get();

              
         
             $town_name=Town::where('id',$prod_sale_data[0][0]->customer->city)->first();
               
            //   $order_date=$order[0]->productsale->created_at;
            //   $order_invoice=$order[0]->productsale->invoice;
            //   $cust_name= $order[0]->customer->distribution_name;
            //   $cust_address= $order[0]->customer->address;
            //   $ntn= $order[0]->customer->ntn;
            //   $cust_city= $town_name->town_name;
            //   $cust_num= $order[0]->customer->cust_num;
            //   $cust_state= $order[0]->customer->state;
            //   $cust_pakistan= $order[0]->customer->country;
            //   $cust_phone= $order[0]->customer->phone_number;
            //   $cnic= $order[0]->customer->cnic;            
        //  dd($prod_sale_data);
              $regular= "S-F";
             
             $data=[
                    'order'=>$prod_sale_data,
                     'regular'=>$regular,
                     'town_name'=>$town_name,
                    // 'cust_name'=>$cust_name,
                    // 'cust_num'=>$cust_num,
                    // 'ntn'=>$ntn,
                    // 'cnic'=>$cnic,
                    // 'order_invoice'=>$order_invoice,
                    //  'order_date'=>$order_date,
                    // 'cust_address'=>$cust_address,
                    // 'cust_city'=>$cust_city,
                    // 'cust_state'=>$cust_state,
                    // 'cust_pakistan'=>$cust_pakistan,
                    // 'cust_phone'=>$cust_phone,
                ];

                
              }
              
 
             
                $pdf = PDF::loadView('sale.printing_invoices',$data);
        $pdf->setPaper('A4', 'Portriate');
 
        return $pdf->stream("Invoce.pdf");
    } catch(Exception $e)
    {
    
        $s = $e->getMessage();
        
        $d=$s;
    }
      
                
              //   $pdf = PDF::loadView('sale.index1',$data);
              //   $pdf->setPaper('A4', 'Portriate');
              //   // return $pdf->download("Invoce.pdf");
              //   $path = public_path('invoice_data/');
              //   $pdf->save($path.$order_invoice.'.pdf'); 
              //   $files[] = $path.$order_invoice.'.pdf';
              // //  return view("sale.index1",$data); 
             
             // dd($files[0]);
      

       
      // return response()->json(['files' => $files]);

       

       //downloadfile();
      
}

   

public function printing_invoice(Request $request)
    { 
        try
        {

       
        // setQueryLog();
        $inv_year = $request->inv_year;
        $inv_from = $request->from;
        $inv_to = $request->to;
        $inv_type = $request->inv_type;

        $prod_sale= Product_Sale::with([
          'orderdetail'=>function($query){$query->with(
            ['Product','Product.category']);}
          ,'customer'=>function($query){$query->with('town');}])
         ->whereRaw("SUBSTRING_INDEX(SUBSTRING_INDEX(invoice,'-',2),'-',-1)='" . $inv_type ."'")
         ->whereRaw("Convert(SUBSTRING_INDEX(SUBSTRING_INDEX(invoice,'-',-2),'-',1),SIGNED)=" . $inv_year)
         ->whereRaw("convert(SUBSTRING_INDEX(invoice,'-',-1),SIGNED) > " . $inv_from)
         ->whereRaw("convert(SUBSTRING_INDEX(invoice,'-',-1),SIGNED) < " . $inv_to)
         ->orderByRaw("convert(SUBSTRING_INDEX(invoice,'-',-1),SIGNED) ASC")
        ->get();
                
       //dd($prod_sale);
              
              $regular= "S-F";
                $data=[
                    'order'=>$prod_sale,
                    'regular'=>$regular,
                ];
 

                

                $pdf = PDF::loadView('sale.print_invoice',$data);
        $pdf->setPaper('A4', 'Portriate');
 
        return $pdf->stream("Invoce.pdf");
    } catch(Exception $e)
    {
    
        $s = $e->getMessage();
        
        $d=$s;
    }
         
    
    }

    
}

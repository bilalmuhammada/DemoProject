<?php

namespace App\Http\Controllers;

use App\Zone;
use App\Http\Requests\StoreZoneRequest;
use App\Http\Requests\UpdateZoneRequest;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Auth;
use Illuminate\Http\Request;
class ZoneController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('unit')) {
            $techxa_zone_all = Zone::where('is_active', true)->get();
            return view('zone.create', compact('techxa_zone_all'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreZoneRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'zone_name' => [
                'max:255',
                    Rule::unique('zones')->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
            'zone_code' => [
                'max:255',
                    Rule::unique('zones')->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
        ]);
        $input = $request->all();
        $input['is_active'] = true;
        Zone::create($input);
        return redirect('zone')->with('message', 'Data inserted successfully');
    }


    public function deleteBySelection(Request $request)
    {
        $zone_id = $request['zoneIdArray'];
        foreach ($zone_id as $id) {
            $techxa_zone_data = Zone::find($id);
            $techxa_zone_data->is_active = false;
            $techxa_zone_data->save();
        }
        return 'Zones deleted successfully!';
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function show(Zone $zone)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $techxa_zone_data = Zone::findOrFail($id);
        return $techxa_zone_data;
    }
   
    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateZoneRequest  $request
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $this->validate($request, [
            'zone_name' => [
                'max:255',
                Rule::unique('zones')->ignore($request->zone_id)->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
            'zone_code' => [
                'max:255',
                Rule::unique('zones')->ignore($request->zone_id)->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
        ]);
        $input = $request->all();
        $techxa_zone_data = Zone::find($input['zone_id']);
        // setQueryLog();
        $techxa_zone_data->update($input);
        // dd(getQueryLog());
        return redirect('zone')->with('message', 'Data updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $techxa_zone_data = Zone::find($id);
        $techxa_zone_data->is_active = false;
        $techxa_zone_data->save();
        return redirect('zone')->with('not_permitted', 'Data deleted successfully');
    }


    public function importzone(Request $request)
    { 
        $upload=$request->file('file');

      
        $ext = pathinfo($upload->getClientOriginalName(), PATHINFO_EXTENSION);
        if($ext != 'csv')
            return redirect()->back()->with('not_permitted', 'Please upload a CSV file');
        $filename =  $upload->getClientOriginalName();
        $upload=$request->file('file');
        $filePath=$upload->getRealPath();
        //open and read
        $file=fopen($filePath, 'r');
        $header= fgetcsv($file);
        $escapedHeader=[];
        //validate
        foreach ($header as $key => $value) {
            $lheader=strtolower($value);
            $escapedItem=preg_replace('/[^a-z]/', '', $lheader);
            array_push($escapedHeader, $escapedItem);
        }
        //looping through othe columns
        while($columns=fgetcsv($file))
        {
            if($columns[0]=="")
                continue;
            foreach ($columns as $key => $value) {
                $value=preg_replace('/\D/','',$value);
            }
           $data= array_combine($escapedHeader, $columns);
//dd($data);
//$zone=Zone::where('name', $data['zonename'])->first();
// $input['qty_list'] =$data['qty']+$prod_id->qty_list;
//        Product::where('id', $prod_id->id)->update($input);
//dd($prod_id);
 //$qty=Product::where('id', $data['product_id'])->first();
       // dd($qty->qty_list);
        
           $lims_zone_data=  Zone::firstOrNew(['zone_name'=>$data['zonename']]);
           $lims_zone_data->zone_code =$data['code'];
           $lims_zone_data->zone_name =$data['zonename'];
           $lims_zone_data->is_active =1;
          // $lims_product_data->distributor_margin =$data['distributormargin'];
           
          
           $lims_zone_data->save();
           
        }
        return redirect('zone')->with('message', 'Zone imported successfully');
    }
}

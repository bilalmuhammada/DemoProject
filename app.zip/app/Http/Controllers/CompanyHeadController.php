<?php

namespace App\Http\Controllers;
use App\Account_head;

use App\Distributor;
use App\Zone;
use App\CustomerGroup;
use App\Town;
use App\Http\Requests\StoreZoneRequest;
use App\Http\Requests\UpdateZoneRequest;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Auth;
use App\Company_Head;
use Illuminate\Http\Request;

class CompanyHeadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('unit')) {
            $distributer_all = Distributor::get();
            $town_all = Town::get();
            $custgrp_all = CustomerGroup::get();
            $company_head=Company_Head::get();
 
            return view('company_head.create', 
            ['distributer_all'=>$distributer_all,
            'town_all'=> $town_all,
            'company_head'=>$company_head,
            'custgrp_all'=> $custgrp_all,
            
         ]);
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }
 
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
 
    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreZoneRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'ACHName' => [
                'max:255',
                    Rule::unique('account_heads')->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
           
        ]);
        $input = $request->all();
    
        $model = new Company_Head();
     //   $model->ACHCode =$input['ac_code'];
        $model->company_head =$input['company_head'];
       // $model->HeadType =$input['online'];
       
       
        $model->save();
        return redirect('company_head')->with('message', 'Data inserted successfully');
    }
 
 
    public function deleteBySelection(Request $request)
    {
        $distributer_id = $request['zoneIdArray'];
        foreach ($zone_id as $id) {
            $Distributor_data = Company_Head::find($id);
            $Distributor_data->is_active = false;
            $Distributor_data->save();
        }
        return 'Distributor deleted successfully!';
    }
 
    /**
     * Display the specified resource.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function show(Zone $zone)
    {
        //
    }
 
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $techxa_zone_data = Company_Head::findOrFail($id);
        return $techxa_zone_data;
    }
   
    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateZoneRequest  $request
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $input = $request->all();

//dd(  $input);
        // $this->validate($request, [
        //     'company_head' => [
        //         'max:255',
        //         Rule::unique('company_head')->ignore($input['id'])->where(function ($query) {
        //             return $query->where('is_active', 1);
        //         }),
        //     ],
           
        // ]);
        $input = $request->all();
       
        $company_head= Company_Head::find($input['id']);
        // setQueryLog();
        $company_head->update($input);
        // dd(getQueryLog());
        return redirect('company_head')->with('message', 'Data updated successfully');
    }
 
    
    public function destroy($id)
    {
        $company_head = Company_Head::find($id);
        // $company_head->is_active = false;
        $company_head->delete();
        return redirect('company_head')->with('not_permitted', 'Data deleted successfully');
    }
}

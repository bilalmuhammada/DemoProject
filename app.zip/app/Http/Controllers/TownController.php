<?php

namespace App\Http\Controllers;

use App\Town;
use App\Territory;
use App\Http\Requests\StoreTownRequest;
use App\Http\Requests\UpdateTownRequest;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Auth;
use Illuminate\Http\Request;

class TownController extends Controller
{ /**
    * Display a listing of the resource.
    *
    * @return \Illuminate\Http\Response
    */
   public function index()
   {
       $role = Role::find(Auth::user()->role_id);
       if($role->hasPermissionTo('unit')) {

        //    setQueryLog();
           $techxa_town_all = Town::where('is_active', true)->with('territory')->get();
        //    dd(getQueryLog());
        //    dd($techxa_town_all);

           return view('town.create', compact('techxa_town_all'));
       }
       else
           return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
   }

   /**
    * Show the form for creating a new resource.
    *
    * @return \Illuminate\Http\Response
    */
   public function create()
   {
       //
   }

   /**
    * Store a newly created resource in storage.
    *
    * @param  \App\Http\Requests\StoreTownRequest  $request
    * @return \Illuminate\Http\Response
    */
   public function store(Request $request)
   {
       $this->validate($request, [
           'town_name' => [
               'max:255',
                   Rule::unique('towns')->where(function ($query) {
                   return $query->where('is_active', 1);
               }),
           ],
           'town_code' => [
               'max:255',
                   Rule::unique('towns')->where(function ($query) {
                   return $query->where('is_active', 1);
               }),
           ],
       ]);
       $input = $request->all();

       //dd($input);
       $input['is_active'] = true;
       Town::create($input);
       return redirect('town')->with('message', 'Data inserted successfully');
   }


   public function deleteBySelection(Request $request)
   {
       $town_id = $request['townIdArray'];
       foreach ($town_id as $id) {
           $techxa_town_data = Town::find($id);
           $techxa_town_data->is_active = false;
           $techxa_town_data->save();
       }
       return 'Towns deleted successfully!';
   }

   /**
    * Display the specified resource.
    *
    * @param  \App\Town  $town
    * @return \Illuminate\Http\Response
    */
   public function show(Town $town)
   {
       //
   }

   /**
    * Show the form for editing the specified resource.
    *
    * @param  \App\Town  $town
    * @return \Illuminate\Http\Response
    */
   public function edit($id)
   {
       $techxa_town_data = Town::findOrFail($id);
       return $techxa_town_data;

   }
  
   /**
    * Update the specified resource in storage.
    *
    * @param  \App\Http\Requests\UpdateTownRequest  $request
    * @param  \App\Town  $town
    * @return \Illuminate\Http\Response
    */
   public function update(Request $request, $id)
   {

       $this->validate($request, [
           'town_name' => [
               'max:255',
               Rule::unique('towns')->ignore($request->town_id)->where(function ($query) {
                   return $query->where('is_active', 1);
               }),
           ],
           'town_code' => [
               'max:255',
               Rule::unique('towns')->ignore($request->town_id)->where(function ($query) {
                   return $query->where('is_active', 1);
               }),
           ],
       ]);
       $input = $request->all();
       $techxa_town_data = Town::find($input['town_id']);
       // setQueryLog();
       $techxa_town_data->update($input);
       // dd(getQueryLog());
       return redirect('town')->with('message', 'Data updated successfully');
   }

   /**
    * Remove the specified resource from storage.
    *
    * @param  \App\Town  $town
    * @return \Illuminate\Http\Response
    */
   public function destroy($id)
   {
       $techxa_town_data = Town::find($id);
       $techxa_town_data->is_active = false;
       $techxa_town_data->save();
       return redirect('town')->with('not_permitted', 'Data deleted successfully');
   }


   public function importtown(Request $request)
   { 
       $upload=$request->file('file');

     
       $ext = pathinfo($upload->getClientOriginalName(), PATHINFO_EXTENSION);
       if($ext != 'csv')
           return redirect()->back()->with('not_permitted', 'Please upload a CSV file');
       $filename =  $upload->getClientOriginalName();
       $upload=$request->file('file');
       $filePath=$upload->getRealPath();
       //open and read
       $file=fopen($filePath, 'r');
       $header= fgetcsv($file);
       $escapedHeader=[];
       //validate
       foreach ($header as $key => $value) {
           $lheader=strtolower($value);
           $escapedItem=preg_replace('/[^a-z]/', '', $lheader);
           array_push($escapedHeader, $escapedItem);
       }
       //looping through othe columns
       while($columns=fgetcsv($file))
       {
           if($columns[0]=="")
               continue;
           foreach ($columns as $key => $value) {
               $value=preg_replace('/\D/','',$value);
           }
          $data= array_combine($escapedHeader, $columns);
//dd($data);
// $prod_id=Product::where('name', $data['productname'])->first();
// $input['qty_list'] =$data['qty']+$prod_id->qty_list;
//       Product::where('id', $prod_id->id)->update($input);
//dd($prod_id);
//$qty=Product::where('id', $data['product_id'])->first();
      // dd($qty->qty_list);
       
          $lims_Town_data= Town::firstOrNew(['town_name'=>$data['townname']]);
          $lims_Town_data->territory_name =$data['territortname'];
          $lims_Town_data->town_code =$data['towncode'];
          $lims_Town_data->town_name =$data['townname'];
          $lims_Town_data->is_active =1;
         // $lims_product_data->distributor_margin =$data['distributormargin'];
          
         
          $lims_Town_data->save();
          
       }
       return redirect('town')->with('message', 'Price Structure imported successfully');
   }
}

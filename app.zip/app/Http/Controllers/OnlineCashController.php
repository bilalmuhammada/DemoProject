<?php

namespace App\Http\Controllers;

use App\Online_cash;
use App\Ledger;
use Illuminate\Http\Request;
use App\Distributor;
use App\Http\Requests\StoreZoneRequest;
use App\Http\Requests\UpdateZoneRequest;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;
use App\Zone;
use App\CustomerGroup;
use App\Customer;
use App\Town;
use App\Company_Head;
use App\Account_head;
use App\Warehouse;
use Spatie\Permission\Models\Permission;
use Auth;
class OnlineCashController extends Controller
{
    public function index(Request $request)
    {
        $start_date=$request->start_date;
        $end_date=$request->end_date;

        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('unit')) {
           
           
            $distributer_all = Customer::orderBy('id',"DESC")->where('is_active',1)->with('town')->get();

            // dd(  $distributer_all );
            $town_all = Town::get();
            $custgrp_all = CustomerGroup::get();
            $Account_head = Account_head::get();
            $companyhead = Company_Head::get();
            $warehouse_all = Warehouse::where('is_active',1)->get();

            if($start_date!=null && $end_date!=null )
            {
                $onlinecash = Online_cash::orderBy('id',"DESC")->whereBetween('recdate',[$start_date,$end_date])->with('accounthead')->with('Customer')->get();

               
            }else{
                $start_date=date('Y-m-01');
                $end_date=date('Y-m-t');
                $onlinecash = Online_cash::orderBy('id',"DESC")->whereBetween('recdate',[$start_date,$end_date])->with('accounthead')->with('Customer')->get();

                
            }



            return view('Online_cash.create', 
            [
            'distributer_all'=>$distributer_all,
            'onlinecash'=> $onlinecash,
            'town_all'=> $town_all,
            'warehouse_all'=> $warehouse_all,
            'companyhead'=>$companyhead,
            'start_date'=>$start_date,
            'end_date'=> $end_date,
            'Account_head'=>$Account_head,
            'custgrp_all'=> $custgrp_all,
            
         ]);
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }
 
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
 
    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreZoneRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $input = $request->all();
        $cust6=Customer::where('id', $input['distr_id'])->first();
        if($input['warehouse_id']!=null){
    

            $cust=Customer::where('warehouse_id', $input['warehouse_id'])->first();
        
        
            $supervised_town=    Town::where('id', $cust6->city)->first();
            $model12 = new Ledger();
            $model12->baltype =$input['balancetype'];
            $model12->moneymean =$input['online'];
            $model12->voucherid =$input['voucher'];
            $model12->recdate =$input['recdate'];
            $model12->type =2;
            $model12->distid =$cust->id;
            $model12->discribtion =$cust6->distribution_name;
            $model12->dis_address =$input['dis_address'];
            $model12->acchead =$input['acchead_id'];
            $model12->amount =$input['amount'];
            $model12->save();
        
        }
        

     
      
        $model = new Online_cash();
        $model1 = new Ledger();
        $model->baltype =$input['balancetype'];
        $model->moneymean =$input['online'];
        $model->voucherid =$input['voucher'];
        $model->recdate = $input['recdate'];
        
        $model->distid =$input['distr_id'];
        $model->discribtion =$input['discribtion'];
        
        $model->dis_address =$input['dis_address'];
        $model->acchead =$input['acchead_id'];
      
        $model->amount =$input['amount'];
      

        $model1->discribtion =$input['discribtion'];
        $model1->baltype =$input['balancetype'];
        $model1->moneymean =$input['online'];
        $model1->voucherid =$input['voucher'];
        $model1->recdate = $input['recdate'] ;
        $model1->type =2;
        
        $model1->distid =$input['distr_id'];
        $model1->dis_address =$input['dis_address'];
        $model1->discribtion =$cust6->distribution_name;
        $model1->acchead =$input['acchead_id'];
        
        $model1->amount =$input['amount'];
        
        $model->save();

        $model1->save();
        return redirect('online_cash')->with('message', 'Data inserted successfully');
    }
 
 
    public function deleteBySelection(Request $request)
    {
        $distributer_id = $request['zoneIdArray'];
        foreach ($zone_id as $id) {
            $Distributor_data = Online_cash::find($id);
            $Distributor_data->is_active = false;
            $Distributor_data->save();
        }
        return 'Distributor deleted successfully!';
    }
 
    /**
     * Display the specified resource.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function show(Zone $zone)
    {
        //
    }
 
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        

        // if ($id > 0) {

        //     $arr = Online_cash::where(['id' => $id])->get();
        //     $result['recdate'] =  $arr['0']->recdate;
        //     $result['distid'] =  $arr['0']->distid;
        //     $result['discribtion'] =  $arr['0']->discribtion;
        //     $result['acchead'] =  $arr['0']->acchead;
        //     $result['amount'] =  $arr['0']->amount;
        //     $result['baltype'] =  $arr['0']->balancetype;
        //     $result['online'] =  $arr['0']->moneymean;
        //     $result['voucher'] =  $arr['0']->voucherid;
        //     $result['id'] =  $arr['0']->id;

        //     // $result['ishomecheck'] =  '';
        //     // if ($arr['0']->ishome == 1) {
        //     //     $result['ishomecheck'] =  'checked';
        //     // }
        //     // $result['id'] =  $arr['0']->id;
        //     // $result['data'] = Category::where(['stutus' => 1])->where('id', '!=', $id)->get();
        //     //dd($result);
        // } else {
        //     $result['recdate'] =  "";
        //     $result['distid'] =  ""; 
        //     $result['discribtion'] =  "";
        //     $result['acchead'] = "";
        //     $result['amount'] =  "";
        //     $result['baltype'] =  "";
        //     $result['online'] =  "";
        //     $result['voucher'] =  "";
            
        //     $result['id'] = 0;
        // }
     
       // dd($id);
        $result['id'] =$id;
        $result['online_data'] = Online_cash::findOrFail($id);
        //$result['ledger'] = Ledger::findOrFail($id);

       // dd($result);
       $result['onlinecash'] = Online_cash::get();
       $result['distributer_all']  = Customer::where('is_active',1)->get();
       $result['town_all']  = Town::get();
    
       $result['warehouse_all']= Warehouse::where('is_active',1)->get();
       $result['custgrp_all']  = CustomerGroup::get();
       $result['Account_head']  = Account_head::get();
       $result['companyhead']  = Company_Head::get();
      // dd( $result);
        return view('Online_cash.edit',  
            $result    
         );
        
    }
   
    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateZoneRequest  $request
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

 
        $input = $request->all();
      

$model=[];
$model1=[];



        // $model = new Online_cash();
        // $model1 = new Ledger();
        // $cust=Customer::where('id', $input['distr_id'])->first();
        

        $cust6=Customer::where('id', $input['distr_id'])->first();
        $model['baltype'] =$input['balancetype'];
        $model['moneymean'] =$input['online'];
        
        $model['voucherid']=$input['voucher'];
        $model['recdate'] =$input['recdate'];
        
        $model['distid']=$input['distr_id'];
        $model['dis_address'] =$input['dis_address'];
        $model['discribtion'] =$input['discribtion'];
        $model['acchead']=$input['acchead_id'];
       
        $model['amount'] =$input['amount'];

        $model1['baltype'] =$input['balancetype'];
        $model1['moneymean'] =$input['online'];
        $model1['voucherid'] =$input['voucher'];
        $model1['recdate'] =$input['recdate'];
        
        $model1['distid']=$input['distr_id'];
        $model1['type']=2;
        // $model1['discribtion'] =$input['dis_address'];
       // $model1['discribtion'] =$input['discribtion'];
        
        $model1['discribtion'] =$cust6->distribution_name;
        $model1['acchead']=$input['acchead_id'];
        
        $model1['amount'] =$input['amount'];

// dd($model1,$model,$model12);
        Online_cash::where('id', $input['id'])->update($model);


        Ledger::where('voucherid',$input['voucher'])->where('distid', $input['distr_id'])->update($model1);
        


       

        if($input['warehouse_id']!=null){
    

            $cust=Customer::where('warehouse_id', $input['warehouse_id'])->first();
            $Ledger=Ledger::where('voucherid', $input['voucher'])->where('distid',$cust->id)->first();
        
            $model12=[];
            $supervised_town=    Town::where('id', $cust6->city)->first();
            // $model12 = new Ledger();
            $model12['baltype'] =$input['balancetype'];
            $model12['moneymean'] =$input['online'];
            $model12['voucherid'] =$input['voucher'];
            $model12['recdate'] =$input['recdate'];
            $model12['type']=2;
            $model12['distid'] =$cust->id;
            // $model12['discribtion'] =$supervised_town->town_name;
            $model12['discribtion'] =$cust6->distribution_name;
            $model12['dis_address'] =$input['dis_address'];
            $model12['acchead'] =$input['acchead_id'];
            $model12['amount'] =$input['amount'];

          
            if(isset($Ledger)){
                Ledger::where('voucherid',$input['voucher'])->where('distid', $cust->id)->update($model12);
            }else{
                Ledger::insert($model12);
            }
           
        
        
         }
     
       


        return redirect('online_cash')->with('message', 'update inserted successfully');
        //dd($input);
        // $this->validate($request, [
        //     'DistributorName' => [
        //         'max:255',
        //         Rule::unique('zones')->ignore($request->zone_id)->where(function ($query) {
        //             return $query->where('is_active', 1);
        //         }),
        //     ],
           
        // ]);
        
    }
 
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $online_data = Online_cash::find($id);

       // dd($online_data->voucherid);
        

       // $distributor_data->is_active = false;
       $online_data->delete();
       Ledger::where('voucherid',$online_data->voucherid)->delete();
       
        return redirect('online_cash')->with('not_permitted', 'Data deleted successfully');
    }

    public function show_address(Request $request)
    {

      
        // $distributor_data = Customer::where($id);
        $distributer_all = Customer::where('is_active',1)->where('id',$request->id)->first();
       // $distributor_data->is_active = false;
       return  $distributer_all;
        
    }
    public function get_voucher()
    {
        $month = date('m');
        $year = date('y');

       
        $Online_cash = Online_cash::latest()->first();
      
       
        if($Online_cash!=null)
        {
            $counter_val = sprintf('%05d', $Online_cash->id+1);

            $online_cash=   $month . '-' . $year . '-'.$counter_val;
        }
        else{
            $online_cash=1;
        }
       

       
       return  $online_cash;
        
    }

    
    
}

<?php

namespace App\Http\Controllers;

use App\DeliveryName;
use App\sector;
use Illuminate\Http\Request;

use App\local_distr_orderdetail;
use App\local_distr_return_orderdetails;
use App\local_distr_product_sales;
use App\cr;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\shops;
use Auth;
use App\Roles;
use DB;
use App\Customer;
use App\orderBooker;
use App\sub_distributor_ledger;
use App\Warehouse;

class DeliveryNameController extends Controller
{
	public function index()
	{
		$role = Role::find(Auth::user()->role_id);
		if($role->hasPermissionTo('local_system')){
			$permissions = Role::findByName($role->name)->permissions;
			foreach ($permissions as $permission)
				$all_permission[] = $permission->name;
			if(empty($all_permission))
				$all_permission[] = 'dummy text';
			// $lims_shops_all = shops::get();
			$lims_deliveryname_all = DeliveryName::get();
			$sector = sector::get();
		   
			return view('local_distributor.deliveryname.create', compact('lims_deliveryname_all','sector', 'all_permission'));
		}
		else
			return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		$role = Role::find(Auth::user()->role_id);
		if($role->hasPermissionTo('local_system') ||$role->hasPermissionTo('users-add') ){
			// $lims_customer_group_all = CustomerGroup::where('is_active',true)->get();
			// $town = Town::get();
			$lims_role_list = Roles::where('is_active', true)->get();
			$customer = Customer::where('is_active', true)->get();
			$warehouse = Warehouse::where('is_active', true)->get();
			return view('local_distributor.orderbooker.create', compact('warehouse','customer','town','lims_role_list'));
		}
		else
			return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
	}

	public function importdeliveryman(Request $request){


        $filename =  $request->file->getClientOriginalName();
        $upload=$request->file('file');
        $filePath=$upload->getRealPath();
        //open and read
        $file=fopen($filePath, 'r');
        $header= fgetcsv($file);
        $escapedHeader=[];
        //validate
        foreach ($header as $key => $value) {
            $lheader=strtolower($value);
            $escapedItem=preg_replace('/[^a-z]/', '', $lheader);
            array_push($escapedHeader, $escapedItem);
        }
        //looping through othe columns
        $lims_deliveryman_data = [];
        while($columns=fgetcsv($file))
        {
            if($columns[0]=="")
                continue;
            foreach ($columns as $key => $value) {
                $value=preg_replace('/\D/','',$value);
            }
            $data= array_combine($escapedHeader, $columns);

            dd($data);
            $deliveryname = DeliveryName::firstOrNew(['emp_code' => $data['code'],'is_active' => true ]);
            $deliveryname->code = $data['code'];
            $deliveryname->code = $data['name'];
           
            $deliveryname->save();
        }
        return redirect('deliveryman')->with('message', 'deliveryman imported successfully');
    }


	
	public function store(Request $request)
	{
		//
		$data = $request->all();

		
		 $data['dist_id']= session('logged_session_data.customer_id');
	
		  $data['sector'] = implode(",",$data['sector']);
		$shops=   DeliveryName::create($data);

		$message='Create Successfully';
		return redirect('deliveryman')->with('create_message', $message);
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  \App\cr  $cr
	 * @return \Illuminate\Http\Response
	 */
	public function show(cr $cr)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  \App\cr  $cr
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id)
	{
		$techxa_shop_data = DeliveryName::findOrFail($id);
	   return $techxa_shop_data;
		//
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \App\cr  $cr
	 * @return \Illuminate\Http\Response
	 */
	public function update(Request $request)
	{
		$input = $request->all();
		///dd($input);
	   $techxa_town_data = DeliveryName::find($input['id']);
	   // setQueryLog();
	   $input['dist_id']= session('logged_session_data.customer_id');
	   $techxa_town_data->update($input);
	   // dd(getQueryLog());
	   return redirect('deliveryman')->with('message', 'Data updated successfully');
		//
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  \App\cr  $cr
	 * @return \Illuminate\Http\Response
	 */
	public function destroy(Request $request, $id)
	{
		$techxa_town_data = DeliveryName::find($id);
		$techxa_town_data->is_active = false;
		$techxa_town_data->save();
		return redirect('deliveryman')->with('not_permitted', 'Data deleted successfully');
	}



	

	function  print_history_loadpass(Request $request) 
{
		

	  
	
		
// dd($request->all());



$recent_sale=[];
$orderBooker='';
$lims_deliveryname_all='';
 $start_date= $request->start_date  ;
 $end_date=   $request->end_date ;

//  dd($request->mdo_id);
$orderBooker_id=$request->mdo_id;
 $dm_id=    $request->dm_id;
 $payment_type=    1;

 $orderbookerman='';
 $orderbookerphone='';
 $deliverman='';
 $deliverphone='';
 if($payment_type==1){
  if($start_date!=null && $dm_id!=null && $orderBooker_id!=null ){

$recent_sale=DB::table('local_distr_product_sales')
						 ->join('local_distr_orderdetails', 'local_distr_product_sales.id', '=', 'local_distr_orderdetails.prod_sale_id')
						 ->whereDate('local_distr_product_sales.created_at', '=', $start_date)
						 //   ->whereDate('product_adjustments.created_at', '>=', $start_date)
						 //   ->whereDate('product_adjustments.created_at', '<=' , $end_date)
						   ->where('local_distr_product_sales.dm_id', $dm_id)
						   ->where('local_distr_product_sales.orderbooker_id', $orderBooker_id)
						   ->select(DB::raw('local_distr_product_sales.qty,local_distr_orderdetails.valueoffer,local_distr_orderdetails.tval_tradeoff,local_distr_orderdetails.tp_price,sum(local_distr_orderdetails.total_discount) as total_discount,local_distr_orderdetails.prod_id,local_distr_orderdetails.returnqty,local_distr_orderdetails.returnctn,local_distr_product_sales.orderbooker_id,local_distr_product_sales.dm_id,sum(local_distr_orderdetails.qty) as sold_qty'))->groupBy('prod_id')->get();
 
						$lims_deliveryname_all=   DeliveryName::where('id',$dm_id)->first();
						$deliverman=$lims_deliveryname_all->name;
                        $deliverphone=$lims_deliveryname_all->phone_number;
						$orderBooker=   orderBooker::where('id',$orderBooker_id)->first();
						$orderbookerman=$orderBooker->name;
						$orderbookerphone=$orderBooker->phone_number;

// dd($recent_sale);

}else if($start_date!=null && $dm_id!=null && $orderBooker_id==null){

	$recent_sale=DB::table('local_distr_product_sales')
						 ->join('local_distr_orderdetails', 'local_distr_product_sales.id', '=', 'local_distr_orderdetails.prod_sale_id')
						 ->whereDate('local_distr_product_sales.created_at', '=', $start_date)
						 //   ->whereDate('product_adjustments.created_at', '>=', $start_date)
						 //   ->whereDate('product_adjustments.created_at', '<=' , $end_date)
						   ->where('local_distr_product_sales.dm_id', $dm_id)
						//    ->where('local_distr_product_sales.orderbooker_id', $orderBooker_id)
						   ->select(DB::raw('local_distr_product_sales.qty,local_distr_orderdetails.valueoffer,local_distr_orderdetails.tval_tradeoff,local_distr_orderdetails.tp_price,sum(local_distr_orderdetails.total_discount) as total_discount,local_distr_orderdetails.prod_id,local_distr_orderdetails.returnqty,local_distr_orderdetails.returnctn,local_distr_product_sales.orderbooker_id,local_distr_product_sales.dm_id,sum(local_distr_orderdetails.qty) as sold_qty'))->groupBy('prod_id')->get();
 
						$lims_deliveryname_all=   DeliveryName::where('id',$dm_id)->first();
						
				  
						if($recent_sale!='[]'){
							$orderBooker=   orderBooker::where('id',$recent_sale[0]->orderbooker_id)->first();
							$orderbookerman=$orderBooker->name;
							$orderbookerphone=$orderBooker->phone_number;
							
							
						}
						else{
							$orderbookerman='';
							$orderbookerphone='';
						}


}else if($start_date!=null && $dm_id==null && $orderBooker_id!=null){

	$recent_sale=DB::table('local_distr_product_sales')
	->join('local_distr_orderdetails', 'local_distr_product_sales.id', '=', 'local_distr_orderdetails.prod_sale_id')
	->whereDate('local_distr_product_sales.created_at', '=', $start_date)
	//   ->whereDate('product_adjustments.created_at', '>=', $start_date)
	//   ->whereDate('product_adjustments.created_at', '<=' , $end_date)
	//   ->where('local_distr_product_sales.dm_id', $dm_id)
      ->where('local_distr_product_sales.orderbooker_id', $orderBooker_id)
	  ->select(DB::raw('local_distr_product_sales.qty,local_distr_orderdetails.valueoffer,local_distr_orderdetails.tval_tradeoff,local_distr_orderdetails.tp_price,sum(local_distr_orderdetails.total_discount) as total_discount,local_distr_orderdetails.prod_id,local_distr_orderdetails.returnqty,local_distr_orderdetails.returnctn,local_distr_product_sales.orderbooker_id,local_distr_product_sales.dm_id,sum(local_distr_orderdetails.qty) as sold_qty'))->groupBy('prod_id')->get();

	if($recent_sale!='[]'){
		$lims_deliveryname_all=   DeliveryName::where('id',$recent_sale[0]->dm_id)->firstOrFail();
		$deliverman=$lims_deliveryname_all->name;
   $deliverphone=$lims_deliveryname_all->phone_number;
	}
	else{
		$deliverman='';
		$deliverphone='';
	}
   
   $orderBooker=   orderBooker::where('id',$orderBooker_id)->first();

   


}


else{
 $end_date=date('Y-m-t');
$start_date=date('Y-m-01');
$lims_deliveryname_all=  '';
$orderBooker=  '';





}



}



$prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));

if( $start_date==null){
$start_date=date('Y-m-01');
}






$townName='';
$distributerName='';
$dm = DeliveryName::where('is_active',1)->get();

$orderBooker1 = orderBooker::where('is_active',1)->get();



return view('local_distributor.reports.loadpass
',[
'dm'=>$dm,


'payment_type'=>$payment_type,
'orderBooker1'=>$orderBooker1,
'dm_id'=>$dm_id,
'orderBooker_id'=>$orderBooker_id,

 'deliverman'=>$deliverman,
 'deliverphone'=>$deliverphone,
 'orderbookerman'=>$orderbookerman,
 'orderbookerphone'=>$orderbookerphone,

'customer'=>$distributerName,
'invoice'=>$recent_sale,
'orderBooker'=>$orderBooker,
'lims_deliveryname_all'=>$lims_deliveryname_all,

'prevdate'=>$prevdate,
'start_date'=>$start_date,



]);

}
function  print_history(Request $request) 
{
	
 

	$recent_sale=[];
   $orderBooker='';
   $lims_deliveryname_all='';
	$start_date= $request->start_date  ;

	$orderBooker_id=    $request->mdo_id;
	$dm_id=    $request->dm_id;
	$payment_type=    1;
	$orderbookerman='';
	$orderbookerphone='';
	$deliverman='';
	$deliverphone='';


	if($payment_type==1){
	 if($start_date!=null  && $dm_id!=null && $orderBooker_id!=null ){
   



$recent_sale=DB::table('local_distr_product_sales')
							->join('local_distr_orderdetails', 'local_distr_product_sales.id', '=', 'local_distr_orderdetails.prod_sale_id')
							 //->join('local_distr_return_orderdetails', 'local_distr_product_sales.id', '=', 'local_distr_return_orderdetails.prod_sale_id')
							 
							->whereDate('local_distr_product_sales.created_at', '=', $start_date)
							
							  
							
							  ->where('local_distr_product_sales.dm_id', $dm_id)
							  ->where('local_distr_product_sales.orderbooker_id', $orderBooker_id)
							  ->select(DB::raw('local_distr_product_sales.qty,local_distr_product_sales.invoice_no,local_distr_orderdetails.valueoffer,local_distr_orderdetails.tval_tradeoff,local_distr_orderdetails.tp_price,sum(local_distr_orderdetails.total_discount) as total_discount,local_distr_orderdetails.prod_id,local_distr_orderdetails.returnqty,local_distr_orderdetails.returnctn,local_distr_product_sales.orderbooker_id,local_distr_product_sales.dm_id,sum(local_distr_orderdetails.qty) as sold_qty'))->groupBy('prod_id')->get();
	
						   $lims_deliveryname_all=   DeliveryName::where('id',$dm_id)->first();
						   $deliverman=$lims_deliveryname_all->name;
						   $deliverphone=$lims_deliveryname_all->phone_number;
						   $orderBooker=   orderBooker::where('id',$orderBooker_id)->first();
						   $orderbookerman=$orderBooker->name;
						   $orderbookerphone=$orderBooker->phone_number;
						
  }else if($start_date!=null && $dm_id!=null && $orderBooker_id==null){
  
	$recent_sale=DB::table('local_distr_product_sales')
	->join('local_distr_orderdetails', 'local_distr_product_sales.id', '=', 'local_distr_orderdetails.prod_sale_id')
	 //->join('local_distr_return_orderdetails', 'local_distr_product_sales.id', '=', 'local_distr_return_orderdetails.prod_sale_id')
	 
	->whereDate('local_distr_product_sales.created_at', '=', $start_date)
	
	  
	
	  ->where('local_distr_product_sales.dm_id', $dm_id)
	 
	  ->select(DB::raw('local_distr_product_sales.qty,local_distr_product_sales.invoice_no,local_distr_orderdetails.valueoffer,local_distr_orderdetails.tval_tradeoff,local_distr_orderdetails.tp_price,sum(local_distr_orderdetails.total_discount) as total_discount,local_distr_orderdetails.prod_id,local_distr_orderdetails.returnqty,local_distr_orderdetails.returnctn,local_distr_product_sales.orderbooker_id,local_distr_product_sales.dm_id,sum(local_distr_orderdetails.qty) as sold_qty'))->groupBy('prod_id')->get();





   $lims_deliveryname_all=   DeliveryName::where('id',$dm_id)->first();
//    dd($recent_sale);

   if($recent_sale!='[]'){
	   $orderBooker=   orderBooker::where('id',$recent_sale[0]->orderbooker_id)->first();
	   $orderbookerman=$orderBooker->name;
	   $orderbookerphone=$orderBooker->phone_number;
	   
	   
   }
   else{
	   $orderbookerman='';
	   $orderbookerphone='';
   }


  
  }else if($start_date!=null && $dm_id==null && $orderBooker_id!=null){
	$recent_sale=DB::table('local_distr_product_sales')
							->join('local_distr_orderdetails', 'local_distr_product_sales.id', '=', 'local_distr_orderdetails.prod_sale_id')
							 //->join('local_distr_return_orderdetails', 'local_distr_product_sales.id', '=', 'local_distr_return_orderdetails.prod_sale_id')
							 
							->whereDate('local_distr_product_sales.created_at', '=', $start_date)
							
							  
							
							//   ->where('local_distr_product_sales.dm_id', $dm_id)
							  ->where('local_distr_product_sales.orderbooker_id', $orderBooker_id)
							  ->select(DB::raw('local_distr_product_sales.qty,local_distr_product_sales.invoice_no,local_distr_orderdetails.valueoffer,local_distr_orderdetails.tval_tradeoff,local_distr_orderdetails.tp_price,sum(local_distr_orderdetails.total_discount) as total_discount,local_distr_orderdetails.prod_id,local_distr_orderdetails.returnqty,local_distr_orderdetails.returnctn,local_distr_product_sales.orderbooker_id,local_distr_product_sales.dm_id,sum(local_distr_orderdetails.qty) as sold_qty'))->groupBy('prod_id')->get();
	
	if($recent_sale!='[]'){
		$lims_deliveryname_all=   DeliveryName::where('id',$recent_sale[0]->dm_id)->firstOrFail();
		$deliverman=$lims_deliveryname_all->name;
   $deliverphone=$lims_deliveryname_all->phone_number;
	}
	else{
		$deliverman='';
		$deliverphone='';
	}
   
   $orderBooker=   orderBooker::where('id',$orderBooker_id)->first();

  } else{
	$end_date=date('Y-m-t');
   $start_date=date('Y-m-d');
   $lims_deliveryname_all=   DeliveryName::first();
   $orderBooker=   orderBooker::first();




  }
  
 

  }

 

  $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));

  if( $start_date==null){

   $end_date=date('Y-m-t');
   $start_date=date('Y-m-d');
}






$townName='';
$distributerName='';
 $dm = DeliveryName::where('is_active',1)->get();

 $orderBooker1 = orderBooker::where('is_active',1)->get();
 
 return view('local_distributor.reports.loadpass_or_dsr
 ',[
   'dm'=>$dm,
   
   'orderBooker1'=>$orderBooker1,
   'dm_id'=>$dm_id,
   'orderBooker_id'=>$orderBooker_id,
   'payment_type'=>$payment_type,
   'deliverman'=>$deliverman,
   'deliverphone'=>$deliverphone,
   'orderbookerman'=>$orderbookerman,
   'orderbookerphone'=>$orderbookerphone,
   'customer'=>$distributerName,
   'invoice'=>$recent_sale,
   
   'ordebooker_name'=>$orderBooker,
   'lims_deliveryname_all'=>$lims_deliveryname_all,
   
   'prevdate'=>$prevdate,
   'start_date'=>$start_date,



]);



}



//shop
public function local_print_history(Request $request){



	$recent_sale=[];
	$data=[];
    $start_date= $request->start_date  ;
    $end_date=   $request->end_date ;
	$deliveryname1='';
    $dm_id=    $request->dm_id;
	$mdo_id=    $request->mdo_id;
	$invoicetype=    $request->invoiceType;

	 if($start_date!=null && $dm_id!=null && $invoicetype!=null && $mdo_id!=null){

$recent_sale = local_distr_product_sales::orderBy('id', 'desc')->whereDate('created_at',$start_date." 00:00:00")->where('dm_id',$dm_id)->where('orderbooker_id',$mdo_id)->with('local_distr_orderdetail')->where('token',$invoicetype)->where('status',1)->get();
$shop_data = shops::where('is_active',1)->get();


}else if( $start_date!=null && $dm_id!=null && $invoicetype!=null && $mdo_id==null){
	$recent_sale = local_distr_product_sales::orderBy('id', 'desc')->whereDate('created_at',$start_date." 00:00:00")->where('dm_id',$dm_id)->with('local_distr_orderdetail')->where('token',$invoicetype)->where('status',1)->get();
	$shop_data = shops::where('is_active',1)->get();
}
else if($start_date!=null && $dm_id==null && $invoicetype!=null && $mdo_id!=null){
	$recent_sale = local_distr_product_sales::orderBy('id', 'desc')->whereDate('created_at',$start_date." 00:00:00")->where('orderbooker_id',$mdo_id)->with('local_distr_orderdetail')->where('token',$invoicetype)->where('status',1)->get();
	$shop_data = shops::where('is_active',1)->get();
}

  else{$start_date=date('Y-m-d');
// $recent_sale = local_distr_product_sales::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->with('local_distr_orderdetail')->where('status',1)->get();
$shop_data = shops::where('is_active',1)->get();











  }
  
 

  

 

  $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));

  if($end_date==null && $start_date==null){

   $start_date=date('Y-m-d');
}





$deliveryname  = DeliveryName::get();
$townName='';
$distributerName='';
 $shops = shops::where('is_active',1)->get();
 $orderbooker = orderBooker::where('is_active',1)->get();

 return view('local_distributor.reports.local_print_history',[
	'deliveryname'=>$deliveryname,
	
	
	'orderbooker'=>$orderbooker,
	'shops'=>$shops,
	'mdo_id'=>$mdo_id,
	'dm_id'=>$dm_id,
	'distributerName'=>$distributerName,
	'invoice'=>$recent_sale,
	'ledger_bal'=>$data,
	'dm_id'=>$dm_id,
	'invoicetype'=>$request->invoiceType,
	// 'id'=>$id,
   'deliveryname11'=>'$deliveryname1->name',
	'prevdate'=>$prevdate,
	'start_date'=>$start_date,
   'end_date'=>$end_date,
 
 
 ]);
}




//Payement
public function local_print_history_payment(Request $request){



	$recent_sale=[];
	$data=[];
    $start_date= $request->start_date  ;
    $end_date=   $request->end_date ;
	$deliveryname1='';
    $invoice_type=    $request->invoice_type;
	$dm_id=    $request->dm_id;
	if($start_date!=null && $end_date!=null && $dm_id!=null){
   
   
$recent_sale = local_distr_product_sales::orderBy('id', 'desc')->where('created_at',$start_date." 00:00:00")->where('dm_id',$dm_id)->with('local_distr_orderdetail')->where('token',1)->where('status',1)->get();



$shop_data = shops::where('is_active',1)->get();
foreach($shop_data as $shop)
{
// $result['id']=  $customer->id;
    
     

$result['name']=  $shop->name;
// $result['town'] = Town::where('id',$customer->city)->pluck('town_name')->toArray();
$result['invoice'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',4)->sum('amount');


$result['criedit'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',2)->sum('amount');
$result['p.criedit'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',3)->sum('amount');

$result['recovery'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',5)->sum('amount');
$result['cashrec'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',1)->sum('amount');

$result['outstanding']=  ( $result['p.criedit'] +$result['recovery']+ $result['cashrec'])-($result['invoice']+$result['criedit']);



$data[]=$result;

}


	//  $ledger = sub_distributor_ledger::orderBy('recdate','ASC')
	
	//  ->whereRaw("recdate BETWEEN STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d') AND STR_TO_DATE('" . date('Y-m-d' , strtotime($end_date)) . "', '%Y-%m-%d')")
	//  ->get();

// dd(getQueryLog());
  }else{
    $end_date=date('Y-m-t');
   $start_date=date('Y-m-01');
   
// $recent_sale = local_distr_product_sales::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->with('local_distr_orderdetail')->where('status',1)->get();
$shop_data = shops::where('is_active',1)->get();

//$deliveryname1=DeliveryName::where('id',$recent_sale[0]->dm_id)->first();
//   dd();



foreach($shop_data as $shop)
{
// $result['id']=  $customer->id;
    
     
$result['id']=  $shop->id;
$result['name']=  $shop->name;
// $result['town'] = Town::where('id',$customer->city)->pluck('town_name')->toArray();
$result['invoice'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',4)->sum('amount');


$result['criedit'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',2)->sum('amount');
$result['p.criedit'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',3)->sum('amount');

$result['recovery'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',5)->sum('amount');
$result['cashrec'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',1)->sum('amount');

$result['outstanding']=  ( $result['p.criedit'] +$result['recovery']+ $result['cashrec'])-($result['invoice']+$result['criedit']);



$data[]=$result;

}






  }
  
 

  

 

  $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));

  if($end_date==null && $start_date==null){

   $end_date=date('Y-m-t');
   $start_date=date('Y-m-01');
}





$deliveryname  = DeliveryName::get();
$townName='';
$distributerName='';
 $shops = shops::where('is_active',1)->get();


 return view('local_distributor.reports.local_print_history_payment',[
	'deliveryname'=>$deliveryname,
	
	

	'shops'=>$shops,
	'invoice_type'=>$invoice_type,
	'distributerName'=>$distributerName,
	'invoice'=>$recent_sale,
	'ledger_bal'=>$data,
	'dm_id'=>$dm_id,

   'deliveryname11'=>'$deliveryname1->name',
	'prevdate'=>$prevdate,
	'start_date'=>$start_date,
   'end_date'=>$end_date,
 
 
 ]);
}


//Cash Recb



public function local_print_history_cash_recovery(Request $request){



	$recent_sale=[];
	$data=[];
    $start_date= $request->start_date  ;
    $end_date=   $request->end_date ;
	$deliveryname1='';
    $invoice_type=    $request->invoice_type;
	$dm_id=    $request->dm_id;
	if($start_date!=null && $end_date!=null && $invoice_type==null)
    {
 

///setQueryLog();

$recent_sale = local_distr_product_sales::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->with('local_distr_orderdetail')->where('token',1)->where('status',1)->get();
  


// dd($dm_id);
  //dd(getQueryLog());

 
  
  }else if($start_date!=null && $end_date!=null && $invoice_type!=null){
   
   
$recent_sale = local_distr_product_sales::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->where('account',$invoice_type)->with('local_distr_orderdetail')->where('token',1)->where('status',1)->get();



$shop_data = shops::where('is_active',1)->get();
foreach($shop_data as $shop)
{
// $result['id']=  $customer->id;
    
     

$result['name']=  $shop->name;
// $result['town'] = Town::where('id',$customer->city)->pluck('town_name')->toArray();
$result['invoice'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',4)->sum('amount');


$result['criedit'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',2)->sum('amount');
$result['p.criedit'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',3)->sum('amount');

$result['recovery'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',5)->sum('amount');
$result['cashrec'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',1)->sum('amount');

$result['outstanding']=  ( $result['p.criedit'] +$result['recovery']+ $result['cashrec'])-($result['invoice']+$result['criedit']);



$data[]=$result;

}


	//  $ledger = sub_distributor_ledger::orderBy('recdate','ASC')
	
	//  ->whereRaw("recdate BETWEEN STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d') AND STR_TO_DATE('" . date('Y-m-d' , strtotime($end_date)) . "', '%Y-%m-%d')")
	//  ->get();

// dd(getQueryLog());
  }else{
    $end_date=date('Y-m-t');
   $start_date=date('Y-m-01');
   
// $recent_sale = local_distr_product_sales::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->with('local_distr_orderdetail')->where('status',1)->get();
$shop_data = shops::where('is_active',1)->get();

//$deliveryname1=DeliveryName::where('id',$recent_sale[0]->dm_id)->first();
//   dd();



foreach($shop_data as $shop)
{
// $result['id']=  $customer->id;
    
     
$result['id']=  $shop->id;
$result['name']=  $shop->name;
// $result['town'] = Town::where('id',$customer->city)->pluck('town_name')->toArray();
$result['invoice'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',4)->sum('amount');


$result['criedit'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',2)->sum('amount');
$result['p.criedit'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',3)->sum('amount');

$result['recovery'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',5)->sum('amount');
$result['cashrec'] = sub_distributor_ledger::where('shop_id',$shop->id)->where('type',1)->sum('amount');

$result['outstanding']=  ( $result['p.criedit'] +$result['recovery']+ $result['cashrec'])-($result['invoice']+$result['criedit']);



$data[]=$result;

}






  }
  
 

  

 

  $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));

  if($end_date==null && $start_date==null){

   $end_date=date('Y-m-t');
   $start_date=date('Y-m-01');
}





$deliveryname  = DeliveryName::get();
$townName='';
$distributerName='';
 $shops = shops::where('is_active',1)->get();


 return view('local_distributor.reports.local_print_history_cash_recovery',[
	'deliveryname'=>$deliveryname,
	
	

	'shops'=>$shops,
	'invoice_type'=>$invoice_type,
	'distributerName'=>$distributerName,
	'invoice'=>$recent_sale,
	'ledger_bal'=>$data,
	'dm_id'=>$dm_id,
	
   'deliveryname11'=>'$deliveryname1->name',
	'prevdate'=>$prevdate,
	'start_date'=>$start_date,
   'end_date'=>$end_date,
 
 
 ]);
}




public function print_inv_plus_load(Request $request){


	

	$data=explode("-",$request->inv_id);
       
          if($request->inv && $data[0]!='R'){
		  $prod_sale_data = local_distr_product_sales::where('invoice_no',$request->inv_id)->first();
          // dd($prod_sale_data);
              $order= local_distr_orderdetail::orderBy('prod_code','ASC')->orderBy('id',"ASC")->with('shop')->with('local_distr_product_sales')->with('product')->where('prod_sale_id',$prod_sale_data->id)
              
              ->with(['product'=>function($query){
                $query->with('category');
              }])
              
              ->get();

//  dd($order);
             
             $town_name=sector::where('id',$order[0]->shop->sectors)->first();
             $lims_orderBooker=orderBooker::where('id',$order[0]->local_distr_product_sales->orderbooker_id)->first();
             $lims_DeliveryName_list=DeliveryName::where('id',$order[0]->local_distr_product_sales->dm_id)->first();
        //    dd($lims_DeliveryName_list);     
              $order_date=$order[0]->local_distr_product_sales->created_at;
              $order_invoice=$order[0]->local_distr_product_sales->invoice;
              $cust_name= $order[0]->shop->name;
              $cust_address= $order[0]->shop->address;
              $ntn= 'null';
              $cust_city= $town_name->name;
              $lims_orderBooker_name= $lims_orderBooker->name;
              $orphone= $lims_orderBooker->phone_number;

              $lims_DeliveryName= $lims_DeliveryName_list->name;
              $dlphone= $lims_DeliveryName_list->phone_number;
              $invoice_no= $request->inv_id;
			  $customer_detail= Customer::where('id',session('logged_session_data.customer_id'))->firstOrFail();
            //   $cnic= $order[0]->customer->cnic;  
            //   $customer_group_id= $order[0]->customer->customer_group_id;  
                        
              
              $regular= "S-F";
                $data=[
					'customer_detail'=> $customer_detail,
                    'order'=>$order,
                    'regular'=>$regular,
                    'cust_name'=>$cust_name,
                     'invoice_no'=>$invoice_no,
                     'lims_orderBooker_name'=>$lims_orderBooker_name,
                     'orphone'=>$orphone,
                     'lims_DeliveryName'=>$lims_DeliveryName,
                     'dlphone'=>$dlphone,
                    'ntn'=>$ntn,
                    'request_id'=>2,
                    'order_invoice'=>$order_invoice,
                     'order_date'=>$order_date,
                    'cust_address'=>$cust_address,
                    'cust_city'=>$cust_city,
                  
                ];
               
                    return view("local_distributor.create_order.print_invoice",$data);
			}
			else {

				
				$prod_sale_data = local_distr_product_sales::where('invoice_no',$request->inv_id)->first();
				// dd($prod_sale_data);
					$order= local_distr_return_orderdetails::orderBy('prod_code','ASC')->orderBy('id',"ASC")->with('shop')->with('product')->where('prod_sale_id',$prod_sale_data->id)
					
					->with(['product'=>function($query){
					  $query->with('category');
					}])
					
					->get();
	  
	  //  dd($order);
				   
				   $town_name=sector::where('id',$order[0]->shop->sectors)->first();
				   $lims_orderBooker=orderBooker::where('id',$order[0]->local_distr_product_sales->orderbooker_id)->first();
				   $lims_DeliveryName_list=DeliveryName::where('id',$order[0]->local_distr_product_sales->dm_id)->first();
			  //    dd($lims_DeliveryName_list);     
					$order_date=$order[0]->local_distr_product_sales->created_at;
					$order_invoice=$order[0]->local_distr_product_sales->invoice;
					$cust_name= $order[0]->shop->name;
					$cust_address= $order[0]->shop->address;
					$ntn= 'null';
					$cust_city= $town_name->name;
					$lims_orderBooker_name= $lims_orderBooker->name;
					$orphone= $lims_orderBooker->phone_number;
	  
					$lims_DeliveryName= $lims_DeliveryName_list->name;
					$dlphone= $lims_DeliveryName_list->phone_number;
					$invoice_no= $request->inv_id;
					$customer_detail= Customer::where('id',session('logged_session_data.customer_id'))->firstOrFail();
				  //   $cnic= $order[0]->customer->cnic;  
				  //   $customer_group_id= $order[0]->customer->customer_group_id;  
							  
					
					$regular= "S-F";
					  $data=[
						  'customer_detail'=> $customer_detail,
						  'order'=>$order,
						  'regular'=>$regular,
						  'cust_name'=>$cust_name,
						   'invoice_no'=>$invoice_no,
						   'lims_orderBooker_name'=>$lims_orderBooker_name,
						   'orphone'=>$orphone,
						   'lims_DeliveryName'=>$lims_DeliveryName,
						   'dlphone'=>$dlphone,
						  'ntn'=>$ntn,
						  'request_id'=>2,
						  'order_invoice'=>$order_invoice,
						   'order_date'=>$order_date,
						  'cust_address'=>$cust_address,
						  'cust_city'=>$cust_city,
						
					  ];
					 
						  return view("local_distributor.create_order.print_invoice",$data);
			}

}



public function mdoExecution(Request $request){


	$mdoBilling_data = local_distr_product_sales::where('orderbooker_id',$request->orderbooker_id)->whereBetween('created_at',[$request->start_date." 00:00:00",$request->end_date." 23:59:59"])->where('token',1)->where('status',1)->get();
	// $prod_sale_data = local_distr_product_sales::where('orderbooker_id',$request->orderbooker_id)->whereBetween('created_at',[$request->start_date." 00:00:00",$request->end_date." 23:59:59"])->where('token',0)->get();


// dd($mdoBilling_data);
$start_date=date('Y-m-d');
$end_date=date('Y-m-d');
$orderbooker=orderBooker::all();
	
	// dd('hhh');
$data=[
'mdoBilling_data'=>$mdoBilling_data,
'start_date'=>$start_date,
'orderbooker'=>$orderbooker,
'end_date'=>$end_date
];

	return view("local_distributor.reports.excecution",$data);

}

}

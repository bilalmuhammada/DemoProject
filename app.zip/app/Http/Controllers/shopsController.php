<?php

namespace App\Http\Controllers;



use App\cr;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\shops;
use Auth;
use PDF;
use App\Roles;
use App\sector;
use App\Customer;
use App\local_distr_product_sales;
use App\orderBooker;
use App\sub_distributor_ledger;
use App\Warehouse;
use Illuminate\Http\Request;

class shopsController extends Controller
{
    
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('local_system')){
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if(empty($all_permission))
                $all_permission[] = 'dummy text';
            $lims_shops_all = shops::where('dist_id', session('logged_session_data.customer_id'))->where('is_active',true)->get();
            $lims_orderBooker_all = orderBooker::where('dist_id', session('logged_session_data.customer_id'))->get();
            $sector = sector::where('dist_id', session('logged_session_data.customer_id'))->get();
           
            return view('local_distributor.shops.create', compact('lims_orderBooker_all','lims_shops_all','sector', 'all_permission'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('local_system') ||$role->hasPermissionTo('users-add') ){
            // $lims_customer_group_all = CustomerGroup::where('is_active',true)->get();
            $town = Town::get();
            $lims_role_list = Roles::where('is_active', true)->get();
            $customer = Customer::where('is_active', true)->get();
            $warehouse = Warehouse::where('is_active', true)->get();
            return view('local_distributor.orderbooker.create', compact('warehouse','customer','town','lims_role_list'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    
    public function store(Request $request)
    {
        //
        $data = $request->all();
        $sub_ledger = new sub_distributor_ledger();
       
         //dd(implode(",",$data['town']));
         $get_id=shops::get()->last();
        
        

          $data['dist_id'] =  session('logged_session_data.customer_id');
          $data['shop_code'] = 'SH-'.$get_id->id ;
        $shops=   shops::create($data);



        $prod_ledger_data= sub_distributor_ledger::where('shop_id',$shops->id)->whereIn('type',0)->first();
       if(!isset($prod_ledger_data)){
        $sub_ledger->shop_id=$shops->id;
        $sub_ledger->invoice_no= "Opening";
        $sub_ledger->discribtion='Opening';
        $sub_ledger->amount=$data['openingBal'];
        $sub_ledger->recdate=date('Y-m-d');
        $sub_ledger->type=0;
        $sub_ledger->save();
       }
       


        $message='Create Successfully';
        return redirect('customer_shops')->with('create_message', $message);
    }

   
    public function show(cr $cr)
    {
        //
    }

    
    public function edit($id)
    {
        $techxa_shop_data = shops::findOrFail($id);
       return $techxa_shop_data;
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\cr  $cr
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $input = $request->all();
       $techxa_town_data = shops::find($input['id']);
       // setQueryLog();
       $input['dist_id']=  session('logged_session_data.customer_id');
       $techxa_town_data->update($input);
       // dd(getQueryLog());
       return redirect('customer_shops')->with('message', 'Data updated successfully');
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\cr  $cr
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        $techxa_town_data = shops::find($id);
        $techxa_town_data->is_active = false;
        $techxa_town_data->save();
        return redirect('customer_shops')->with('not_permitted', 'Data deleted successfully');
    }
    

    


    public function importcustomer_shops(Request $request){


        $filename =  $request->file->getClientOriginalName();
        $upload=$request->file('file');
        $filePath=$upload->getRealPath();
        //open and read
        $file=fopen($filePath, 'r');
        $header= fgetcsv($file);
        $escapedHeader=[];
        //validate
        foreach ($header as $key => $value) {
            $lheader=strtolower($value);
            $escapedItem=preg_replace('/[^a-z]/', '', $lheader);
            array_push($escapedHeader, $escapedItem);
        }
        //looping through othe columns
        $lims_mdo_data = [];
        while($columns=fgetcsv($file))
        {
            if($columns[0]=="")
                continue;
            foreach ($columns as $key => $value) {
                $value=preg_replace('/\D/','',$value);
            }
            $data= array_combine($escapedHeader, $columns);

        
           $orderBooker_id= orderBooker::where('emp_code',$data['mdocode'])->first();
    
           $sector_id= sector::where('name',$data['sector'])->first();
        //    dd( $sector_id);  
            $shop_detail = shops::firstOrNew(['shop_code' => $data['code'],'is_active' => true ]);
            $shop_detail->shop_code = $data['code'];
            $shop_detail->name = $data['shopname'];
            $shop_detail->address = $data['address'];
            $shop_detail->phone_number = $data['phonenumber'];
            
            if( $sector_id!=null){
                $shop_detail->sectors = $sector_id->id;  
            }
            else{
                $shop_detail->sectors=0;
            }
           
            $shop_detail->orderbooker_id = $orderBooker_id->id;
            $shop_detail->dist_id =session('logged_session_data.customer_id');
            $shop_detail->is_active =true;     
            $shop_detail->save();
        }
        return redirect('customer_shops')->with('message', 'Shop Details imported successfully');
    }


   public function sectorofMdo(Request $request){


    $orderBooker=orderBooker::where('id',$request->orderbooker_id)->first();

    // dd( $orderBooker->sectors);
    

   $sectorname= sector::whereIn('id', explode(",",$orderBooker->sectors))->get();
return $sectorname;
    }


   public function inoviceBySelection( Request $request){
 $invoiceIdArray1 = $request['invoiceIdArray'];
 
 // $prod_sale_data = [];
try{
       foreach ($invoiceIdArray1 as $id) {
        

       $prod_sale_data[] = local_distr_product_sales::where('id',$id)->with('shops')->with('local_distr_orderdetail')->get();
       
        
          
    
     
              
         

         $customer_detail= Customer::where('id',session('logged_session_data.customer_id'))->firstOrFail();
             $town_name=sector::where('id',$prod_sale_data[0][0]->sector_id)->first();
            
            //   $order_date=$order[0]->productsale->created_at;
            //   $order_invoice=$order[0]->productsale->invoice;
            //   $cust_name= $order[0]->customer->distribution_name;
            //   $cust_address= $order[0]->customer->address;
            //   $ntn= $order[0]->customer->ntn;
            //   $cust_city= $town_name->town_name;
            //   $cust_num= $order[0]->customer->cust_num;
            //   $cust_state= $order[0]->customer->state;
            //   $cust_pakistan= $order[0]->customer->country;
            //   $cust_phone= $order[0]->customer->phone_number;
            //   $cnic= $order[0]->customer->cnic;            
        //  dd($prod_sale_data);
              $regular= "S-F";
             
             $data=[
                    'order'=>$prod_sale_data,
                     'regular'=>$regular,
                     'town_name'=>$town_name,
                     'customer_detail'=>$customer_detail
                
                ];

                
              }

             
                $pdf = PDF::loadView('local_distributor.reports.printing_invoices',$data);
        $pdf->setPaper('A4', 'Portriate');
 
        return $pdf->stream("Invoce.pdf");
    } catch(Exception $e)
    {
    
        $s = $e->getMessage();
        
        $d=$s;
    }
      
    }

    public function Outstandshop(Request $request){
        $orderbookername='';
        $orderbookerphone='';
        $orderbooker_id=0;
        $shop_detail = shops::where('orderbooker_id',$request->orderbooker_id)->get();
        $data=[];
       
        foreach($shop_detail as $value)
        {
        $result['id']=  $value->id;
    
     

        $result['name']=  $value->name;
        $result['sector'] = sector::where('id',$value->sectors)->pluck('name')->toArray();
   $result['invoice'] = sub_distributor_ledger::where('shop_id',$value->id)->where('type',4)->sum('amount');
   $result['return'] = sub_distributor_ledger::where('shop_id',$value->id)->where('type',6)->sum('amount');
   
   $result['cashrecived'] = sub_distributor_ledger::where('shop_id',$value->id)->where('type',1)->sum('amount');
   $result['criedit'] = sub_distributor_ledger::where('shop_id',$value->id)->where('type',3)->sum('amount');
   $result['recovery'] = sub_distributor_ledger::where('shop_id',$value->id)->where('type',5)->sum('amount');
   $result['outstanding']=  ( $result['cashrecived'] +$result['recovery'] + $result['return'] )-$result['invoice']- $result['criedit'];


  
   $data[]=$result;
   $orderbooker_id=$request->orderbooker_id;
   $orderbookername1= orderBooker::where('id',$request->orderbooker_id)->first();
   $orderbookername=$orderbookername1->name;
   $orderbookerphone=$orderbookername1->phone_number;
    }



    $customername=Customer::where('id',session('logged_session_data.customer_id'))->pluck('distribution_name')->first();

   $orderbooker= orderBooker::get();
    return view('local_distributor.reports.outstanding', compact('data','orderbooker','orderbookername','orderbookerphone','customername','orderbooker_id') );
}

}

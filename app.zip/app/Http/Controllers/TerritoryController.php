<?php

namespace App\Http\Controllers;

use App\Territory;
use App\Http\Requests\StoreTerritoryRequest;
use App\Http\Requests\UpdateTerritoryRequest;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Auth;
use Illuminate\Http\Request;
class TerritoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('unit')) {
        //    setQueryLog();
           $techxa_territory_all = Territory::with('zone')->where('is_active', true)->get();
        //    dd(getQueryLog());
           // dd($techxa_territory_all);
            return view('territory.create', compact('techxa_territory_all'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreTerritoryRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'territory_name' => [
                'max:255',
                    Rule::unique('territories')->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
            'territory_code' => [
                'max:255',
                    Rule::unique('territories')->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
            'zone_code' => 'required',
        ]);
        $input = $request->all();
        $input['is_active'] = true;
        Territory::create($input);
        return redirect('territory')->with('message', 'Data inserted successfully');
    }


    public function deleteBySelection(Request $request)
    {
        $territory_id = $request['territoryIdArray'];
        foreach ($territory_id as $id) {
            $techxa_territory_data = Territory::find($id);
            $techxa_territory_data->is_active = false;
            $techxa_territory_data->save();
        }
        return 'Territorys deleted successfully!';
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Territory  $territory
     * @return \Illuminate\Http\Response
     */
    public function show(Territory $territory)
    {
        //Te
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Territory  $territory
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       
        $techxa_territory_data = Territory::findOrFail($id);
        return $techxa_territory_data;
    }
   
    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateTerritoryRequest  $request
     * @param  \App\Territory  $territory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $this->validate($request, [
            'territory_name' => [
                'max:255',
                Rule::unique('territories')->ignore($request->territory_id)->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
            'territory_code' => [
                'max:255',
                Rule::unique('territories')->ignore($request->territory_id)->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
            'zone_code' => 'required',
        ]);
        $input = $request->all();
        $techxa_territory_data = Territory::find($input['territory_id']);
        // setQueryLog();
        $techxa_territory_data->update($input);
        // dd(getQueryLog());
        return redirect('territory')->with('message', 'Data updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Territory  $territory
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $techxa_territory_data = Territory::find($id);
        $techxa_territory_data->is_active = false;
        $techxa_territory_data->save();
        return redirect('territory')->with('not_permitted', 'Data deleted successfully');
    }
    public function importterritory(Request $request)
    { 
        $upload=$request->file('file');

      
        $ext = pathinfo($upload->getClientOriginalName(), PATHINFO_EXTENSION);
        if($ext != 'csv')
            return redirect()->back()->with('not_permitted', 'Please upload a CSV file');
        $filename =  $upload->getClientOriginalName();
        $upload=$request->file('file');
        $filePath=$upload->getRealPath();
        //open and read
        $file=fopen($filePath, 'r');
        $header= fgetcsv($file);
        $escapedHeader=[];
        //validate
        foreach ($header as $key => $value) {
            $lheader=strtolower($value);
            $escapedItem=preg_replace('/[^a-z]/', '', $lheader);
            array_push($escapedHeader, $escapedItem);
        }
        //looping through othe columns
        while($columns=fgetcsv($file))
        {
            if($columns[0]=="")
                continue;
            foreach ($columns as $key => $value) {
                $value=preg_replace('/\D/','',$value);
            }
           $data= array_combine($escapedHeader, $columns);
//dd($data);
// $prod_id=Product::where('name', $data['productname'])->first();
// $input['qty_list'] =$data['qty']+$prod_id->qty_list;
//        Product::where('id', $prod_id->id)->update($input);
//dd($prod_id);
 //$qty=Product::where('id', $data['product_id'])->first();
       // dd($qty->qty_list);
        
           $lims_Territory_data= Territory::firstOrNew(['territory_name'=>$data['territoryname']]);
           $lims_Territory_data->zone_code =$data['code'];
           $lims_Territory_data->territory_code =$data['territorycode'];
           $lims_Territory_data->territory_name =$data['territoryname'];
           $lims_Territory_data->is_active =1;
          // $lims_product_data->distributor_margin =$data['distributormargin'];
           
          
           $lims_Territory_data->save();
           
        }
        return redirect('territory')->with('message', 'Price Structure imported successfully');
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Product;
use App\warehouseSummary;
use App\ProductPurchase;
use GuzzleHttp\Client;
use App\Product_Sale;
use App\ProductQuotation;
use App\Sale;
use App\Purchase;
use App\Quotation;
use App\add_cliam;
use App\Territory;
use App\Transfer;
use App\Returns;
use App\order_detail;
use App\ProductReturn;
use App\ReturnPurchase;
use App\ProductTransfer;
use App\PurchaseProductReturn;
use App\Payment;
use App\Warehouse;
use App\Product_Warehouse;
use App\Expense;
use App\Payroll;
use App\add_stock;
use App\User;
use App\Customer;
use App\Supplier;
use App\Variant;
use App\Zone;
use App\Price_structure;
use App\CustomerGroup;

use App\Town;
use App\ProductVariant;
use DB;
use Auth;
use PDF;
use App\Company_Head;
use App\Ledger;
use App\Account_head;
use App\Online_cash;
use App\CliamHead;
use Illuminate\Support\Facades\DB as FacadesDB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class ReportController extends Controller
{
    public function productQuantityAlert()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('product-qty-alert')){
            // $lims_product_data = Product::select('name','code', 'image', 'qty', 'alert_quantity')->where('is_active', true)->whereColumn('alert_quantity', '>', 'qty')->get();
          
         
            $start_date=date('Y-m-01');
            $end_date=date('Y-m-t');
            $lims_product_data=Product::where('is_active',true)->with(['orderdetail' => function ($attend) use ($start_date,$end_date)  {
                return $attend->whereBetween('created_at',[$start_date,$end_date])->selectRaw('prod_id,SUM(qty) as totalqty')->groupBy('prod_id');
                 ;
                },
            ] )->get()->toArray();
         //  dd( $lims_product_data);
          return view('report.qty_alert_report', compact('lims_product_data'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function warehouseStock()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('warehouse-stock-report')){
            $total_item = DB::table('product_warehouse')
                        ->join('products', 'product_warehouse.product_id', '=', 'products.id')
                        ->where([
                            ['products.is_active', true],
                            ['product_warehouse.qty', '>' , 0]
                        ])->count();

            $total_qty = Product::where('is_active', true)->sum('qty');
            $total_price = DB::table('products')->where('is_active', true)->sum(DB::raw('price * qty'));
            $total_cost = DB::table('products')->where('is_active', true)->sum(DB::raw('cost * qty'));
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            $warehouse_id = 0;
            return view('report.warehouse_stock', compact('total_item', 'total_qty', 'total_price', 'total_cost', 'lims_warehouse_list', 'warehouse_id'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function warehouseStockById(Request $request)
    {
        $data = $request->all();
        if($data['warehouse_id'] == 0)
            return redirect()->back();

        $total_item = DB::table('product_warehouse')
                        ->join('products', 'product_warehouse.product_id', '=', 'products.id')
                        ->where([
                            ['products.is_active', true],
                            ['product_warehouse.qty', '>' , 0],
                            ['product_warehouse.warehouse_id', $data['warehouse_id']]
                        ])->count();
        $total_qty = DB::table('product_warehouse')
                        ->join('products', 'product_warehouse.product_id', '=', 'products.id')
                        ->where([
                            ['products.is_active', true],
                            ['product_warehouse.warehouse_id', $data['warehouse_id']]
                        ])->sum('product_warehouse.qty');
        $total_price = DB::table('product_warehouse')
                        ->join('products', 'product_warehouse.product_id', '=', 'products.id')
                        ->where([
                            ['products.is_active', true],
                            ['product_warehouse.warehouse_id', $data['warehouse_id']]
                        ])->sum(DB::raw('products.price * product_warehouse.qty'));
        $total_cost = DB::table('product_warehouse')
                        ->join('products', 'product_warehouse.product_id', '=', 'products.id')
                        ->where([
                            ['products.is_active', true],
                            ['product_warehouse.warehouse_id', $data['warehouse_id']]
                        ])->sum(DB::raw('products.cost * product_warehouse.qty'));
        $lims_warehouse_list = Warehouse::where('is_active', true)->get();
        $warehouse_id = $data['warehouse_id'];
        return view('report.warehouse_stock', compact('total_item', 'total_qty', 'total_price', 'total_cost', 'lims_warehouse_list', 'warehouse_id'));
    }

    public function dailySale($year, $month)
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('daily-sale')){
            $start = 1;
            $number_of_day = date('t', mktime(0, 0, 0, $month, 1, $year));
            while($start <= $number_of_day)
            {
                if($start < 10)
                    $date = $year.'-'.$month.'-0'.$start;
                else
                    $date = $year.'-'.$month.'-'.$start;
                $query1 = array(
                    // 'SUM(total_discount) AS total_discount',
                    // 'SUM(order_discount) AS order_discount',
                    // 'SUM(total_tax) AS total_tax',
                    // 'SUM(order_tax) AS order_tax',
                    // 'SUM(shipping_cost) AS shipping_cost',
                    'SUM(total) AS grand_total'
                );
                $sale_data = Product_Sale::whereDate('created_at', $date)->selectRaw(implode(',', $query1))->where('status',1)->get();
                $total_discount[$start] = $sale_data[0]->total_discount;
                $order_discount[$start] = $sale_data[0]->order_discount;
                $total_tax[$start] = $sale_data[0]->total_tax;
                $order_tax[$start] = $sale_data[0]->order_tax;
                $shipping_cost[$start] = $sale_data[0]->shipping_cost;
                $grand_total[$start] = $sale_data[0]->grand_total;
                $start++;
            }
            $start_day = date('w', strtotime($year.'-'.$month.'-01')) + 1;
            $prev_year = date('Y', strtotime('-1 month', strtotime($year.'-'.$month.'-01')));
            $prev_month = date('m', strtotime('-1 month', strtotime($year.'-'.$month.'-01')));
            $next_year = date('Y', strtotime('+1 month', strtotime($year.'-'.$month.'-01')));
            $next_month = date('m', strtotime('+1 month', strtotime($year.'-'.$month.'-01')));
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            $warehouse_id = 0;
            return view('report.daily_sale', compact('total_discount','order_discount', 'total_tax', 'order_tax', 'shipping_cost', 'grand_total', 'start_day', 'year', 'month', 'number_of_day', 'prev_year', 'prev_month', 'next_year', 'next_month', 'lims_warehouse_list', 'warehouse_id'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function dailySaleByWarehouse(Request $request,$year,$month)
    {
        $data = $request->all();
        if($data['warehouse_id'] == 0)
            return redirect()->back();
        $start = 1;
        $number_of_day = date('t', mktime(0, 0, 0, $month, 1, $year));
        while($start <= $number_of_day)
        {
            if($start < 10)
                $date = $year.'-'.$month.'-0'.$start;
            else
                $date = $year.'-'.$month.'-'.$start;
            $query1 = array(
                'SUM(total_discount) AS total_discount',
                'SUM(order_discount) AS order_discount',
                'SUM(total_tax) AS total_tax',
                'SUM(order_tax) AS order_tax',
                'SUM(shipping_cost) AS shipping_cost',
                'SUM(grand_total) AS grand_total'
            );
            $sale_data = Sale::where('warehouse_id', $data['warehouse_id'])->whereDate('created_at', $date)->selectRaw(implode(',', $query1))->get();
            $total_discount[$start] = $sale_data[0]->total_discount;
            $order_discount[$start] = $sale_data[0]->order_discount;
            $total_tax[$start] = $sale_data[0]->total_tax;
            $order_tax[$start] = $sale_data[0]->order_tax;
            $shipping_cost[$start] = $sale_data[0]->shipping_cost;
            $grand_total[$start] = $sale_data[0]->grand_total;
            $start++;
        }
        $start_day = date('w', strtotime($year.'-'.$month.'-01')) + 1;
        $prev_year = date('Y', strtotime('-1 month', strtotime($year.'-'.$month.'-01')));
        $prev_month = date('m', strtotime('-1 month', strtotime($year.'-'.$month.'-01')));
        $next_year = date('Y', strtotime('+1 month', strtotime($year.'-'.$month.'-01')));
        $next_month = date('m', strtotime('+1 month', strtotime($year.'-'.$month.'-01')));
        $lims_warehouse_list = Warehouse::where('is_active', true)->get();
        $warehouse_id = $data['warehouse_id'];
        return view('report.daily_sale', compact('total_discount','order_discount', 'total_tax', 'order_tax', 'shipping_cost', 'grand_total', 'start_day', 'year', 'month', 'number_of_day', 'prev_year', 'prev_month', 'next_year', 'next_month', 'lims_warehouse_list', 'warehouse_id'));

    }

    public function dailyPurchase($year, $month)
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('daily-purchase')){
            $start = 1;
            $number_of_day = date('t', mktime(0, 0, 0, $month, 1, $year));
            while($start <= $number_of_day)
            {
                if($start < 10)
                    $date = $year.'-'.$month.'-0'.$start;
                else
                    $date = $year.'-'.$month.'-'.$start;
                $query1 = array(
                    'SUM(total_discount) AS total_discount',
                    'SUM(order_discount) AS order_discount',
                    'SUM(total_tax) AS total_tax',
                    'SUM(order_tax) AS order_tax',
                    'SUM(shipping_cost) AS shipping_cost',
                    'SUM(grand_total) AS grand_total'
                );
                $purchase_data = Purchase::whereDate('created_at', $date)->selectRaw(implode(',', $query1))->get();
                $total_discount[$start] = $purchase_data[0]->total_discount;
                $order_discount[$start] = $purchase_data[0]->order_discount;
                $total_tax[$start] = $purchase_data[0]->total_tax;
                $order_tax[$start] = $purchase_data[0]->order_tax;
                $shipping_cost[$start] = $purchase_data[0]->shipping_cost;
                $grand_total[$start] = $purchase_data[0]->grand_total;
                $start++;
            }
            $start_day = date('w', strtotime($year.'-'.$month.'-01')) + 1;
            $prev_year = date('Y', strtotime('-1 month', strtotime($year.'-'.$month.'-01')));
            $prev_month = date('m', strtotime('-1 month', strtotime($year.'-'.$month.'-01')));
            $next_year = date('Y', strtotime('+1 month', strtotime($year.'-'.$month.'-01')));
            $next_month = date('m', strtotime('+1 month', strtotime($year.'-'.$month.'-01')));
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            $warehouse_id = 0;
            return view('report.daily_purchase', compact('total_discount','order_discount', 'total_tax', 'order_tax', 'shipping_cost', 'grand_total', 'start_day', 'year', 'month', 'number_of_day', 'prev_year', 'prev_month', 'next_year', 'next_month', 'lims_warehouse_list', 'warehouse_id'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function dailyPurchaseByWarehouse(Request $request, $year, $month)
    {        
        $data = $request->all();
        if($data['warehouse_id'] == 0)
            return redirect()->back();
        $start = 1;
        $number_of_day = date('t', mktime(0, 0, 0, $month, 1, $year));
        while($start <= $number_of_day)
        {
            if($start < 10)
                $date = $year.'-'.$month.'-0'.$start;
            else
                $date = $year.'-'.$month.'-'.$start;
            $query1 = array(
                'SUM(total_discount) AS total_discount',
                'SUM(order_discount) AS order_discount',
                'SUM(total_tax) AS total_tax',
                'SUM(order_tax) AS order_tax',
                'SUM(shipping_cost) AS shipping_cost',
                'SUM(grand_total) AS grand_total'
            );
            $purchase_data = Purchase::where('warehouse_id', $data['warehouse_id'])->whereDate('created_at', $date)->selectRaw(implode(',', $query1))->get();
            $total_discount[$start] = $purchase_data[0]->total_discount;
            $order_discount[$start] = $purchase_data[0]->order_discount;
            $total_tax[$start] = $purchase_data[0]->total_tax;
            $order_tax[$start] = $purchase_data[0]->order_tax;
            $shipping_cost[$start] = $purchase_data[0]->shipping_cost;
            $grand_total[$start] = $purchase_data[0]->grand_total;
            $start++;
        }
        $start_day = date('w', strtotime($year.'-'.$month.'-01')) + 1;
        $prev_year = date('Y', strtotime('-1 month', strtotime($year.'-'.$month.'-01')));
        $prev_month = date('m', strtotime('-1 month', strtotime($year.'-'.$month.'-01')));
        $next_year = date('Y', strtotime('+1 month', strtotime($year.'-'.$month.'-01')));
        $next_month = date('m', strtotime('+1 month', strtotime($year.'-'.$month.'-01')));
        $lims_warehouse_list = Warehouse::where('is_active', true)->get();
        $warehouse_id = $data['warehouse_id'];

        return view('report.daily_purchase', compact('total_discount','order_discount', 'total_tax', 'order_tax', 'shipping_cost', 'grand_total', 'start_day', 'year', 'month', 'number_of_day', 'prev_year', 'prev_month', 'next_year', 'next_month', 'lims_warehouse_list', 'warehouse_id'));
    }

    public function monthlySale($year)
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('monthly-sale')){
            $start = strtotime($year .'-01-01');
            $end = strtotime($year .'-12-31');
            while($start <= $end)
            {
                $start_date = $year . '-'. date('m', $start).'-'.'01';
                $end_date = $year . '-'. date('m', $start).'-'.'31';

                $temp_total_discount = Sale::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total_discount');
                $total_discount[] = number_format((float)$temp_total_discount, 2, '.', '');

                $temp_order_discount = Sale::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('order_discount');
                $order_discount[] = number_format((float)$temp_order_discount, 2, '.', '');

                $temp_total_tax = Sale::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total_tax');
                $total_tax[] = number_format((float)$temp_total_tax, 2, '.', '');

                $temp_order_tax = Sale::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('order_tax');
                $order_tax[] = number_format((float)$temp_order_tax, 2, '.', '');

                $temp_shipping_cost = Sale::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('shipping_cost');
                $shipping_cost[] = number_format((float)$temp_shipping_cost, 2, '.', '');

                $temp_total = Sale::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('grand_total');
                $total[] = number_format((float)$temp_total, 2, '.', '');
                $start = strtotime("+1 month", $start);
            }
            $lims_warehouse_list = Warehouse::where('is_active',true)->get();
            $warehouse_id = 0;
            return view('report.monthly_sale', compact('year', 'total_discount', 'order_discount', 'total_tax', 'order_tax', 'shipping_cost', 'total', 'lims_warehouse_list', 'warehouse_id'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function monthlySaleByWarehouse(Request $request, $year)
    {
        $data = $request->all();
        if($data['warehouse_id'] == 0)
            return redirect()->back();

        $start = strtotime($year .'-01-01');
        $end = strtotime($year .'-12-31');
        while($start <= $end)
        {
            $start_date = $year . '-'. date('m', $start).'-'.'01';
            $end_date = $year . '-'. date('m', $start).'-'.'31';

            $temp_total_discount = Sale::where('warehouse_id', $data['warehouse_id'])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total_discount');
            $total_discount[] = number_format((float)$temp_total_discount, 2, '.', '');

            $temp_order_discount = Sale::where('warehouse_id', $data['warehouse_id'])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('order_discount');
            $order_discount[] = number_format((float)$temp_order_discount, 2, '.', '');

            $temp_total_tax = Sale::where('warehouse_id', $data['warehouse_id'])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total_tax');
            $total_tax[] = number_format((float)$temp_total_tax, 2, '.', '');

            $temp_order_tax = Sale::where('warehouse_id', $data['warehouse_id'])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('order_tax');
            $order_tax[] = number_format((float)$temp_order_tax, 2, '.', '');

            $temp_shipping_cost = Sale::where('warehouse_id', $data['warehouse_id'])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('shipping_cost');
            $shipping_cost[] = number_format((float)$temp_shipping_cost, 2, '.', '');

            $temp_total = Sale::where('warehouse_id', $data['warehouse_id'])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('grand_total');
            $total[] = number_format((float)$temp_total, 2, '.', '');
            $start = strtotime("+1 month", $start);
        }
        $lims_warehouse_list = Warehouse::where('is_active',true)->get();
        $warehouse_id = $data['warehouse_id'];
        return view('report.monthly_sale', compact('year', 'total_discount', 'order_discount', 'total_tax', 'order_tax', 'shipping_cost', 'total', 'lims_warehouse_list', 'warehouse_id'));
    }

    public function monthlyPurchase($year)
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('monthly-purchase')){
            $start = strtotime($year .'-01-01');
            $end = strtotime($year .'-12-31');
            while($start <= $end)
            {
                $start_date = $year . '-'. date('m', $start).'-'.'01';
                $end_date = $year . '-'. date('m', $start).'-'.'31';

                $query1 = array(
                    'SUM(total_discount) AS total_discount',
                    'SUM(order_discount) AS order_discount',
                    'SUM(total_tax) AS total_tax',
                    'SUM(order_tax) AS order_tax',
                    'SUM(shipping_cost) AS shipping_cost',
                    'SUM(grand_total) AS grand_total'
                );
                $purchase_data = Purchase::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->selectRaw(implode(',', $query1))->get();
                
                $total_discount[] = number_format((float)$purchase_data[0]->total_discount, 2, '.', '');
                $order_discount[] = number_format((float)$purchase_data[0]->order_discount, 2, '.', '');
                $total_tax[] = number_format((float)$purchase_data[0]->total_tax, 2, '.', '');
                $order_tax[] = number_format((float)$purchase_data[0]->order_tax, 2, '.', '');
                $shipping_cost[] = number_format((float)$purchase_data[0]->shipping_cost, 2, '.', '');
                $grand_total[] = number_format((float)$purchase_data[0]->grand_total, 2, '.', '');
                $start = strtotime("+1 month", $start);
            }
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            $warehouse_id = 0;
            return view('report.monthly_purchase', compact('year', 'total_discount', 'order_discount', 'total_tax', 'order_tax', 'shipping_cost', 'grand_total', 'lims_warehouse_list', 'warehouse_id'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function monthlyPurchaseByWarehouse(Request $request, $year)
    {
        $data = $request->all();
        if($data['warehouse_id'] == 0)
            return redirect()->back();

        $start = strtotime($year .'-01-01');
        $end = strtotime($year .'-12-31');
        while($start <= $end)
        {
            $start_date = $year . '-'. date('m', $start).'-'.'01';
            $end_date = $year . '-'. date('m', $start).'-'.'31';

            $query1 = array(
                'SUM(total_discount) AS total_discount',
                'SUM(order_discount) AS order_discount',
                'SUM(total_tax) AS total_tax',
                'SUM(order_tax) AS order_tax',
                'SUM(shipping_cost) AS shipping_cost',
                'SUM(grand_total) AS grand_total'
            );
            $purchase_data = Purchase::where('warehouse_id', $data['warehouse_id'])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->selectRaw(implode(',', $query1))->get();
            
            $total_discount[] = number_format((float)$purchase_data[0]->total_discount, 2, '.', '');
            $order_discount[] = number_format((float)$purchase_data[0]->order_discount, 2, '.', '');
            $total_tax[] = number_format((float)$purchase_data[0]->total_tax, 2, '.', '');
            $order_tax[] = number_format((float)$purchase_data[0]->order_tax, 2, '.', '');
            $shipping_cost[] = number_format((float)$purchase_data[0]->shipping_cost, 2, '.', '');
            $grand_total[] = number_format((float)$purchase_data[0]->grand_total, 2, '.', '');
            $start = strtotime("+1 month", $start);
        }
        $lims_warehouse_list = Warehouse::where('is_active', true)->get();
        $warehouse_id = $data['warehouse_id'];
        return view('report.monthly_purchase', compact('year', 'total_discount', 'order_discount', 'total_tax', 'order_tax', 'shipping_cost', 'grand_total', 'lims_warehouse_list', 'warehouse_id'));
    }

    public function bestSeller()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('best-seller')){
            $start = strtotime(date("Y-m", strtotime("-2 months")).'-01');
            $end = strtotime(date("Y").'-'.date("m").'-31');
            
            while($start <= $end)
            {
                $start_date = date("Y-m", $start).'-'.'01';
                $end_date = date("Y-m", $start).'-'.'31';

                $best_selling_qty = order_detail::select(DB::raw('prod_id, sum(qty) as sold_qty'))->whereDate('updated_at', '>=' , $start_date)->whereDate('updated_at', '<=' , $end_date)->groupBy('prod_id')->orderBy('sold_qty', 'desc')->take(1)->get();
                
             //   dd( $best_selling_qty);
                if(!count($best_selling_qty)){
                    $product[] = '';
                    $sold_qty[] = 0;
                }
                foreach ($best_selling_qty as $best_seller) {
                    $product_data = Product::find($best_seller->prod_id);
                    $product[] = $product_data->name.': '.$product_data->code;
                    $sold_qty[] = $best_seller->sold_qty;
                }
                $start = strtotime("+1 month", $start);
            }
            $start_month = date("F Y", strtotime('-2 month'));
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            $warehouse_id = 0;
            //return $product;
            return view('report.best_seller', compact('product', 'sold_qty', 'start_month', 'lims_warehouse_list', 'warehouse_id'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function bestSellerByWarehouse(Request $request)
    {
        $data = $request->all();
        if($data['warehouse_id'] == 0)
            return redirect()->back();

        $start = strtotime(date("Y-m", strtotime("-2 months")).'-01');
        $end = strtotime(date("Y").'-'.date("m").'-31');

        while($start <= $end)
        {
            $start_date = date("Y-m", $start).'-'.'01';
            $end_date = date("Y-m", $start).'-'.'31';

            $best_selling_qty = DB::table('sales')
                                ->join('product_sales', 'sales.id', '=', 'product_sales.sale_id')->select(DB::raw('product_sales.product_id, sum(product_sales.qty) as sold_qty'))->where('sales.warehouse_id', $data['warehouse_id'])->whereDate('sales.created_at', '>=' , $start_date)->whereDate('sales.created_at', '<=' , $end_date)->groupBy('product_id')->orderBy('sold_qty', 'desc')->take(1)->get();
                                
            if(!count($best_selling_qty)) {
                $product[] = '';
                $sold_qty[] = 0;
            }
            foreach ($best_selling_qty as $best_seller) {
                $product_data = Product::find($best_seller->product_id);
                $product[] = $product_data->name.': '.$product_data->code;
                $sold_qty[] = $best_seller->sold_qty;
            }
            $start = strtotime("+1 month", $start);
        }
        $start_month = date("F Y", strtotime('-2 month'));
        $lims_warehouse_list = Warehouse::where('is_active', true)->get();
        $warehouse_id = $data['warehouse_id'];
        return view('report.best_seller', compact('product', 'sold_qty', 'start_month', 'lims_warehouse_list', 'warehouse_id'));
    }

    public function profitLoss(Request $request)
    {
        $start_date = $request['start_date'];
        $end_date = $request['end_date'];
        $query1 = array(
            'SUM(grand_total) AS grand_total',
            'SUM(paid_amount) AS paid_amount',
            'SUM(total_tax + order_tax) AS tax',
            'SUM(total_discount + order_discount) AS discount'
        );
        $query2 = array(
            'SUM(grand_total) AS grand_total',
            'SUM(total_tax + order_tax) AS tax'
        );
        $product_sale_data = Product_Sale::select(DB::raw('product_id, product_batch_id, sum(qty) as sold_qty, sum(total) as sold_amount'))->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->groupBy('product_id', 'product_batch_id')->get();

        $product_revenue = 0;
        $product_cost = 0;
        $product_tax = 0;
        $profit = 0;
        foreach ($product_sale_data as $key => $product_sale) {
            if($product_sale->product_batch_id)
                $product_purchase_data = ProductPurchase::where([
                    ['product_id', $product_sale->product_id],
                    ['product_batch_id', $product_sale->product_batch_id]
                ])->get();
            else
                $product_purchase_data = ProductPurchase::where('product_id', $product_sale->product_id)->get();

            $purchased_qty = 0;
            $purchased_amount = 0;
            $purchased_tax = 0;
            $sold_qty = $product_sale->sold_qty;
            $product_revenue += $product_sale->sold_amount;
            foreach ($product_purchase_data as $key => $product_purchase) {
                $purchased_qty += $product_purchase->qty;
                $purchased_amount += $product_purchase->total;
                $purchased_tax += $product_purchase->tax;
                if($purchased_qty >= $sold_qty) {
                    $qty_diff = $purchased_qty - $sold_qty;
                    $unit_cost = $product_purchase->total / $product_purchase->qty;
                    $unit_tax = $product_purchase->tax / $product_purchase->qty;
                    $purchased_amount -= ($qty_diff * $unit_cost);
                    $purchased_tax -= ($qty_diff * $unit_tax);
                    break;
                }
            }
            $product_cost += $purchased_amount;
            $product_tax += $purchased_tax;
        }
        
        $purchase = Purchase::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->selectRaw(implode(',', $query1))->get();
        $total_purchase = Purchase::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->count();
        $sale = Sale::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->selectRaw(implode(',', $query1))->get();
        $total_sale = Sale::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->count();
        $return = Returns::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->selectRaw(implode(',', $query2))->get();
        $total_return = Returns::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->count();
        $purchase_return = ReturnPurchase::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->selectRaw(implode(',', $query2))->get();
        $total_purchase_return = ReturnPurchase::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->count();
        $expense = Expense::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('amount');
        $total_expense = Expense::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->count();
        $payroll = Payroll::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('amount');
        $total_payroll = Payroll::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->count();
        $total_item = DB::table('product_warehouse')
                    ->join('products', 'product_warehouse.product_id', '=', 'products.id')
                    ->where([
                        ['products.is_active', true],
                        ['product_warehouse.qty', '>' , 0]
                    ])->count();
        $payment_recieved_number = DB::table('payments')->whereNotNull('sale_id')->whereDate('created_at', '>=' , $start_date)
            ->whereDate('created_at', '<=' , $end_date)->count();
        $payment_recieved = DB::table('payments')->whereNotNull('sale_id')->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('payments.amount');
        $credit_card_payment_sale = DB::table('payments')
                            ->where('paying_method', 'Credit Card')
                            ->whereNotNull('payments.sale_id')
                            ->whereDate('payments.created_at', '>=' , $start_date)
                            ->whereDate('payments.created_at', '<=' , $end_date)->sum('payments.amount');
        $cheque_payment_sale = DB::table('payments')
                            ->where('paying_method', 'Cheque')
                            ->whereNotNull('payments.sale_id')
                            ->whereDate('payments.created_at', '>=' , $start_date)
                            ->whereDate('payments.created_at', '<=' , $end_date)->sum('payments.amount');
        $gift_card_payment_sale = DB::table('payments')
                            ->where('paying_method', 'Gift Card')
                            ->whereNotNull('sale_id')
                            ->whereDate('created_at', '>=' , $start_date)
                            ->whereDate('created_at', '<=' , $end_date)
                            ->sum('amount');
        $paypal_payment_sale = DB::table('payments')
                            ->where('paying_method', 'Paypal')
                            ->whereNotNull('sale_id')
                            ->whereDate('created_at', '>=' , $start_date)
                            ->whereDate('created_at', '<=' , $end_date)
                            ->sum('amount');
        $deposit_payment_sale = DB::table('payments')
                            ->where('paying_method', 'Deposit')
                            ->whereNotNull('sale_id')
                            ->whereDate('created_at', '>=' , $start_date)
                            ->whereDate('created_at', '<=' , $end_date)
                            ->sum('amount');
        $cash_payment_sale =  $payment_recieved - $credit_card_payment_sale - $cheque_payment_sale - $gift_card_payment_sale - $paypal_payment_sale - $deposit_payment_sale;
        $payment_sent_number = DB::table('payments')->whereNotNull('purchase_id')->whereDate('created_at', '>=' , $start_date)
            ->whereDate('created_at', '<=' , $end_date)->count();
        $payment_sent = DB::table('payments')->whereNotNull('purchase_id')->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('payments.amount');
        $credit_card_payment_purchase = DB::table('payments')
                            ->where('paying_method', 'Gift Card')
                            ->whereNotNull('payments.purchase_id')
                            ->whereDate('payments.created_at', '>=' , $start_date)
                            ->whereDate('payments.created_at', '<=' , $end_date)->sum('payments.amount');
        $cheque_payment_purchase = DB::table('payments')
                            ->where('paying_method', 'Cheque')
                            ->whereNotNull('payments.purchase_id')
                            ->whereDate('payments.created_at', '>=' , $start_date)
                            ->whereDate('payments.created_at', '<=' , $end_date)->sum('payments.amount');
        $cash_payment_purchase =  $payment_sent - $credit_card_payment_purchase - $cheque_payment_purchase;
        $lims_warehouse_all = Warehouse::where('is_active',true)->get();
        $warehouse_name = [];
        foreach ($lims_warehouse_all as $warehouse) {
            $warehouse_name[] = $warehouse->name;
            $warehouse_sale[] = Sale::where('warehouse_id', $warehouse->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->selectRaw(implode(',', $query2))->get();
            $warehouse_purchase[] = Purchase::where('warehouse_id', $warehouse->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->selectRaw(implode(',', $query2))->get();
            $warehouse_return[] = Returns::where('warehouse_id', $warehouse->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->selectRaw(implode(',', $query2))->get();
            $warehouse_purchase_return[] = ReturnPurchase::where('warehouse_id', $warehouse->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->selectRaw(implode(',', $query2))->get();
            $warehouse_expense[] = Expense::where('warehouse_id', $warehouse->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('amount');
        }

        return view('report.profit_loss', compact('purchase', 'product_cost', 'product_tax', 'total_purchase', 'sale', 'total_sale', 'return', 'purchase_return', 'total_return', 'total_purchase_return', 'expense', 'payroll', 'total_expense', 'total_payroll', 'payment_recieved', 'payment_recieved_number', 'cash_payment_sale', 'cheque_payment_sale', 'credit_card_payment_sale', 'gift_card_payment_sale', 'paypal_payment_sale', 'deposit_payment_sale', 'payment_sent', 'payment_sent_number', 'cash_payment_purchase', 'cheque_payment_purchase', 'credit_card_payment_purchase', 'warehouse_name', 'warehouse_sale', 'warehouse_purchase', 'warehouse_return', 'warehouse_purchase_return', 'warehouse_expense', 'start_date', 'end_date'));
    }



    public function summary_ssr_report(Request $request)
    {

        $start_date =$request->start_date;
        $end_date = $request->end_date;
        $ssr_report=[];
        $start_date=date('Y-09-01');
        $end_date=date('Y-09-t');
        
        $ssr_report=[];
        $lims_customer_list = Customer::where('is_active', true)->get();
        foreach( $lims_customer_list as $customers)
        {
            $data['customer_id']= $customers->id;
            $customer= $customers->id;
      
            $data['town']= Town::where('is_active', true)->where('id',$customers->city)->first();
            $data['closing_purchase']=PurchaseProductReturn::whereDate('created_at','<',$start_date)->orderBy('id','ASC')->where('customer_id',$customer)->selectRaw('customer_id,product_id,SUM(qty) as totalqtyclosing')->groupBy('product_id')->get()->toArray();


            $data['lims_product_data']=Product::where('is_active',true)->orderBy('id','ASC')->with(['purchase_return'=> function ($attend1) use ($start_date,$end_date,$customer)  {
                return $attend1->whereDate('created_at','>=',$start_date)->where('customer_id',$customer)->whereDate('created_at','<=',$end_date)->selectRaw('customer_id,product_id,SUM(qty) as totalqty1')->groupBy('product_id');
            }])  ->with(['orderdetail' => function ($attend) use ($start_date,$end_date,$customer)  {
                     return $attend->whereBetween('created_at',[$start_date,$end_date])->where('cust_id',$customer)->selectRaw('cust_id,tp_price,invoice_price')->selectRaw('prod_id,SUM(qty) as totalqty')->groupBy('prod_id')->with('customer')
;
                     },
                ] )->get()->toArray();

                // $data['total_inv_qty_unit_col']=0;
                // $data['total_inv_qty_unit_col_inv_price']=0;
                // foreach($data['lims_product_data'] as $productlist){
                //     $data['product_id']= $productlist['id'];
                //     $data['price_structure']=  Price_structure::where('product_id',$productlist['id'])->where('group_id',2)->first();
                //     if($productlist['orderdetail']!=null){
                //         // $total_inv_qty_unit= $product['orderdetail'][0]['totalqty']*$product['UnitPerCTRN'];
                //         // $total_inv_qty_unit_col_o += $product['orderdetail'][0]['totalqty']*$product['UnitPerCTRN'];
                //          $data['total_inv_qty_unit_col']+= $productlist['orderdetail'][0]['totalqty']*$productlist['UnitPerCTRN']*$data['price_structure']->txt_trade_price;
                //          $data['total_inv_qty_unit_col_inv_price']+= $productlist['orderdetail'][0]['totalqty']*$productlist['UnitPerCTRN']*$data['price_structure']->inv_price;
                //     }
                //     else {
                //         $total_inv_qty_unit=0;
                //     }

                // }
                $ssr_report[]=$data;

        }
       
           
        // dd($ssr_report);

             

        //enditem
       
        $town = Town::where('is_active', true)->get();
        $zones = Zone::where('is_active', true)->get();
        $territory = Territory::where('is_active', true)->get();
        
     //   dd($lims_product_data[0]);
        // $warehouse_id = $data['warehouse_id'];
        // $lims_warehouse_list = Warehouse::where('is_active', true)->get();
        return view('report.reports.summary_ssr_report',compact('territory','town','zones','start_date', 'end_date','ssr_report','lims_customer_list',));
    }


    public function ssr_report(Request $request)
    {

        
        // $data = $request->all();

        // dd($data);
        $start_date =$request->start_date;
        $end_date = $request->end_date;
        $town_id_front = $request->town_id;
        $zone_code = $request->zone_code;
        $territory_name = $request->territory_name;
        // dd( $zone_code);
        $lims_product_data='';
        $customer=[];

        
       if( $zone_code!=null && $territory_name==null){
        $zone_id=  Zone::where('zone_name', $zone_code)->get()->pluck('zone_code')->toArray();
        $Territory_id=  Territory::where('zone_code', $zone_id)->get()->pluck('territory_name')->toArray();
        $town_id=  Town::whereIn('territory_name', $Territory_id)->get()->pluck('id')->toArray();
        $customer= Customer::whereIn('city',$town_id)->get()->pluck('id')->toArray();

      //  dd($customer);
       }else if($territory_name!=null && $town_id_front==null)
       {
        $town_id=  Town::where('territory_name', $territory_name)->get()->pluck('id')->toArray();
        $customer= Customer::whereIn('city',$town_id)->get()->pluck('id')->toArray();
       }else
       {

        // $town_id=  Town::where('territory_name', $territory_name)->get()->pluck('id')->toArray();

        $customer= Customer::where('city',$town_id_front)->get()->pluck('id')->toArray();

      
        // $town_id=  Town::where('territory_name', $territory_name)->get()->pluck('id')->toArray();
       }
     //  dd($customer);
        
     $ssr_report=[];
     // dd($town_id);
        if($start_date!=null && $end_date!=null )
        {
            

            
            $data['closing_purchase']=PurchaseProductReturn::whereDate('created_at','<',$start_date)->orderBy('id','ASC')->whereIn('customer_id',$customer)->selectRaw('customer_id,product_id,SUM(qty) as totalqtyclosing')->groupBy('product_id')->get()->toArray();

            // $order_detail= order_detail::whereBetween('created_at',[$start_date,$end_date])->whereIn('cust_id',$customer)->get();
 //dd($data['closing_purchase']);

            $data['lims_product_data']=Product::where('is_active',true)->orderBy('','ASC')->with(['purchase_return'=> function ($attend1) use ($start_date,$end_date,$zone_code,$customer)  {
                return $attend1->whereDate('created_at','>=',$start_date)->whereIn('customer_id',$customer)->whereDate('created_at','<=',$end_date)->selectRaw('customer_id,product_id,SUM(qty) as totalqty1')->groupBy('product_id');
            }])  ->with(['orderdetail' => function ($attend) use ($start_date,$end_date,$territory_name,$zone_code,$customer)  {
                     return $attend->whereBetween('created_at',[$start_date,$end_date])->whereIn('cust_id',$customer)->selectRaw('cust_id,tp_price,invoice_price')->selectRaw('prod_id,SUM(qty) as totalqty')->groupBy('prod_id')->with('customer')
;
                     },
                ] )->get()->toArray();


        $ssr_report[]=$data;

      //  dd($lims_product_data[3]);
        
        }else
        {
            $start_date=date('Y-m-01');
            $end_date=date('Y-m-t');
        
        }

       //dd($ssr_report);
       
        
        $lims_customer_list = Customer::where('is_active', true)->get();
        $town = Town::where('is_active', true)->get();
        $zones = Zone::where('is_active', true)->get();
        $territory = Territory::where('is_active', true)->get();
        
     //   dd($lims_product_data[0]);
        // $warehouse_id = $data['warehouse_id'];
        // $lims_warehouse_list = Warehouse::where('is_active', true)->get();
        return view('report.reports.ssr_report',compact('territory','town','town_id_front','territory_name','zone_code','zones','start_date', 'end_date','lims_product_data','customer','ssr_report','lims_customer_list',));
    }




    public function productReport(Request $request)
    {

        
        // $data = $request->all();

        // dd($data);
        $start_date =$request->start_date;
        $end_date = $request->end_date;
        $customer_id = $request->customer_id;
        $zone_code = $request->zone_code;
        $territory_name = $request->territory_name;
        // dd( $zone_code);
        $lims_product_data='';
        $customer=[];

        
       if( $zone_code!=null && $territory_name==null){
        $zone_id=  Zone::where('zone_name', $zone_code)->get()->pluck('zone_code')->toArray();
        $Territory_id=  Territory::where('zone_code', $zone_id)->get()->pluck('territory_name')->toArray();
        $town_id=  Town::whereIn('territory_name', $Territory_id)->get()->pluck('id')->toArray();
        $customer= Customer::whereIn('city',$town_id)->where('distributor_type',1)->get()->pluck('id')->toArray();

      //  dd($customer);
       }else if($territory_name!=null && $customer_id==null)
       {
        $town_id=  Town::where('territory_name', $territory_name)->get()->pluck('id')->toArray();
        $customer= Customer::whereIn('city',$town_id)->where('distributor_type',1)->get()->pluck('id')->toArray();
       }else
       {

        

        $customer= Customer::where('distributor_type',1)->get()->pluck('id')->toArray();

      
        
       }
        // dd(  $customer);
     
        if($start_date!=null && $end_date!=null )
        {
            

            
           
            

            $lims_product_data=Product::where('is_active',true)->orderBy('code','ASC')->with(['orderdetail' => function ($attend) use ($start_date,$end_date,$customer_id,$territory_name,$zone_code,$customer)  {
                return $attend->whereBetween('created_at',[$start_date,$end_date])->whereIn('cust_id',$customer)->selectRaw('cust_id,tp_price,invoice_price')->selectRaw('prod_id,SUM(qty) as totalqty')->groupBy('prod_id')->with('customer'
              
            )
                 ;
                },
            ] )->get()->toArray();


          //  dd($lims_product_data[0]);
        }
        
        else
        {
            
            $start_date=date('Y-m-01');
            $end_date=date('Y-m-t');
        
        }
       
       
        
        $lims_customer_list = Customer::where('is_active', true)->get();
        $zones = Zone::where('is_active', true)->get();
        $territory = Territory::where('is_active', true)->get();
        
     //   dd($lims_product_data[0]);
        // $warehouse_id = $data['warehouse_id'];
        // $lims_warehouse_list = Warehouse::where('is_active', true)->get();
        return view('report.product_report',compact('territory','territory_name','zone_code','zones','start_date', 'end_date','lims_product_data','lims_customer_list','customer_id'));
    }

    public function productReportData(Request $request)
    {
        $data = $request->all();
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $warehouse_id = $data['warehouse_id'];
        $product_id = [];
        $variant_id = [];
        $product_name = [];
        $product_qty = [];

        $columns = array( 
            1 => 'name'
        );

        if($request->input('length') != -1)
            $limit = $request->input('length');
        else
            $limit = $totalData;
        //return $request;
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        if($request->input('search.value')) {
            $search = $request->input('search.value');
            $totalData = Product::where([
                ['name', 'LIKE', "%{$search}%"],
                ['is_active', true]
            ])->count();
            $lims_product_all = Product::select('id', 'name', 'qty', 'is_variant')
                                ->where([
                                    ['name', 'LIKE', "%{$search}%"],
                                    ['is_active', true]
                                ])->offset($start)
                                  ->limit($limit)
                                  ->orderBy($order, $dir)
                                  ->get();
        }
        else {
            $totalData = Product::where('is_active', true)->count();
            $lims_product_all = Product::select('id', 'name', 'qty', 'is_variant')->with('orderdetail')->with('add_stock')
                                ->where('is_active', true)
                                ->offset($start)
                                ->limit($limit)
                                ->orderBy($order, $dir)
                                ->get();
        }

        $totalFiltered = $totalData; 
        $data = [];
        foreach ($lims_product_all as $product) {           
            $variant_id_all = [];
            if($warehouse_id == 0) {
                if($product->is_variant) {
                    $variant_id_all = ProductVariant::where('product_id', $product->id)->pluck('variant_id');
                 //new code
                 
                    
                  
                    foreach ($variant_id_all as $key => $variant_id) {
                        $variant_data = Variant::select('name')->find($variant_id);
                       
                        $nestedData['key'] = count($data);
                       
                         
                        $nestedData['name'] = $product->name . ' [' . $variant_data->name . ']';
                        //purchase data
                        $nestedData['purchased_amount'] = ProductPurchase::where([
                                                ['product_id', $product->id],
                                                ['variant_id', $variant_id]
                                        ])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total');

                        $lims_product_purchase_data = ProductPurchase::select('purchase_unit_id', 'qty')->where([
                                                ['product_id', $product->id],
                                                ['variant_id', $variant_id]
                                        ])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->get();

                        $purchased_qty = 0;
                        if(count($lims_product_purchase_data)) {
                            foreach ($lims_product_purchase_data as $product_purchase) {
                                $unit = DB::table('units')->find($product_purchase->purchase_unit_id);
                                if($unit->operator == '*'){
                                    $purchased_qty += $product_purchase->qty * $unit->operation_value;
                                }
                                elseif($unit->operator == '/'){
                                    $purchased_qty += $product_purchase->qty / $unit->operation_value;
                                }
                            }
                        }
                        $nestedData['purchased_qty'] = $purchased_qty;
                        //transfer data
                        /*$nestedData['transfered_amount'] = ProductTransfer::where([
                                                ['product_id', $product->id],
                                                ['variant_id', $variant_id]
                                        ])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total');

                        $lims_product_transfer_data = ProductTransfer::select('purchase_unit_id', 'qty')->where([
                                                ['product_id', $product->id],
                                                ['variant_id', $variant_id]
                                        ])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->get();

                        $transfered_qty = 0;
                        if(count($lims_product_transfer_data)) {
                            foreach ($lims_product_transfer_data as $product_transfer) {
                                $unit = DB::table('units')->find($product_transfer->purchase_unit_id);
                                if($unit->operator == '*'){
                                    $transfered_qty += $product_transfer->qty * $unit->operation_value;
                                }
                                elseif($unit->operator == '/'){
                                    $transfered_qty += $product_transfer->qty / $unit->operation_value;
                                }
                            }
                        }
                        $nestedData['transfered_qty'] = $transfered_qty;*/
                        //sale data
                        $nestedData['sold_amount'] = Product_Sale::where([
                                                ['product_id', $product->id],
                                                ['variant_id', $variant_id]
                                        ])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total');

                        $lims_product_sale_data = Product_Sale::select('sale_unit_id', 'qty')->where([
                                                ['product_id', $product->id],
                                                ['variant_id', $variant_id]
                                        ])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->get();

                        $sold_qty = 0;
                        if(count($lims_product_sale_data)) {
                            foreach ($lims_product_sale_data as $product_sale) {
                                $unit = DB::table('units')->find($product_sale->sale_unit_id);
                                if($unit->operator == '*'){
                                    $sold_qty += $product_sale->qty * $unit->operation_value;
                                }
                                elseif($unit->operator == '/'){
                                    $sold_qty += $product_sale->qty / $unit->operation_value;
                                }
                            }
                        }
                        $nestedData['sold_qty'] = $sold_qty;
                        //return data
                        $nestedData['returned_amount'] = ProductReturn::where([
                                                ['product_id', $product->id],
                                                ['variant_id', $variant_id]
                                        ])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total');

                        $lims_product_return_data = ProductReturn::select('sale_unit_id', 'qty')->where([
                                                ['product_id', $product->id],
                                                ['variant_id', $variant_id]
                                        ])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->get();

                        $returned_qty = 0;
                        if(count($lims_product_return_data)) {
                            foreach ($lims_product_return_data as $product_return) {
                                $unit = DB::table('units')->find($product_return->sale_unit_id);
                                if($unit->operator == '*'){
                                    $returned_qty += $product_return->qty * $unit->operation_value;
                                }
                                elseif($unit->operator == '/'){
                                    $returned_qty += $product_return->qty / $unit->operation_value;
                                }
                            }
                        }
                        $nestedData['returned_qty'] = $returned_qty;
                        //purchase return data
                        $nestedData['purchase_returned_amount'] = PurchaseProductReturn::where([
                                                ['product_id', $product->id],
                                                ['variant_id', $variant_id]
                                        ])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total');

                        $lims_product_purchase_return_data = PurchaseProductReturn::select('purchase_unit_id', 'qty')->where([
                                                ['product_id', $product->id],
                                                ['variant_id', $variant_id]
                                        ])->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->get();

                        $purchase_returned_qty = 0;
                        if(count($lims_product_purchase_return_data)) {
                            foreach ($lims_product_purchase_return_data as $product_purchase_return) {
                                $unit = DB::table('units')->find($product_purchase_return->purchase_unit_id);
                                if($unit->operator == '*'){
                                    $purchase_returned_qty += $product_purchase_return->qty * $unit->operation_value;
                                }
                                elseif($unit->operator == '/'){
                                    $purchase_returned_qty += $product_purchase_return->qty / $unit->operation_value;
                                }
                            }
                        }
                        $nestedData['purchase_returned_qty'] = $purchase_returned_qty;

                        if($nestedData['purchased_qty'] > 0)
                            $nestedData['profit'] = $nestedData['sold_amount'] - (($nestedData['purchased_amount'] / $nestedData['purchased_qty']) * $nestedData['sold_qty']);
                        else
                           $nestedData['profit'] =  $nestedData['sold_amount'];

                        $nestedData['in_stock'] = $product->qty;

                        $nestedData['profit'] = number_format((float)$nestedData['profit'], 2, '.', '');

                        /*if($nestedData['purchased_qty'] > 0 || $nestedData['transfered_qty'] > 0 || $nestedData['sold_qty'] > 0 || $nestedData['returned_qty'] > 0 || $nestedData['purchase_returned_qty']) {*/
                            $data[] = $nestedData;
                        //}
                    }
                }
                else {
                    $nestedData['key'] = count($data);
                    $nestedData['name'] = $product->name;
                    //purchase data
                    $nestedData['invoice_qty'] = order_detail::select('qty')->where('prod_id', $product->id)->sum('qty');
                  
                    $nestedData['stock_qty'] = add_stock::select('stock_qty')->where('prod_id', $product->id)->sum('stock_qty');
                    $nestedData['purchased_amount'] = ProductPurchase::where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total');

                    $lims_product_purchase_data = ProductPurchase::select('purchase_unit_id', 'qty')->where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->get();

                    $purchased_qty = 0;
                    if(count($lims_product_purchase_data)) {
                        foreach ($lims_product_purchase_data as $product_purchase) {
                            $unit = DB::table('units')->find($product_purchase->purchase_unit_id);
                            if($unit->operator == '*'){
                                $purchased_qty += $product_purchase->qty * $unit->operation_value;
                            }
                            elseif($unit->operator == '/'){
                                $purchased_qty += $product_purchase->qty / $unit->operation_value;
                            }
                        }
                    }
                    $nestedData['purchased_qty'] = $purchased_qty;
                    //transfer data
                    /*$nestedData['transfered_amount'] = ProductTransfer::where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total');

                    $lims_product_transfer_data = ProductTransfer::select('purchase_unit_id', 'qty')->where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->get();

                    $transfered_qty = 0;
                    if(count($lims_product_transfer_data)) {
                        foreach ($lims_product_transfer_data as $product_transfer) {
                            $unit = DB::table('units')->find($product_transfer->purchase_unit_id);
                            if($unit->operator == '*'){
                                $transfered_qty += $product_transfer->qty * $unit->operation_value;
                            }
                            elseif($unit->operator == '/'){
                                $transfered_qty += $product_transfer->qty / $unit->operation_value;
                            }
                        }
                    }
                    $nestedData['transfered_qty'] = $transfered_qty;*/
                    //sale data
                    $nestedData['sold_amount'] = Product_Sale::where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total');

                    $lims_product_sale_data = Product_Sale::select('sale_unit_id', 'qty')->where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->get();

                    $sold_qty = 0;
                    if(count($lims_product_sale_data)) {
                        foreach ($lims_product_sale_data as $product_sale) {
                            $unit = DB::table('units')->find($product_sale->sale_unit_id);
                            if($unit->operator == '*'){
                                $sold_qty += $product_sale->qty * $unit->operation_value;
                            }
                            elseif($unit->operator == '/'){
                                $sold_qty += $product_sale->qty / $unit->operation_value;
                            }
                        }
                    }
                    $nestedData['sold_qty'] = $sold_qty;
                    //return data
                    $nestedData['returned_amount'] = ProductReturn::where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total');

                    $lims_product_return_data = ProductReturn::select('sale_unit_id', 'qty')->where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->get();

                    $returned_qty = 0;
                    if(count($lims_product_return_data)) {
                        foreach ($lims_product_return_data as $product_return) {
                            $unit = DB::table('units')->find($product_return->sale_unit_id);
                            if($unit->operator == '*'){
                                $returned_qty += $product_return->qty * $unit->operation_value;
                            }
                            elseif($unit->operator == '/'){
                                $returned_qty += $product_return->qty / $unit->operation_value;
                            }
                        }
                    }
                    $nestedData['returned_qty'] = $returned_qty;
                    //purchase return data
                    $nestedData['purchase_returned_amount'] = PurchaseProductReturn::where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->sum('total');

                    $lims_product_purchase_return_data = PurchaseProductReturn::select('purchase_unit_id', 'qty')->where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->get();

                    $purchase_returned_qty = 0;
                    if(count($lims_product_purchase_return_data)) {
                        foreach ($lims_product_purchase_return_data as $product_purchase_return) {
                            $unit = DB::table('units')->find($product_purchase_return->purchase_unit_id);
                            if($unit->operator == '*'){
                                $purchase_returned_qty += $product_purchase_return->qty * $unit->operation_value;
                            }
                            elseif($unit->operator == '/'){
                                $purchase_returned_qty += $product_purchase_return->qty / $unit->operation_value;
                            }
                        }
                    }
                    $nestedData['purchase_returned_qty'] = $purchase_returned_qty;

                    if($nestedData['purchased_qty'] > 0)
                            $nestedData['profit'] = $nestedData['sold_amount'] - (($nestedData['purchased_amount'] / $nestedData['purchased_qty']) * $nestedData['sold_qty']);
                    else
                       $nestedData['profit'] =  $nestedData['sold_amount'];
                    $nestedData['in_stock'] = $product->qty;

                    $nestedData['profit'] = number_format((float)$nestedData['profit'], 2, '.', '');
                    /*if($nestedData['purchased_qty'] > 0 || $nestedData['transfered_qty'] > 0 || $nestedData['sold_qty'] > 0 || $nestedData['returned_qty'] > 0 || $nestedData['purchase_returned_qty']) {*/
                        $data[] = $nestedData;
                    //}
                }
            }
            else {
                if($product->is_variant) {
                    $variant_id_all = ProductVariant::where('product_id', $product->id)->pluck('variant_id');

                    foreach ($variant_id_all as $key => $variant_id) {
                        $variant_data = Variant::select('name')->find($variant_id);
                        $nestedData['key'] = count($data);
                        $nestedData['name'] = $product->name . ' [' . $variant_data->name . ']';
                        //purchase data
                        $nestedData['purchased_amount'] = DB::table('purchases')
                                    ->join('product_purchases', 'purchases.id', '=', 'product_purchases.purchase_id')->where([
                                        ['product_purchases.product_id', $product->id],
                                        ['product_purchases.variant_id', $variant_id],
                                        ['purchases.warehouse_id', $warehouse_id]
                                    ])->whereDate('purchases.created_at','>=', $start_date)->whereDate('purchases.created_at','<=', $end_date)->sum('total');
                        $lims_product_purchase_data = DB::table('purchases')
                                    ->join('product_purchases', 'purchases.id', '=', 'product_purchases.purchase_id')->where([
                                        ['product_purchases.product_id', $product->id],
                                        ['product_purchases.variant_id', $variant_id],
                                        ['purchases.warehouse_id', $warehouse_id]
                                    ])->whereDate('purchases.created_at','>=', $start_date)->whereDate('purchases.created_at','<=', $end_date)
                                        ->select('product_purchases.purchase_unit_id', 'product_purchases.qty')
                                        ->get();

                        $purchased_qty = 0;
                        if(count($lims_product_purchase_data)) {
                            foreach ($lims_product_purchase_data as $product_purchase) {
                                $unit = DB::table('units')->find($product_purchase->purchase_unit_id);
                                if($unit->operator == '*'){
                                    $purchased_qty += $product_purchase->qty * $unit->operation_value;
                                }
                                elseif($unit->operator == '/'){
                                    $purchased_qty += $product_purchase->qty / $unit->operation_value;
                                }
                            }
                        }
                        $nestedData['purchased_qty'] = $purchased_qty;
                        //transfer data
                        /*$nestedData['transfered_amount'] = DB::table('transfers')
                                ->join('product_transfer', 'transfers.id', '=', 'product_transfer.transfer_id')
                                ->where([
                                    ['product_transfer.product_id', $product->id],
                                    ['product_transfer.variant_id', $variant_id],
                                    ['transfers.to_warehouse_id', $warehouse_id]
                                ])->whereDate('transfers.created_at', '>=', $start_date)
                                  ->whereDate('transfers.created_at', '<=' , $end_date)
                                  ->sum('total');
                        $lims_product_transfer_data = DB::table('transfers')
                                ->join('product_transfer', 'transfers.id', '=', 'product_transfer.transfer_id')
                                ->where([
                                    ['product_transfer.product_id', $product->id],
                                    ['product_transfer.variant_id', $variant_id],
                                    ['transfers.to_warehouse_id', $warehouse_id]
                                ])->whereDate('transfers.created_at', '>=', $start_date)
                                  ->whereDate('transfers.created_at', '<=' , $end_date)
                                  ->select('product_transfer.purchase_unit_id', 'product_transfer.qty')
                                  ->get();

                        $transfered_qty = 0;
                        if(count($lims_product_transfer_data)) {
                            foreach ($lims_product_transfer_data as $product_transfer) {
                                $unit = DB::table('units')->find($product_transfer->purchase_unit_id);
                                if($unit->operator == '*'){
                                    $transfered_qty += $product_transfer->qty * $unit->operation_value;
                                }
                                elseif($unit->operator == '/'){
                                    $transfered_qty += $product_transfer->qty / $unit->operation_value;
                                }
                            }
                        }
                        $nestedData['transfered_qty'] = $transfered_qty;*/
                        //sale data
                        $nestedData['sold_amount'] = DB::table('sales')
                                    ->join('product_sales', 'sales.id', '=', 'product_sales.sale_id')->where([
                                        ['product_sales.product_id', $product->id],
                                        ['variant_id', $variant_id],
                                        ['sales.warehouse_id', $warehouse_id]
                                    ])->whereDate('sales.created_at','>=', $start_date)->whereDate('sales.created_at','<=', $end_date)->sum('total');
                        $lims_product_sale_data = DB::table('sales')
                                    ->join('product_sales', 'sales.id', '=', 'product_sales.sale_id')->where([
                                        ['product_sales.product_id', $product->id],
                                        ['variant_id', $variant_id],
                                        ['sales.warehouse_id', $warehouse_id]
                                    ])->whereDate('sales.created_at','>=', $start_date)
                                    ->whereDate('sales.created_at','<=', $end_date)
                                    ->select('product_sales.sale_unit_id', 'product_sales.qty')
                                    ->get();

                        $sold_qty = 0;
                        if(count($lims_product_sale_data)) {
                            foreach ($lims_product_sale_data as $product_sale) {
                                $unit = DB::table('units')->find($product_sale->sale_unit_id);
                                if($unit->operator == '*'){
                                    $sold_qty += $product_sale->qty * $unit->operation_value;
                                }
                                elseif($unit->operator == '/'){
                                    $sold_qty += $product_sale->qty / $unit->operation_value;
                                }
                            }
                        }
                        $nestedData['sold_qty'] = $sold_qty;
                        //return data
                        $nestedData['returned_amount'] = DB::table('returns')
                                ->join('product_returns', 'returns.id', '=', 'product_returns.return_id')
                                ->where([
                                    ['product_returns.product_id', $product->id],
                                    ['product_returns.variant_id', $variant_id],
                                    ['returns.warehouse_id', $warehouse_id]
                                ])->whereDate('returns.created_at', '>=', $start_date)
                                  ->whereDate('returns.created_at', '<=' , $end_date)
                                  ->sum('total');

                        $lims_product_return_data = DB::table('returns')
                                ->join('product_returns', 'returns.id', '=', 'product_returns.return_id')
                                ->where([
                                    ['product_returns.product_id', $product->id],
                                    ['product_returns.variant_id', $variant_id],
                                    ['returns.warehouse_id', $warehouse_id]
                                ])->whereDate('returns.created_at', '>=', $start_date)
                                  ->whereDate('returns.created_at', '<=' , $end_date)
                                  ->select('product_returns.sale_unit_id', 'product_returns.qty')
                                  ->get();

                        $returned_qty = 0;
                        if(count($lims_product_return_data)) {
                            foreach ($lims_product_return_data as $product_return) {
                                $unit = DB::table('units')->find($product_return->sale_unit_id);
                                if($unit->operator == '*'){
                                    $returned_qty += $product_return->qty * $unit->operation_value;
                                }
                                elseif($unit->operator == '/'){
                                    $returned_qty += $product_return->qty / $unit->operation_value;
                                }
                            }
                        }
                        $nestedData['returned_qty'] = $returned_qty;
                        //purchase return data
                        $nestedData['purchase_returned_amount'] = DB::table('return_purchases')
                                ->join('purchase_product_return', 'return_purchases.id', '=', 'purchase_product_return.return_id')
                                ->where([
                                    ['purchase_product_return.product_id', $product->id],
                                    ['purchase_product_return.variant_id', $variant_id],
                                    ['return_purchases.warehouse_id', $warehouse_id]
                                ])->whereDate('return_purchases.created_at', '>=', $start_date)
                                  ->whereDate('return_purchases.created_at', '<=' , $end_date)
                                  ->sum('total');
                        $lims_product_purchase_return_data = DB::table('return_purchases')
                                ->join('purchase_product_return', 'return_purchases.id', '=', 'purchase_product_return.return_id')
                                ->where([
                                    ['purchase_product_return.product_id', $product->id],
                                    ['purchase_product_return.variant_id', $variant_id],
                                    ['return_purchases.warehouse_id', $warehouse_id]
                                ])->whereDate('return_purchases.created_at', '>=', $start_date)
                                  ->whereDate('return_purchases.created_at', '<=' , $end_date)
                                  ->select('purchase_product_return.purchase_unit_id', 'purchase_product_return.qty')
                                  ->get();

                        $purchase_returned_qty = 0;
                        if(count($lims_product_purchase_return_data)) {
                            foreach ($lims_product_purchase_return_data as $product_purchase_return) {
                                $unit = DB::table('units')->find($product_purchase_return->purchase_unit_id);
                                if($unit->operator == '*'){
                                    $purchase_returned_qty += $product_purchase_return->qty * $unit->operation_value;
                                }
                                elseif($unit->operator == '/'){
                                    $purchase_returned_qty += $product_purchase_return->qty / $unit->operation_value;
                                }
                            }
                        }
                        $nestedData['purchase_returned_qty'] = $purchase_returned_qty;
                        
                        if($nestedData['purchased_qty'] > 0)
                            $nestedData['profit'] = $nestedData['sold_amount'] - (($nestedData['purchased_amount'] / $nestedData['purchased_qty']) * $nestedData['sold_qty']);
                        else
                           $nestedData['profit'] =  $nestedData['sold_amount'];
                        $product_warehouse = Product_Warehouse::where([
                            ['product_id', $product->id],
                            ['variant_id', $variant_id],
                            ['warehouse_id', $warehouse_id]
                        ])->select('qty')->first();
                        if($product_warehouse)
                            $nestedData['in_stock'] = $product_warehouse->qty;
                        else
                            $nestedData['in_stock'] = 0;

                        $nestedData['profit'] = number_format((float)$nestedData['profit'], 2, '.', '');

                        $data[] = $nestedData;
                    }
                }
                else {
                    $nestedData['key'] = count($data);
                    $nestedData['name'] = $product->name;
                    //purchase data
                    $nestedData['purchased_amount'] = DB::table('purchases')
                                ->join('product_purchases', 'purchases.id', '=', 'product_purchases.purchase_id')->where([
                                    ['product_purchases.product_id', $product->id],
                                    ['purchases.warehouse_id', $warehouse_id]
                                ])->whereDate('purchases.created_at','>=', $start_date)->whereDate('purchases.created_at','<=', $end_date)->sum('total');
                    $lims_product_purchase_data = DB::table('purchases')
                                ->join('product_purchases', 'purchases.id', '=', 'product_purchases.purchase_id')->where([
                                    ['product_purchases.product_id', $product->id],
                                    ['purchases.warehouse_id', $warehouse_id]
                                ])->whereDate('purchases.created_at','>=', $start_date)->whereDate('purchases.created_at','<=', $end_date)
                                    ->select('product_purchases.purchase_unit_id', 'product_purchases.qty')
                                    ->get();

                    $purchased_qty = 0;
                    if(count($lims_product_purchase_data)) {
                        foreach ($lims_product_purchase_data as $product_purchase) {
                            $unit = DB::table('units')->find($product_purchase->purchase_unit_id);
                            if($unit->operator == '*'){
                                $purchased_qty += $product_purchase->qty * $unit->operation_value;
                            }
                            elseif($unit->operator == '/'){
                                $purchased_qty += $product_purchase->qty / $unit->operation_value;
                            }
                        }
                    }
                    $nestedData['purchased_qty'] = $purchased_qty;
                    //transfer data
                    /*$nestedData['transfered_amount'] = DB::table('transfers')
                            ->join('product_transfer', 'transfers.id', '=', 'product_transfer.transfer_id')
                            ->where([
                                ['product_transfer.product_id', $product->id],
                                ['transfers.to_warehouse_id', $warehouse_id]
                            ])->whereDate('transfers.created_at', '>=', $start_date)
                              ->whereDate('transfers.created_at', '<=' , $end_date)
                              ->sum('total');
                    $lims_product_transfer_data = DB::table('transfers')
                            ->join('product_transfer', 'transfers.id', '=', 'product_transfer.transfer_id')
                            ->where([
                                ['product_transfer.product_id', $product->id],
                                ['transfers.to_warehouse_id', $warehouse_id]
                            ])->whereDate('transfers.created_at', '>=', $start_date)
                              ->whereDate('transfers.created_at', '<=' , $end_date)
                              ->select('product_transfer.purchase_unit_id', 'product_transfer.qty')
                              ->get();

                    $transfered_qty = 0;
                    if(count($lims_product_transfer_data)) {
                        foreach ($lims_product_transfer_data as $product_transfer) {
                            $unit = DB::table('units')->find($product_transfer->purchase_unit_id);
                            if($unit->operator == '*'){
                                $transfered_qty += $product_transfer->qty * $unit->operation_value;
                            }
                            elseif($unit->operator == '/'){
                                $transfered_qty += $product_transfer->qty / $unit->operation_value;
                            }
                        }
                    }
                    $nestedData['transfered_qty'] = $transfered_qty;*/
                    //sale data
                    $nestedData['sold_amount'] = DB::table('sales')
                                ->join('product_sales', 'sales.id', '=', 'product_sales.sale_id')->where([
                                    ['product_sales.product_id', $product->id],
                                    ['sales.warehouse_id', $warehouse_id]
                                ])->whereDate('sales.created_at','>=', $start_date)->whereDate('sales.created_at','<=', $end_date)->sum('total');
                    $lims_product_sale_data = DB::table('sales')
                                ->join('product_sales', 'sales.id', '=', 'product_sales.sale_id')->where([
                                    ['product_sales.product_id', $product->id],
                                    ['sales.warehouse_id', $warehouse_id]
                                ])->whereDate('sales.created_at','>=', $start_date)
                                ->whereDate('sales.created_at','<=', $end_date)
                                ->select('product_sales.sale_unit_id', 'product_sales.qty')
                                ->get();

                    $sold_qty = 0;
                    if(count($lims_product_sale_data)) {
                        foreach ($lims_product_sale_data as $product_sale) {
                            $unit = DB::table('units')->find($product_sale->sale_unit_id);
                            if($unit->operator == '*'){
                                $sold_qty += $product_sale->qty * $unit->operation_value;
                            }
                            elseif($unit->operator == '/'){
                                $sold_qty += $product_sale->qty / $unit->operation_value;
                            }
                        }
                    }
                    $nestedData['sold_qty'] = $sold_qty;
                    //return data
                    $nestedData['returned_amount'] = DB::table('returns')
                            ->join('product_returns', 'returns.id', '=', 'product_returns.return_id')
                            ->where([
                                ['product_returns.product_id', $product->id],
                                ['returns.warehouse_id', $warehouse_id]
                            ])->whereDate('returns.created_at', '>=', $start_date)
                              ->whereDate('returns.created_at', '<=' , $end_date)
                              ->sum('total');

                    $lims_product_return_data = DB::table('returns')
                            ->join('product_returns', 'returns.id', '=', 'product_returns.return_id')
                            ->where([
                                ['product_returns.product_id', $product->id],
                                ['returns.warehouse_id', $warehouse_id]
                            ])->whereDate('returns.created_at', '>=', $start_date)
                              ->whereDate('returns.created_at', '<=' , $end_date)
                              ->select('product_returns.sale_unit_id', 'product_returns.qty')
                              ->get();

                    $returned_qty = 0;
                    if(count($lims_product_return_data)) {
                        foreach ($lims_product_return_data as $product_return) {
                            $unit = DB::table('units')->find($product_return->sale_unit_id);
                            if($unit->operator == '*'){
                                $returned_qty += $product_return->qty * $unit->operation_value;
                            }
                            elseif($unit->operator == '/'){
                                $returned_qty += $product_return->qty / $unit->operation_value;
                            }
                        }
                    }
                    $nestedData['returned_qty'] = $returned_qty;
                    //purchase return data
                    $nestedData['purchase_returned_amount'] = DB::table('return_purchases')
                            ->join('purchase_product_return', 'return_purchases.id', '=', 'purchase_product_return.return_id')
                            ->where([
                                ['purchase_product_return.product_id', $product->id],
                                ['return_purchases.warehouse_id', $warehouse_id]
                            ])->whereDate('return_purchases.created_at', '>=', $start_date)
                              ->whereDate('return_purchases.created_at', '<=' , $end_date)
                              ->sum('total');
                    $lims_product_purchase_return_data = DB::table('return_purchases')
                            ->join('purchase_product_return', 'return_purchases.id', '=', 'purchase_product_return.return_id')
                            ->where([
                                ['purchase_product_return.product_id', $product->id],
                                ['return_purchases.warehouse_id', $warehouse_id]
                            ])->whereDate('return_purchases.created_at', '>=', $start_date)
                              ->whereDate('return_purchases.created_at', '<=' , $end_date)
                              ->select('purchase_product_return.purchase_unit_id', 'purchase_product_return.qty')
                              ->get();

                    $purchase_returned_qty = 0;
                    if(count($lims_product_purchase_return_data)) {
                        foreach ($lims_product_purchase_return_data as $product_purchase_return) {
                            $unit = DB::table('units')->find($product_purchase_return->purchase_unit_id);
                            if($unit->operator == '*'){
                                $purchase_returned_qty += $product_purchase_return->qty * $unit->operation_value;
                            }
                            elseif($unit->operator == '/'){
                                $purchase_returned_qty += $product_purchase_return->qty / $unit->operation_value;
                            }
                        }
                    }
                    $nestedData['purchase_returned_qty'] = $purchase_returned_qty;

                    if($nestedData['purchased_qty'] > 0)
                            $nestedData['profit'] = $nestedData['sold_amount'] - (($nestedData['purchased_amount'] / $nestedData['purchased_qty']) * $nestedData['sold_qty']);
                    else
                       $nestedData['profit'] =  $nestedData['sold_amount'];

                    $product_warehouse = Product_Warehouse::where([
                        ['product_id', $product->id],
                        ['warehouse_id', $warehouse_id]
                    ])->select('qty')->first();
                    if($product_warehouse)
                        $nestedData['in_stock'] = $product_warehouse->qty;
                    else
                        $nestedData['in_stock'] = 0;

                    $nestedData['profit'] = number_format((float)$nestedData['profit'], 2, '.', '');
                    
                    $data[] = $nestedData;
                }
            }
        }
       
        /*$totalData = count($data);
        $totalFiltered = $totalData;*/
        $json_data = array(
            "draw"            => intval($request->input('draw')),  
            "recordsTotal"    => intval($totalData),  
            "recordsFiltered" => intval($totalFiltered), 
            "data"            => $data   
        );
            
        echo json_encode($json_data);
    }

    public function purchaseReport(Request $request)
    {
    	$data = $request->all();
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $warehouse_id = $data['warehouse_id'];
        $product_id = [];
        $variant_id = [];
        $product_name = [];
        $product_qty = [];
        $lims_product_all = Product::select('id', 'name', 'qty', 'is_variant')->where('is_active', true)->get();
        foreach ($lims_product_all as $product) {
            $lims_product_purchase_data = null;
            $variant_id_all = [];
            if($warehouse_id == 0) {
                if($product->is_variant)
                    $variant_id_all = ProductPurchase::distinct('variant_id')->where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->pluck('variant_id');
                else
                    $lims_product_purchase_data = ProductPurchase::where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->first();
            }
            else {
                if($product->is_variant)
                    $variant_id_all = DB::table('purchases')
                        ->join('product_purchases', 'purchases.id', '=', 'product_purchases.purchase_id')
                        ->distinct('variant_id')
                        ->where([
                            ['product_purchases.product_id', $product->id],
                            ['purchases.warehouse_id', $warehouse_id]
                        ])->whereDate('purchases.created_at','>=', $start_date)
                          ->whereDate('purchases.created_at','<=', $end_date)
                          ->pluck('variant_id');
                else
                    $lims_product_purchase_data = DB::table('purchases')
                        ->join('product_purchases', 'purchases.id', '=', 'product_purchases.purchase_id')->where([
                                ['product_purchases.product_id', $product->id],
                                ['purchases.warehouse_id', $warehouse_id]
                        ])->whereDate('purchases.created_at','>=', $start_date)
                          ->whereDate('purchases.created_at','<=', $end_date)
                          ->first();
            }

            if($lims_product_purchase_data) {
                $product_name[] = $product->name;
                $product_id[] = $product->id;
                $variant_id[] = null;
                if($warehouse_id == 0)
                    $product_qty[] = $product->qty;
                else
                    $product_qty[] = Product_Warehouse::where([
                                    ['product_id', $product->id],
                                    ['warehouse_id', $warehouse_id]
                                ])->sum('qty');
            }
            elseif(count($variant_id_all)) {
                foreach ($variant_id_all as $key => $variantId) {
                    $variant_data = Variant::find($variantId);
                    $product_name[] = $product->name.' ['.$variant_data->name.']';
                    $product_id[] = $product->id;
                    $variant_id[] = $variant_data->id;
                    if($warehouse_id == 0)
                        $product_qty[] = ProductVariant::FindExactProduct($product->id, $variant_data->id)->first()->qty;
                    else
                        $product_qty[] = Product_Warehouse::where([
                                        ['product_id', $product->id],
                                        ['variant_id', $variant_data->id],
                                        ['warehouse_id', $warehouse_id]
                                    ])->first()->qty;
                    
                }
            }
        }
        $lims_warehouse_list = Warehouse::where('is_active', true)->get();
        return view('report.purchase_report',compact('product_id', 'variant_id', 'product_name', 'product_qty', 'start_date', 'end_date', 'lims_warehouse_list', 'warehouse_id'));
    }

    public function saleReport(Request $request)
    {
    	$data = $request->all();
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $warehouse_id = $data['warehouse_id'];
        $product_id = [];
        $variant_id = [];
        $product_name = [];
        $product_qty = [];
        $lims_product_all = Product::select('id', 'name', 'qty', 'is_variant')->where('is_active', true)->get();
        
        foreach ($lims_product_all as $product) {
            $lims_product_sale_data = null;
            $variant_id_all = [];
            if($warehouse_id == 0){
                if($product->is_variant)
                    $variant_id_all = Product_Sale::distinct('variant_id')->where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->pluck('variant_id');
                else
                    $lims_product_sale_data = Product_Sale::where('product_id', $product->id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->first();
            }
            else {
                if($product->is_variant)
                    $variant_id_all = DB::table('sales')
                        ->join('product_sales', 'sales.id', '=', 'product_sales.sale_id')
                        ->distinct('variant_id')
                        ->where([
                            ['product_sales.product_id', $product->id],
                            ['sales.warehouse_id', $warehouse_id]
                        ])->whereDate('sales.created_at','>=', $start_date)
                          ->whereDate('sales.created_at','<=', $end_date)
                          ->pluck('variant_id');
                else
                    $lims_product_sale_data = DB::table('sales')
                            ->join('product_sales', 'sales.id', '=', 'product_sales.sale_id')->where([
                                    ['product_sales.product_id', $product->id],
                                    ['sales.warehouse_id', $warehouse_id]
                            ])->whereDate('sales.created_at','>=', $start_date)
                              ->whereDate('sales.created_at','<=', $end_date)
                              ->first();
            }
            if($lims_product_sale_data) {
                $product_name[] = $product->name;
                $product_id[] = $product->id;
                $variant_id[] = null;
                if($warehouse_id == 0)
                    $product_qty[] = $product->qty;
                else {
                    $product_qty[] = Product_Warehouse::where([
                                    ['product_id', $product->id],
                                    ['warehouse_id', $warehouse_id]
                                ])->sum('qty');
                }
            }
            elseif(count($variant_id_all)) {
                foreach ($variant_id_all as $key => $variantId) {
                    $variant_data = Variant::find($variantId);
                    $product_name[] = $product->name.' ['.$variant_data->name.']';
                    $product_id[] = $product->id;
                    $variant_id[] = $variant_data->id;
                    if($warehouse_id == 0)
                        $product_qty[] = ProductVariant::FindExactProduct($product->id, $variant_data->id)->first()->qty;
                    else
                        $product_qty[] = Product_Warehouse::where([
                                        ['product_id', $product->id],
                                        ['variant_id', $variant_data->id],
                                        ['warehouse_id', $warehouse_id]
                                    ])->first()->qty;
                    
                }
            }
        }
        $lims_warehouse_list = Warehouse::where('is_active', true)->get();
        return view('report.sale_report',compact('product_id', 'variant_id', 'product_name', 'product_qty', 'start_date', 'end_date', 'lims_warehouse_list','warehouse_id'));
    }

    public function paymentReportByDate(Request $request)
    {
        $data = $request->all();
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        
        $lims_payment_data = Payment::whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->get();
        return view('report.payment_report',compact('lims_payment_data', 'start_date', 'end_date'));
    }

    public function warehouseReport(Request $request)
    {
        $data = $request->all();
        $warehouse_id = $data['warehouse_id'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];

        $lims_purchase_data = Purchase::where('warehouse_id', $warehouse_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();
        $lims_sale_data = Sale::with('customer')->where('warehouse_id', $warehouse_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();
        $lims_quotation_data = Quotation::with('customer')->where('warehouse_id', $warehouse_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();
        $lims_return_data = Returns::with('customer', 'biller')->where('warehouse_id', $warehouse_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();
        $lims_expense_data = Expense::with('expenseCategory')->where('warehouse_id', $warehouse_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();

        $lims_product_purchase_data = [];
        $lims_product_sale_data = [];
        $lims_product_quotation_data = [];
        $lims_product_return_data = [];

        foreach ($lims_purchase_data as $key => $purchase) {
            $lims_product_purchase_data[$key] = ProductPurchase::where('purchase_id', $purchase->id)->get();
        }
        foreach ($lims_sale_data as $key => $sale) {
            $lims_product_sale_data[$key] = Product_Sale::where('sale_id', $sale->id)->get();
        }
        foreach ($lims_quotation_data as $key => $quotation) {
            $lims_product_quotation_data[$key] = ProductQuotation::where('quotation_id', $quotation->id)->get();
        }
        foreach ($lims_return_data as $key => $return) {
            $lims_product_return_data[$key] = ProductReturn::where('return_id', $return->id)->get();
        }
        $lims_warehouse_list = Warehouse::where('is_active', true)->get();
        return view('report.warehouse_report', compact('warehouse_id', 'start_date', 'end_date', 'lims_purchase_data', 'lims_product_purchase_data', 'lims_sale_data', 'lims_product_sale_data', 'lims_warehouse_list', 'lims_quotation_data', 'lims_product_quotation_data', 'lims_return_data', 'lims_product_return_data', 'lims_expense_data'));
    }

    public function userReport(Request $request)
    {
        $data = $request->all();
        $user_id = $data['user_id'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $lims_product_sale_data = [];
        $lims_product_purchase_data = [];
        $lims_product_quotation_data = [];
        $lims_product_transfer_data = [];

        $lims_sale_data = Sale::with('customer', 'warehouse')->where('user_id', $user_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();
        $lims_purchase_data = Purchase::with('warehouse')->where('user_id', $user_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();        
        $lims_quotation_data = Quotation::with('customer', 'warehouse')->where('user_id', $user_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();
        $lims_transfer_data = Transfer::with('fromWarehouse', 'toWarehouse')->where('user_id', $user_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();        
        $lims_payment_data = DB::table('payments')
                           ->where('user_id', $user_id)
                           ->whereDate('payments.created_at', '>=' , $start_date)
                           ->whereDate('payments.created_at', '<=' , $end_date)
                           ->orderBy('created_at', 'desc')
                           ->get();
        $lims_expense_data = Expense::with('warehouse', 'expenseCategory')->where('user_id', $user_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();
        $lims_payroll_data = Payroll::with('employee')->where('user_id', $user_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();

        foreach ($lims_sale_data as $key => $sale) {
            $lims_product_sale_data[$key] = Product_Sale::where('sale_id', $sale->id)->get();
        }
        foreach ($lims_purchase_data as $key => $purchase) {
            $lims_product_purchase_data[$key] = ProductPurchase::where('purchase_id', $purchase->id)->get();
        }
        foreach ($lims_quotation_data as $key => $quotation) {
            $lims_product_quotation_data[$key] = ProductQuotation::where('quotation_id', $quotation->id)->get();
        }
        foreach ($lims_transfer_data as $key => $transfer) {
            $lims_product_transfer_data[$key] = ProductTransfer::where('transfer_id', $transfer->id)->get();
        }

        $lims_user_list = User::where('is_active', true)->get();
        return view('report.user_report', compact('lims_sale_data','user_id', 'start_date', 'end_date', 'lims_product_sale_data', 'lims_payment_data', 'lims_user_list', 'lims_purchase_data', 'lims_product_purchase_data', 'lims_quotation_data', 'lims_product_quotation_data', 'lims_transfer_data', 'lims_product_transfer_data', 'lims_expense_data', 'lims_payroll_data') );
    }

    public function customerReport(Request $request)
    {
    	$data = $request->all();
        $customer_id = $data['customer_id'];
        // $start_date = $data['start_date'];
        // $end_date = $data['end_date'];
       

        //dd($lims_product_data[0]);
        $lims_sale_data = Sale::with('warehouse')->where('customer_id', $customer_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();
        $lims_quotation_data = Quotation::with('warehouse')->where('customer_id', $customer_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();
        $lims_return_data = Returns::with('warehouse', 'biller')->where('customer_id', $customer_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();
        $lims_payment_data = DB::table('payments')
                           ->join('sales', 'payments.sale_id', '=', 'sales.id')
                           ->where('customer_id', $customer_id)
                           ->whereDate('payments.created_at', '>=' , $start_date)
                           ->whereDate('payments.created_at', '<=' , $end_date)
                           ->select('payments.*', 'sales.reference_no as sale_reference')
                           ->orderBy('payments.created_at', 'desc')
                           ->get();

        $lims_product_sale_data = [];
        $lims_product_quotation_data = [];
        $lims_product_return_data = [];

        foreach ($lims_sale_data as $key => $sale) {
            $lims_product_sale_data[$key] = Product_Sale::where('sale_id', $sale->id)->get();
        }
        foreach ($lims_quotation_data as $key => $quotation) {
            $lims_product_quotation_data[$key] = ProductQuotation::where('quotation_id', $quotation->id)->get();
        }
        foreach ($lims_return_data as $key => $return) {
            $lims_product_return_data[$key] = ProductReturn::where('return_id', $return->id)->get();
        }
        $lims_customer_list = Customer::where('is_active', true)->get();
        return view('report.customer_report', compact('lims_sale_data','customer_id', 'start_date', 'end_date', 'lims_product_sale_data', 'lims_payment_data', 'lims_customer_list', 'lims_quotation_data', 'lims_product_quotation_data', 'lims_return_data', 'lims_product_return_data'));
    }

    public function supplierReport(Request $request)
    {
        $data = $request->all();
        $supplier_id = $data['supplier_id'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $lims_purchase_data = Purchase::with('warehouse')->where('supplier_id', $supplier_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();
        $lims_quotation_data = Quotation::with('warehouse', 'customer')->where('supplier_id', $supplier_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();
        $lims_return_data = ReturnPurchase::with('warehouse')->where('supplier_id', $supplier_id)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->orderBy('created_at', 'desc')->get();
        $lims_payment_data = DB::table('payments')
                           ->join('purchases', 'payments.purchase_id', '=', 'purchases.id')
                           ->where('supplier_id', $supplier_id)
                           ->whereDate('payments.created_at', '>=' , $start_date)
                           ->whereDate('payments.created_at', '<=' , $end_date)
                           ->select('payments.*', 'purchases.reference_no as purchase_reference')
                           ->orderBy('payments.created_at', 'desc')
                           ->get();

        $lims_product_purchase_data = [];
        $lims_product_quotation_data = [];
        $lims_product_return_data = [];

        foreach ($lims_purchase_data as $key => $purchase) {
            $lims_product_purchase_data[$key] = ProductPurchase::where('purchase_id', $purchase->id)->get();
        }
        foreach ($lims_return_data as $key => $return) {
            $lims_product_return_data[$key] = PurchaseProductReturn::where('return_id', $return->id)->get();
        }
        foreach ($lims_quotation_data as $key => $quotation) {
            $lims_product_quotation_data[$key] = ProductQuotation::where('quotation_id', $quotation->id)->get();
        }
        $lims_supplier_list = Supplier::where('is_active', true)->get();
        return view('report.supplier_report', compact('lims_purchase_data', 'lims_product_purchase_data', 'lims_payment_data', 'supplier_id', 'start_date', 'end_date', 'lims_supplier_list', 'lims_quotation_data', 'lims_product_quotation_data', 'lims_return_data', 'lims_product_return_data'));
    }

    public function dueReportByDate(Request $request)
    {
    	$data = $request->all();
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $lims_sale_data = Sale::where('payment_status', '!=', 4)->whereDate('created_at', '>=' , $start_date)->whereDate('created_at', '<=' , $end_date)->get();

        return view('report.due_report', compact('lims_sale_data', 'start_date', 'end_date'));
    }



// new reporting methods

public function distributor_expanse(Request $request)
    {

        

       
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('unit')) {
         

            // $Account_head = Account_head::get();
            $CliamHead = CliamHead::orderBy('claim_code','ASC')->get()->pluck('cliam')->toArray();

            $companyhead[] = Company_Head::get();


//    $atten_create= DB::connection('mysql2')->table('atten_creates')->get();

// dd($atten_create);

//             $repor_distributor=  DB::select(DB::raw("SELECT cust.distribution_name, ad.claimtype, ad.total from customers cust inner join (SELECT distid, claimtype, sum(amount) as total from add_cliams as ad WHERE (ad.recdate BETWEEN '2022-07-01' AND '2022-07-30') group by distid) as ad on ad.claimtype=cust.id order by ad.distid desc"));
          
// dd($repor_distributor);
            
            $start_date=$request->start_date;
            $end_date=$request->end_date;

     
            if($start_date!=null && $end_date!=null )
            {
                // $start_date=date('Y-07-01');
                // $end_date=date('Y-07-t');

                // $repor_distributor=  DB::select(DB::raw("SELECT cust.distribution_name, ad.claimtype, ad.total from customers cust inner join (SELECT distid, claimtype, sum(amount) as total from add_cliams as ad WHERE (ad.recdate BETWEEN '$start_date' AND '$end_date') group by distid) as ad on ad.claimtype=cust.id order by ad.distid desc"));
                $repor_distributor= Customer::with(['addcliam' => function ($attend) use ($start_date,$end_date)  {
                    return $attend->with('cliamtype')->whereBetween('recdate',[$start_date,$end_date])->selectRaw('claimtype,distid,SUM(amount) as amount')->groupBy('distid','claimtype')->orderBy('claimtype','DESC');
                     
                    ;},
             ] )->get()->toArray();
             
            }else{
                $start_date=date('Y-m-01');
                $end_date=date('Y-m-t');
                //  $repor_distributor=  DB::select(DB::raw("SELECT cust.distribution_name, ad.claimtype, ad.total from customers cust inner join (SELECT distid, claimtype, sum(amount) as total from add_cliams as ad WHERE (ad.recdate BETWEEN '$start_date' AND '$end_date') group by distid) as ad on ad.claimtype=cust.id order by ad.distid desc"));
                $repor_distributor= Customer::with(['addcliam' => function ($attend) use ($start_date,$end_date)  {
                    return $attend->with('cliamtype')->whereBetween('recdate',[$start_date,$end_date])->selectRaw('claimtype,distid,SUM(amount) as amount')->groupBy('distid','claimtype')->orderBy('claimtype','DESC');
                    ;},
             ] )->get()->toArray();
             
            }
          //  dd($repor_distributor[1]);


           


            return view('report.reports.distributionExpSum', 
            [
                'report_distributor'=>$repor_distributor,
                'CliamHead'=>$CliamHead,
                'start_date'=>$start_date,
                'end_date'=>$end_date

            ]);
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');


    }






    
public function primary_report_townwise(Request $request)
{
    $xml = simplexml_load_file('https://api.ikonka.com.pl/api2/index.php/request/?format=xml&hash=3437941c43bd4ad07d8abfc8b04c7e4937f9d791&variant=b&lang=LT');
    
    
    $json = json_encode($xml);
    $array = json_decode($json,TRUE);

    dd($array);
   $data= $request->all();

    $start_date =$request->start_date;
    $end_date = $request->end_date;
    $customer_id = $request->customer_id;
    $zone_code = $request->zone_code;
    $territory_name = $request->territory_name;
    // dd( $zone_code);
    $lims_product_data='';
    $customer=[];

    
   if( $zone_code!=null && $territory_name==null){
    $zone_id=  Zone::where('zone_name', $zone_code)->get()->pluck('zone_code')->toArray();
    $Territory_id=  Territory::where('zone_code', $zone_id)->get()->pluck('territory_name')->toArray();
    $town_id=  Town::whereIn('territory_name', $Territory_id)->get()->pluck('id')->toArray();
    $customer= Customer::whereIn('city',$town_id)->get()->pluck('id')->toArray();

  //  dd($customer);
   }else if($territory_name!=null && $customer_id==null)
   {
    $town_id=  Town::where('territory_name', $territory_name)->get()->pluck('id')->toArray();
    $customer= Customer::whereIn('city',$town_id)->get()->pluck('id')->toArray();
   }else
   {

    // $town_id=  Town::where('territory_name', $territory_name)->get()->pluck('id')->toArray();

    $customer= Customer::where('id',$customer_id)->get()->pluck('id')->toArray();

  
    // $town_id=  Town::where('territory_name', $territory_name)->get()->pluck('id')->toArray();
   }





    $start_date=date('Y-09-01');
                $end_date=date('Y-09-t');
                
    $employee= DB::connection('mysql2')->table('employee')->where('status',1)->get();

   $data=[];

   $execution['town'] = Town::orderBy('id','ASC')->where('is_active',true)->get()->pluck('town_name','id')->toArray();

   $execution['execution1']=DB::connection('mysql2')->select(DB::raw("SELECT sum(ac.exec) as Execution, ac.area as areatown ,Totaltarget, sum(ac.prshop) as PR_Shop FROM `atten_creates` ac inner join employee e on e.employee_id=ac.user_id left join (select adt.base_town, adt.employee ,Sum(adt.target) as Totaltarget FROM add_targets adt WHERE (adt.month_start>='$start_date' AND adt.month_end<='$end_date') GROUP by adt.base_town) as adt on adt.base_town=ac.area where (ac.date BETWEEN '$start_date' AND '$end_date') group by ac.area"));



$execution['repor_distributor']= Customer::orderBy('territory','DESC')->where('is_active',true)->with(['productSale' => function ($attend) use ($start_date,$end_date)  {
    return $attend->whereBetween('created_at',[$start_date,$end_date])->selectRaw('dist_id,SUM(total) as totalInvoice')->groupBy('dist_id');
     ;
    },
] )->withSum('addcliam','add_cliams.amount')->get()->toArray();
// dd($execution['execution1']);


$lims_customer_list = Customer::where('is_active', true)->get();
    $zones = Zone::where('is_active', true)->get();
    $territory = Territory::where('is_active', true)->get();

return view('report.reports.primaryReport', 
[
    'lims_customer_list'=>$lims_customer_list,
    'zones'=>$zones,
    'territory_name'=>$territory_name,
    'zone_code'=>$zone_code,
    'customer_id'=>$customer_id,
    'territory'=>$territory,
    'primary_report'=>$execution,
    'start_date'=>$start_date,

    'end_date'=>$end_date,

    

]);


}


public function mdo_wise_report(Request $request)
{

    $client =  new \GuzzleHttp\Client();
  $api=  $client->get('https://testapp.stanleyfoods.com/api/attendance_var');
    
    dd(json_decode($api->getBody()));
    $start_date=date('Y-m-01');
                $end_date=date('Y-m-t');

    $employee= DB::connection('mysql2')->table('employee')->orderBy("zoneAr",'ASC')->whereNotIn('designation_id', [35,36,37,38,39,40,41,42,43,45])->where('status',1)->get();
  // dd($employee);
   $data=[];

   foreach($employee as $employee_data){
    $execution['employeeName']=$employee_data->first_name.' '.$employee_data->last_name;
    $execution['Town']=$employee_data->zoneAr;
    $execution['designation']= DB::connection('mysql2')->table('designation')->where('designation_id',$employee_data->designation_id)->get()->pluck('designation_name')->toArray();
    $execution['execution_data']= DB::connection('mysql2')->table('atten_creates')->where('user_id',$employee_data->employee_id)->whereBetween('date',[$start_date,$end_date])->get();
    $execution['target']= DB::connection('mysql2')->table('add_targets')->where('employee',$employee_data->employee_id)->where('month_start','=',$start_date)->where('month_end','=',$end_date)->get()->pluck('target')->toArray();
    $execution['execution_sum']= DB::connection('mysql2')->table('atten_creates')->where('user_id',$employee_data->employee_id)->whereBetween('date',[$start_date,$end_date])->sum('exec');
$data[]=$execution;
}

//dd($data);



return view('report.reports.mdowiseReport', 
[
    'primary_report'=>$data,
    'start_date'=>$start_date,

    'end_date'=>$end_date,

    

]);


}



public function get_territory(Request $request)
{
   
   
    $zone = Zone::where('is_active', true)->where('zone_name',$request->zone_code)->first();
    $territory = Territory::where('is_active', true)->where('zone_code',$zone->zone_code)->get();
   // dd();
// $html='<option value=""> select prduct</option>';
//        foreach($lims_product_list as $product){
//         $html.="<option value='".$product->id ."'>" .$product->name ."</option>";
//        }

//        echo $html;

//dd($lims_product_list);
   return response()->json(
   $territory,
    
);
    
}
public function get_town(Request $request)
{
    
   
    $town = Town::where('is_active', true)->where('territory_name',$request->territory_name)->get()->toArray();
    
     
  
    // $town_name = Town::where('is_active', true)->whereIn('id',$customer->city)->get()->pluck('town_name')->toArray();
 
// $html='<option value=""> select prduct</option>';
//        foreach($lims_product_list as $product){
//         $html.="<option value='".$product->id ."'>" .$product->name ."</option>";
//        }

//        echo $html;

//dd($lims_product_list);
   return response()->json(
    
        $town,
        
    
 
    
);
    
}



// print_history_summary_wh
public function print_history_summary_wh(Request $request){
 
    if(Auth::user()->role_id > 2 ){
        $recent_sale=[];
        
       
     $warehouseName=  warehouse::where('id',Auth::user()->warehouse_id)->first();
   
        $start_date= $request->start_date  ;
        $end_date=   $request->end_date ;
       
        $invoice_type =    $request->invoice_type;
        $warehouse_id =    $request->warehouse_id;
        $payment_type =    1;
        
       
    
       $add_stock= add_stock::get()->toArray();
    if($payment_type==1){
        if($start_date!=null && $end_date!=null )
        {
      //dd('gg');
    
    ///setQueryLog();
    
    $recent_sale = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->with('orderdetail')->where('warehouse',Auth::user()->warehouse_id)->where('status',1)->get();
      
    
    
      //dd(getQueryLog());
    
     
      
    //   }else if($start_date!=null && $end_date!=null ){
       
       
    // $recent_sale = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->with('orderdetail')->where('warehouse',Auth::user()->warehouse_id)->where('status',1)->get();
      

      }else{
        $end_date=date('Y-m-t');
       $start_date=date('Y-09-01');
       
    $recent_sale = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->with('orderdetail')->where('warehouse',Auth::user()->warehouse_id)->where('status',1)->get();
      
    
    
      }
      
     
    
      }
    
     
    
      $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));
    
      if($end_date==null && $start_date==null){
    
       $end_date=date('Y-m-t');
       $start_date=date('Y-m-01');
    }
    
    
    
    
    
    $companyhead  = Company_Head::get();
    $Warehouse = Warehouse::where('is_active',1)->get();
    $townName='';
    $distributerName='';
     $distributer_all = Customer::where('is_active',1)->get();
    }else{
        $recent_sale=[];
       
        $start_date= $request->start_date  ;
        $end_date=   $request->end_date ;
       
        $invoice_type=    $request->invoice_type;
        $add_stock= add_stock::get()->pluck('prod_sale')->toArray();
        $warehouse_id =    $request->warehouse_id;
        $payment_type=    1;
        
  //  dd($add_stock);
    
    if($payment_type==1){
        if($start_date!=null && $end_date!=null && $invoice_type==null && $warehouse_id==null)
        {
      //dd('gg');
    
    ///setQueryLog();
    
    $recent_sale = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->with('orderdetail')->where('status',1)->get();
      
    
    
      //dd(getQueryLog());
    
     
      
      }else if($start_date!=null && $end_date!=null  && $warehouse_id!=null){
       
       
    $recent_sale = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date." 00:00:00",$end_date." 23:59:59"])->with('orderdetail')->whereNotIn('id',$add_stock)->where('warehouse',$warehouse_id)->where('status',1)->get();
      
    
   
    
      }else{
    
    
    
      }
      
     
    
      }
    
     
    
      $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));
    
      if($end_date==null && $start_date==null){
    
       $end_date=date('Y-m-t');
       $start_date=date('Y-m-01');
    }
    
    
    
    
    
    $companyhead  = Company_Head::get();
    
    $Warehouse = Warehouse::where('is_active',1)->get();
    $townName='';
    $distributerName='';
     $distributer_all = Customer::where('is_active',1)->get();
    
          
    }
     
     
     return view('report.reports.print_history_warehouse',[
       'distributer_all'=>$distributer_all,
       
       'warehouse'=>$Warehouse,
       'warehouse_id'=>$warehouse_id,
       'companyhead'=>$companyhead,
       'payment_type'=>$payment_type,
       'invoice_type'=>$invoice_type,
       
       'customer'=>$distributerName,
       'invoice'=>$recent_sale,
       
      
       'prevdate'=>$prevdate,
       'start_date'=>$start_date,
      'end_date'=>$end_date,
    
    
    ]);
}


public function print_history_summary_wh_sum_pdf(Request $request){
    $invoiceIdArray1 = $request['invoiceIdArray'];

  
    // $prod_sale_data = [];
    $orderid=[];
    $prod_sale_id=[];
    $customer_name=  Customer::where('warehouse_id',$request['warehouse_id'])->first();


    $serial_num = generate_serial_num('Sum_Inc');
             
    increament_serial_num('Sum_Inc');
  //dd($request['drno'] );
   try{
   


    foreach ($invoiceIdArray1 as $id) {
           
        $prod_sale_id[]=$id;
          $prod_sale_data[] = Product_Sale::where('id',$id)->with('customer')
          ->with(['orderdetail'=>function($query){
               // $query->orderBy('prod_code','ASC')->orderBy('id',"ASC");
           }])->get();
          
          
               
      

   
           
            
                $town_name=Town::where('id',$prod_sale_data[0][0]->customer->city)->first();
              
                 $regular= "S-F";
                
                $data=[
                       'order'=>$prod_sale_data,
                        'regular'=>$regular,
                        'town_name'=>$town_name,
                       
                        'drname'=>$request['drname'],
                        'customer_detail'=>$customer_name,
                        'drno'=>$request['drno'],
                        'serial_num'=>$serial_num,
                     
                   ];
   
                   
                 }

                 $sammary['warehouse_id']=$prod_sale_data[0][0]->warehouse;
                 $sammary['sum_inv_no']=$serial_num;
                 $sammary['date']=date('Y-m-d');
                 $sammary['drname']=$request['drname'];
                 $sammary['drno']=$request['drno'];
                 $sammary['prod_sale_id']= implode(",",$prod_sale_id);
                 warehouseSummary::insert($sammary);
        
       foreach($prod_sale_data as $key =>$value){
      
        $order['warehouse_id']=$value[0]->warehouse;
        foreach($value[0]->orderdetail as $value1){
            
            $order['prod_id']=$value1->prod_id;
        $order['date']=date('Y-m-d');
      $order['stock_qty']= $value1->qty;

     
      $order['prod_sale']=$value1->prod_sale_id;
      add_stock::insert($order);
      
     

        }

  
       }

   
$s=0;
              
              
                 
          
            
                
                   $pdf = PDF::loadView('report.reports.printing_invoices_summary_wh',$data);
           $pdf->setPaper('A4', 'LandScape');
    
           return $pdf->stream("Invoce.pdf");
       } catch(Exception $e)
       {
       
           $s = $e->getMessage();
           
           $d=$s;
       }



       
}



public function print_wh_summary(Request $request){


    if(Auth::user()->role_id > 2 ){

        if($request->start_date!=null && $request->end_date!=null  ){
            $warehouse_detail=warehouseSummary::whereBetween('date',[$request->start_date,$request->end_date])->where('warehouse_id',Auth::user()->warehouse_id)->get();
            $warehouse = Warehouse::where('is_active',1)->get();
        }else{
            $end_date=date('Y-m-t');
            $start_date=date('Y-m-01');
            $warehouse_detail=warehouseSummary::where('warehouse_id',Auth::user()->warehouse_id)->get();
            $warehouse = Warehouse::where('is_active',1)->get();
        }
;
    }else{

if($request->start_date!=null && $request->end_date!=null && $request->warehouse_id!=null ){
    $warehouse_detail=warehouseSummary::whereBetween('date',[$request->start_date,$request->end_date])->where('warehouse_id',$request->warehouse_id)->get();
    $warehouse = Warehouse::where('is_active',1)->get();
}else{
    $end_date=date('Y-m-t');
    $start_date=date('Y-m-01');
    $warehouse_detail=warehouseSummary::get();
    $warehouse = Warehouse::where('is_active',1)->get();
}
}

       
   
   
   // dd($warehouse);
 
    return view('report.reports.print_summary_warehouse',compact('warehouse_detail','start_date','end_date','warehouse'));

}










public function print_summary_wh_sum_pdf(Request $request,$id){
    $warehouse_detail=warehouseSummary::where('id',$id)->first();
 
    $invoiceIdArray1 = explode (",", $warehouse_detail->prod_sale_id);
    // $invoiceIdArray1 = $request['invoiceIdArray'];
   
 
    // $prod_sale_data = [];
    $orderid=[];
    $prod_sale_id=[];
  //  dd($invoiceIdArray1 );
   try{

       $customer_name=  Customer::where('warehouse_id',$warehouse_detail->warehouse_id)->first();
   

          foreach ($invoiceIdArray1 as $id) {
           
        $prod_sale_id[]=$id;
          $prod_sale_data[] = Product_Sale::where('id',$id)->with('customer')
          ->with(['orderdetail'=>function($query){
               // $query->orderBy('prod_code','ASC')->orderBy('id',"ASC");
           }])->get();
          
          
               
      

          
           
            
                $town_name=Town::where('id',$customer_name->city)->first();
              
                 $regular= "S-F";
                
                $data=[
                       'order'=>$prod_sale_data,
                        'regular'=>$regular,
                        'town_name'=>$town_name,
                       
                        'drname'=>$warehouse_detail->drname,
                        'drno'=>$warehouse_detail->drno,
                           
                        'customer_detail'=>$customer_name,
                        'date'=>$warehouse_detail->date,
                        'serial_num'=>$warehouse_detail->sum_inv_no,
                     
                   ];
   
                   
                 }

             
                 
          
               //  $order[]= order_detail::with('customer')->with('productsale')->with('product')->where('prod_sale_id',$id)
                 
               //   ->with(['product'=>function($query){
               //     $query->with('category');
               //   }])
                 
               //   ->get();
               
 
             
                
                   $pdf = PDF::loadView('report.reports.printing_invoices_summary_wh',$data);
           $pdf->setPaper('A4', 'LandScape');
    
           return $pdf->stream("Invoce.pdf");
       } catch(Exception $e)
       {
       
           $s = $e->getMessage();
           
           $d=$s;
       }


}




public function product_id_invoice(Request $request){

   $product_id=$request->product_id;
 $product_data=order_detail::where('prod_id',$request->product_id)->whereBetween('created_at',[$request->start_date,$request->end_date])->get()->pluck('prod_sale_id')->toArray();
 $product_sale=Product_Sale::whereIn('id',$product_data)->with(['customer'])->with(['orderdetail'=>function ($query) use($product_id) {

    return $query->where('prod_id',$product_id)->get();

 } ])->get()->toArray();
//  dd( $product_sale);
//  $customer=Customer::whereIn('id',$product_sale->pluck('dist_id')->toArray())->with('town')->get()->toArray();


return
$product_sale;

}

//end section 


public function  ledgerReport_sole(Request $request){
    $start_date=  $request->start_date ;
    $end_date=   $request->end_date ;
    $cust_id=    $request->warehouse_id;


   
    $ledger=[];


    $ledger_pre=[];
  
     


     if($cust_id==1){

        $user_id=102;
      }elseif($cust_id==9){

$user_id=66;
      }elseif($cust_id==10){
        $user_id=101;  
      }else
      {
        $user_id=0;

      }
    //  $subDistribuor= Product_Sale::where('warehouse', 1)->where('status',1)->get()->pluck('dist_id')->toArray();
  
    $subDistribuor=DB::table('product_sales')->where('warehouse', $cust_id)->where('status',1)->get()->pluck('dist_id')->toArray();



    //   $sub_claim = Ledger::whereIn('distid',$subDistribuor)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',3)->sum('amount');
 


      $invoice = Ledger::whereIn('distid',$subDistribuor)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',1)->sum('amount');
      $invoicel = Ledger::where('distid',$user_id)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',1)->sum('amount');
 
 
    //  $online = Ledger::whereIn('distid',$subDistribuor)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',2)->sum('amount');
      $claim = Ledger::whereIn('distid',$subDistribuor)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',3)->sum('amount');
      
      
   
      $ledger_pre=  ($claim)-$invoice;
      $ledger= Ledger::orderBy('recdate','ASC')
      ->whereIn('distid',$subDistribuor)->whereNotIn('type',[2,3])
      ->whereRaw("recdate BETWEEN STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d') AND STR_TO_DATE('" . date('Y-m-d' , strtotime($end_date)) . "', '%Y-%m-%d')")
      ->get();
     
    



    $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));
    $companyhead  = Company_Head::get();
    $townName='';
    $distributerName='';
     $warehouse = Warehouse::whereNotIn('id',[8])->where('is_active',1)->get();
     $customer = Customer::where('is_active',1)->where('id',$cust_id)->first();

    return view('report.ledger_sole',[
      'warehouse'=>$warehouse,
      
      'companyhead'=>$companyhead,
      'cust_id'=>$request->user_id,
 
      'ledger'=>$ledger,
      
      'customer'=>$distributerName,
      
      'town'=>$townName,
      'ledger_pre'=>$ledger_pre,
      'prevdate'=>$prevdate,
      'start_date'=>$start_date,
     'end_date'=>$end_date,


  ]);


  }
}

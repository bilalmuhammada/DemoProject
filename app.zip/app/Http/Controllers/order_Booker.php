<?php

namespace App\Http\Controllers;

use App\cr;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\orderBooker;
use Auth;
use App\Roles;
use App\Town;

use App\Customer;
use App\sector;
use App\Warehouse;
use Illuminate\Http\Request;

class order_Booker extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('local_system')){
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if(empty($all_permission))
                $all_permission[] = 'dummy text';
            $lims_ordbooker_all = orderBooker::where('dist_id', session('logged_session_data.customer_id'))->get();
          
            $town = Town::get();
        
            return view('local_distributor.orderbooker.index', compact('lims_ordbooker_all','town', 'all_permission'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('local_system') ||$role->hasPermissionTo('users-add') ){
            // $lims_customer_group_all = CustomerGroup::where('is_active',true)->get();
            $sector = sector::where('dist_id', session('logged_session_data.customer_id'))->where('is_active', true)->get();
            $lims_role_list = Roles::where('is_active', true)->get();
            $customer = Customer::where('is_active', true)->get();
            $warehouse = Warehouse::where('is_active', true)->get();
            return view('local_distributor.orderbooker.create', compact('warehouse','customer','sector','lims_role_list'));
        }
        else


            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    
    public function store(Request $request)
    {
        //
        $data = $request->all();

         //dd(implode(",",$data['town']));
        

            $data['dist_id']= session('logged_session_data.customer_id');

          $data['sectors'] = implode(",",$data['sectors']);
        $orderbooker=   orderBooker::create($data);

        $message='Create Successfully';
        return redirect('orderbooker')->with('create_message', $message);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\cr  $cr
     * @return \Illuminate\Http\Response
     */
    public function show(cr $cr)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\cr  $cr
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('local_system')){
            $lims_orderbooker_data = orderBooker::find($id);
            $customer = Customer::where('is_active', true)->get();
            $lims_role_list = Roles::where('is_active', true)->get();
           
            $sectors = sector::where('dist_id', session('logged_session_data.customer_id'))->where('is_active', true)->get();
         
            return view('local_distributor.orderbooker.edit', compact('lims_orderbooker_data','customer', 'lims_role_list','sectors'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\cr  $cr
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $data = $request->all();

  
        $data['dist_id'] = session('logged_session_data.customer_id');
         $data['sectors'] = implode(",",$data['sectors']);
         $orderBooker = orderBooker::find($id);
    
        $orderBooker->update($data);

       $message='Update Successfully';
       return redirect('orderbooker')->with('create_message', $message);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\cr  $cr
     * @return \Illuminate\Http\Response
     */
    public function destroy(cr $cr)
    {
        //
    }
    public function activestatus(Request $request, $type, $id)
    {

        // dd($type);
        $result = orderBooker::find($id);
        $result->is_active = $type;
        
        $result->save();

        // $request->session()->flash('message', 'Customer status updated');

        return redirect('orderbooker')->with('create_message', 'orderBooker status updated');
    }

    public function importMDO(Request $request){


        $filename =  $request->file->getClientOriginalName();
        $upload=$request->file('file');
        $filePath=$upload->getRealPath();
        //open and read
        $file=fopen($filePath, 'r');
        $header= fgetcsv($file);
        $escapedHeader=[];
        //validate
        foreach ($header as $key => $value) {
            $lheader=strtolower($value);
            $escapedItem=preg_replace('/[^a-z]/', '', $lheader);
            array_push($escapedHeader, $escapedItem);
        }
        //looping through othe columns
        $lims_mdo_data = [];
        while($columns=fgetcsv($file))
        {
            if($columns[0]=="")
                continue;
            foreach ($columns as $key => $value) {
                $value=preg_replace('/\D/','',$value);
            }
            $data= array_combine($escapedHeader, $columns);

            // dd($data);
            $orderBooker = orderBooker::firstOrNew(['emp_code' => $data['empcode'],'is_active' => true ]);
            $orderBooker->name = $data['name'];
            $orderBooker->emp_code = $data['empcode'];
            $orderBooker->phone_number = $data['mobilenumber'];
            $orderBooker->designation = 'MDO';
            $orderBooker->dist_id =session('logged_session_data.customer_id') ;
            
        
            $orderBooker->sectors = $data['sector'];
            $orderBooker->is_active =true;
            $orderBooker->save();
        }
        return redirect('orderbooker')->with('message', 'MDO imported successfully');
    }

}

<?php

namespace App\Http\Controllers;

use App\add_cliam;
use Illuminate\Http\Request;
use App\Zone;
use App\CustomerGroup;
use App\Customer;
use App\Town;
use Illuminate\Validation\Rule;
use App\Company_Head;
use App\Ledger;
use App\Account_head;
use App\Online_cash;
use App\CliamHead;
use DB;
use App\StockCount;
use App\Warehouse;
use Auth;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
class AddCliamController extends Controller
{
    public function index(Request $request)
    {
        $start_date=$request->start_date;
        $end_date=$request->end_date;

        //dd($end_date);
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('unit')) {
            //$addcliam = add_cliam::with('Customer')->get();
           // dd(  $onlinecash );
            $distributer_all = Customer::where('is_active',1)->get();
            $town_all = Town::get();
            $custgrp_all = CustomerGroup::get();
            $Account_head = Account_head::get();
            $CliamHead = CliamHead::get();
            $companyhead = Company_Head::get();
            $warehouse_all = Warehouse::where('is_active',1)->get();
            if($start_date!=null && $end_date!=null )
            {

                $addcliam = add_cliam::with('Customer')->whereBetween('recdate',[$start_date,$end_date])->get();
            }else{
                $start_date=date('Y-m-01');
                $end_date=date('Y-m-t');

                $addcliam = add_cliam::with('Customer')->whereBetween('recdate',[ date('Y-m-01'),date('Y-m-t')])->get();
            }




            return view('add_claim.create', 
            [
            'distributer_all'=>$distributer_all,
            'warehouse_all'=> $warehouse_all,
            'addcliam'=> $addcliam,
            'CliamHead'=>$CliamHead,
            'town_all'=> $town_all,
            'start_date'=>$start_date,
            'end_date'=> $end_date,
            'companyhead'=>$companyhead,
            'Account_head'=>$Account_head,
            'custgrp_all'=> $custgrp_all,
            
         ]);
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }
 
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
 
    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreZoneRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $input = $request->all();
//dd( $input);
$this->validate($request, [
    'voucherid' => [
        'max:255',
            Rule::unique('add_cliams')->where(function ($query) {
            return $query;
        }),
    ],
]);






$cust5=Customer::where('id', $input['distr_id'])->first();
        $model = new add_cliam();
        $model1 = new Ledger();
        $model->claim =$input['claim'];
        $model->claimtype =$input['claimtype'];
        $model->voucherid =$input['voucher'];
        $model->recdate =$input['recdate'];
        
        $model->distid =$input['distr_id'];
        $model->discribtion =$input['discribtion'];
        $model->address =$input['dis_address'];
        //$model->acchead =$input['acchead_id'];
      
        $model->amount =$input['amount'];

        $model1->baltype =$input['claim'];
        $model1->moneymean =$input['claimtype'];
        $model1->voucherid =$input['voucher'];
        $model1->recdate =$input['recdate'];
        $model1->type =3;
        $model1->distid =$input['distr_id'];
        $model1->discribtion =$input['claimtype'].'-'.$cust5->distribution_name; ;
        $model1->dis_address =$input['dis_address'];
        //$model1->acchead =$input['acchead_id'];
        
        $model1->amount =$input['amount'];
        $model1->save();
        $model->save();


        if($input['warehouse_id']!=null){
           
            $cust=Customer::where('warehouse_id', $input['warehouse_id'])->first();
            $supervised_town=Town::where('id', $cust5->city)->first();
            $model12 = new Ledger();
            $model12->baltype =$input['claim'];
            $model12->moneymean =$input['claimtype'];
            $model12->voucherid =$input['voucher'];
            $model12->recdate =$input['recdate'];
            $model12->type =3;
            $model12->distid =$cust->id;
            $model12->discribtion =$input['claimtype'].'-'.$cust5->distribution_name;
            $model12->dis_address =$input['dis_address'];
            //$model1->acchead =$input['acchead_id'];
            $model12->amount =$input['amount'];
            $model12->save();
        
        }
        return redirect('add_claim')->with('message', 'Data inserted successfully');
    }
 
 
    public function deleteBySelection(Request $request)
    {
        $distributer_id = $request['zoneIdArray'];
        foreach ($zone_id as $id) {
            $Distributor_data = Online_cash::find($id);
            $Distributor_data->is_active = false;
            $Distributor_data->save();
        }
        return 'Distributor deleted successfully!';
    }
 
    /**
     * Display the specified resource.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
   
 
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        
        // if ($id > 0) {

        //     $arr = Online_cash::where(['id' => $id])->get();
        //     $result['recdate'] =  $arr['0']->recdate;
        //     $result['distid'] =  $arr['0']->distid;
        //     $result['discribtion'] =  $arr['0']->discribtion;
        //     $result['acchead'] =  $arr['0']->acchead;
        //     $result['amount'] =  $arr['0']->amount;
        //     $result['baltype'] =  $arr['0']->balancetype;
        //     $result['online'] =  $arr['0']->moneymean;
        //     $result['voucher'] =  $arr['0']->voucherid;
        //     $result['id'] =  $arr['0']->id;

        //     // $result['ishomecheck'] =  '';
        //     // if ($arr['0']->ishome == 1) {
        //     //     $result['ishomecheck'] =  'checked';
        //     // }
        //     // $result['id'] =  $arr['0']->id;
        //     // $result['data'] = Category::where(['stutus' => 1])->where('id', '!=', $id)->get();
        //     //dd($result);
        // } else {
        //     $result['recdate'] =  "";
        //     $result['distid'] =  ""; 
        //     $result['discribtion'] =  "";
        //     $result['acchead'] = "";
        //     $result['amount'] =  "";
        //     $result['baltype'] =  "";
        //     $result['online'] =  "";
        //     $result['voucher'] =  "";
            
        //     $result['id'] = 0;
        // }
     
        $result['add_cliam'] = add_cliam::findOrFail($id);
       $result['onlinecash'] = add_cliam::get();
       $result['distributer_all']  = Customer::where('is_active',1)->get();
       $result['town_all']  = Town::get();
       $result['warehouse_all']  = Warehouse::where('is_active',1)->get();
       $result['custgrp_all']  = CustomerGroup::get();
       $result['Account_head']  = Account_head::get();
       $result['companyhead']  = Company_Head::get();
       $result['CliamHead'] = CliamHead::get();
       $result['id'] =$id;
        return view('add_claim.edit',  
            $result    
         );
        
    }
   
    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateZoneRequest  $request
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

 
        $input = $request->all();

$model=[];
$model1=[];

// 


        // $model = new Online_cash();
        // $model1 = new Ledger();
       
        // $model['baltype'] =$input['balancetype'];
        // $model['moneymean'] =$input['online'];
        $cust6=Customer::where('id', $input['distr_id'])->first();
        $model['claim'] =$input['claim'];
        $model['claimtype'] =$input['claimtype'];
        $model['voucherid']=$input['voucher'];
        $model['recdate'] = date('Y-m-d',strtotime($input['recdate']));
        
        $model['distid']=$input['distr_id'];
        $model['discribtion'] =$input['discribtion'];
      ///  $model['acchead']=$input['acchead_id'];
        $model['address'] =$input['dis_address'];
        $model['amount'] =$input['amount'];

        $model1['baltype'] =$input['claim'];
        $model1['moneymean'] =$input['claimtype'];
        $model1['voucherid'] =$input['voucher'];
        $model1['recdate'] =  date('Y-m-d',strtotime($input['recdate']));
        
        $model1['distid']=$input['distr_id'];
        $model1['discribtion'] =$input['claimtype'].'-'.$cust6->distribution_name;
        $model1['acchead']=$input['claim'];
        
        $model1['amount'] =$input['amount'];

        
        add_cliam::where('id', $input['id'])->update($model);
        Ledger::where('voucherid',$input['voucher'])->where('distid', $input['distr_id'])->update($model1);


        
        

if($input['warehouse_id']!=null){
    $model12=[];
    $cust=Customer::where('warehouse_id', $input['warehouse_id'])->first();
    $Ledger=Ledger::where('voucherid', $input['voucher'])->where('distid',$cust->id)->first();

    $supervised_town=    Town::where('id', $cust6->city)->first();
    $model12['baltype'] =$input['claim'];
    $model12['moneymean'] =$input['claimtype'];
    $model12['voucherid'] =$input['voucher'];
    $model12['recdate'] =$input['recdate'];
    $model12['type']=3;
    $model12['distid'] =$cust->id;
    $model12['discribtion'] =$input['claimtype'].'-'.$cust6->distribution_name;
    $model12['dis_address'] =$input['dis_address'];
    // $model12['acchead'] =$input['acchead_id'];
    $model12['amount'] =$input['amount'];
   // dd( isset($Ledger));
    if(isset($Ledger)){
        Ledger::where('voucherid',$input['voucher'])->where('distid',$cust->id)->update($model12);
    }
    else{
        Ledger::insert($model12);
    }
   


 }
        
        return redirect('add_claim')->with('message', 'update inserted successfully');
        //dd($input);
        // $this->validate($request, [
        //     'DistributorName' => [
        //         'max:255',
        //         Rule::unique('zones')->ignore($request->zone_id)->where(function ($query) {
        //             return $query->where('is_active', 1);
        //         }),
        //     ],
           
        // ]);
        
    }
 
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $distributor_data = add_cliam::find($id);
       // $distributor_data->is_active = false;
        $distributor_data->delete();
        Ledger::where('voucherid',$distributor_data->voucherid)->delete();
        return redirect('add_claim')->with('not_permitted', 'Data deleted successfully');
    }

    public function show_address($id)
    {

        
        // $distributor_data = Customer::where($id);
        $distributer_all = Customer::where('is_active',1)->where('id',$id)->get();
       // $distributor_data->is_active = false;
       return  $distributer_all;
        
    }


    public function get_voucher()
    {
        $month = date('m');
        $year = date('y');
        $add_cliam = add_cliam::latest()->first();

       //dd($add_cliam);
        if($add_cliam!=null)
        {
            $counter_val = sprintf('%05d', $add_cliam->id);

            $add_cliam=   $month . '-' . $year . '-'.$counter_val;

           
        }
        else{
            $add_cliam=1;
        }
       

       
       return  $add_cliam;
        
    }

    function  get_distributor($id)
{
      $distributor_detail=  Customer::where('id',$id)->first();
        //dd($distributor_detail);
    return $distributor_detail->distribution_name;
}
function  show_address_edit(Request $request)
{
    //dd($request->id);
      $distributor_detail=  Customer::where('id',$request->id)->first();
        //dd($distributor_detail);
    return $distributor_detail;
}

}

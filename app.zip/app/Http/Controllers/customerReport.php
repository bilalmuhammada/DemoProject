<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class customerReport extends Controller
{
    //
}

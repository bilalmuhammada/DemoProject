<?php

namespace App\Http\Controllers;

use App\Price_structure;
use Illuminate\Http\Request;
use Keygen;
use App\Brand;
use App\Category;
use App\Unit;
use App\Customer;
use App\CustomerGroup;
use App\Tax;
use App\Warehouse;
use App\Supplier;
use App\Product;
use App\ProductBatch;
use App\Product_Warehouse;
use App\Product_Supplier;
use Auth;
use DNS1D;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Validation\Rule;
use DB;
use App\Variant;
use App\ProductVariant;
use App\Classes\GoalSeek;
use App\Classes\GSeek;
class PriceStructureController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('products-index')){            
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if(empty($all_permission))
                $all_permission[] = 'dummy text';
            
                $price_structure = Price_structure::with('CustomerGroup')->whereIn('group_id',[2,7,11])->with('Product')->where('is_active',true)->get();
            // dd($price_structure[0]);
            return view('product.price_structure_index', compact('all_permission','price_structure'));
        }
        else
         
        return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

   
    public function sub_distributor()
    {     
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('products-index')){            
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if(empty($all_permission))
                $all_permission[] = 'dummy text';
            
                $price_structure = Price_structure::with('CustomerGroup')->where('group_id',11)->with('Product')->where('is_active',true)->get();
            // dd($price_structure[0]);
            return view('product.price_structure_sub_dis_index', compact('all_permission','price_structure'));
        }
        else
         
        return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }
    

    public function sub_distributor_pricelist($id)
    {     
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('local_system')){            
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if(empty($all_permission))
                $all_permission[] = 'dummy text';
            
                $price_structure = Price_structure::with('CustomerGroup')->where('group_id',11)->with('Product')->where('is_active',true)->get();
            // dd($price_structure[0]);
            return view('local_distributor.create_order.price_structure_sub_dis_index', compact('all_permission','price_structure'));
        }
        else
         
        return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }
    public function usc_csd_priceStucture()
    {
         
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('products-index')){            
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if(empty($all_permission))
                $all_permission[] = 'dummy text';
            
                $price_structure = Price_structure::with('CustomerGroup')->whereIn('group_id',[1,6,8,9,10])->with('Product')->where('is_active',true)->get();
            // dd($price_structure[0]);
            return view('product.price_structure_usc_csd_index', compact('all_permission','price_structure'));
        }
        else
         
        return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    


    public function   marketing_priceStucture(){
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('products-index')){            
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if(empty($all_permission))
                $all_permission[] = 'dummy text';
            
                $price_structure = Price_structure::with('CustomerGroup')->with('Product')->where('is_active',true)->get();
            // dd($price_structure[0]);
            return view('product.price_structure_marketing_index', compact('all_permission','price_structure'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');

    }


    public function   distributor_priceStucture(){
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('products-index')){            
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if(empty($all_permission))
                $all_permission[] = 'dummy text';
            
                $price_structure = Price_structure::with('CustomerGroup')->with('Product')->where('is_active',true)->get();
            // dd($price_structure[0]);
            return view('product.price_structure_distributor_index', compact('all_permission','price_structure'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');

    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function productWithoutVariant()
    {
        return Product::ActiveStandard()->select('id', 'name', 'code')
                ->whereNull('is_variant')->get();
    }

    public function productWithVariant()
    {
        return Product::join('product_variants', 'products.id', 'product_variants.product_id')
                ->ActiveStandard()
                ->whereNotNull('is_variant')
                ->select('products.id', 'products.name', 'product_variants.item_code')
                ->orderBy('position')->get();
    }
    public function create()
    {
        $role = Role::firstOrCreate(['id' => Auth::user()->role_id]);
        if ($role->hasPermissionTo('products-add')){
            $lims_product_list_without_variant = $this->productWithoutVariant();
            $lims_product_list_with_variant = $this->productWithVariant();
            $lims_brand_list = Brand::where('is_active', true)->get();
            $lims_Product_list = Product::where('is_active', true)->get();

            //dd($lims_Product_list);
            $lims_customer_list = Customer::where('is_active', true)->get();
            $lims_custgroup_list = CustomerGroup::where('is_active', true)->get();
            $lims_category_list = Category::where('is_active', true)->get();
            $lims_unit_list = Unit::where('is_active', true)->get();
            $lims_tax_list = Tax::where('is_active', true)->get();
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            return view('product.price_struc_create',compact('lims_product_list_without_variant','lims_Product_list', 'lims_customer_list','lims_custgroup_list','lims_product_list_with_variant', 'lims_brand_list', 'lims_category_list', 'lims_unit_list', 'lims_tax_list', 'lims_warehouse_list'));
        }else if($role->hasPermissionTo('local_system')){
         
                $lims_product_list_without_variant = $this->productWithoutVariant();
                $lims_product_list_with_variant = $this->productWithVariant();
                $lims_brand_list = Brand::where('is_active', true)->get();
                $lims_Product_list = Product::where('is_active', true)->get();
    
                //dd($lims_Product_list);
                $lims_customer_list = Customer::where('is_active', true)->get();
                $lims_custgroup_list = CustomerGroup::where('is_active', true)->where('id',11)->get();
                $lims_category_list = Category::where('is_active', true)->get();
                $lims_unit_list = Unit::where('is_active', true)->get();
                $lims_tax_list = Tax::where('is_active', true)->get();
                $lims_warehouse_list = Warehouse::where('is_active', true)->get();
                return view('product.price_struc_create',compact('lims_product_list_without_variant','lims_Product_list', 'lims_customer_list','lims_custgroup_list','lims_product_list_with_variant', 'lims_brand_list', 'lims_category_list', 'lims_unit_list', 'lims_tax_list', 'lims_warehouse_list'));
            
        }
        else{
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
        }
   
   
           
            
            
   
   
        }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function getdistmgr(Request $request)
    {
      
    $price_structure= Price_structure::where('group_id',2)->where('product_id',$request->product_id)->where('is_active',true)->first();


    return $price_structure;
    }
    
    public function store(Request $request)
    {
        //

           $data=$request->all();

          // dd($data);
        $this->validate($request, [
            'code' => [
                'max:255',
                    Rule::unique('products')->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
            'name' => [
                'max:255',
                    Rule::unique('products')->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ]
        ]);

   
       
        $lims_product_data = new Price_structure();
        $lims_product_data->group_id =$data['custgroup_id'];
        $lims_product_data->price_code =$data['product_code'];
        $lims_product_data->product_id =$data['product_id'];
        $lims_product_data->distributor_margin =$data['DistributorMargin'];
        $lims_product_data->retailer_margin =$data['RetailerMargin'];
         $lims_product_data->factory_price =$data['FactoryPrice'];
         
         
        $lims_product_data->txt_sales_tax =$data['txt_sales_tax'];
        $lims_product_data->retail_price =$data['price'];
        $lims_product_data->txt_dist_price =$data['txt_dist_price'];
        $lims_product_data->txt_dist_margin =$data['txt_dist_margin'];
        $lims_product_data->txt_trade_price =$data['txt_trade_price'];
       
        if($data['custgroup_id']==11){
            $lims_product_data->txt_retailer_margin =$data['txt_retailer_margin'];
       if( session('logged_session_data.customer_id')!=null){
        $lims_product_data->dist_id=  session('logged_session_data.customer_id');
        $lims_product_data->group_id =$data['custgroup_id'];
       }else{
            $lims_product_data->dist_id= $data['distributor_id'];
            $lims_product_data->group_id =$data['custgroup_id']; 
         }
        }
        else{
            $lims_product_data->dist_id=null;
            $lims_product_data->group_id =$data['custgroup_id'];
        }
        if($data['TO_Value']!=null && $data['TO_Buy']!=null &&  $data['TO_GetFree']!=null && $data['inv_price']!=null ){
            $lims_product_data->offer_value =$data['TO_Value'];
            $lims_product_data->buy =$data['TO_Buy'];
            $lims_product_data->get_free =$data['TO_GetFree'];
             $lims_product_data->inv_price =$data['inv_price'];
        }else{
            $lims_product_data->offer_value =$data['usc_margin'];
            $lims_product_data->buy =$data['usc_saleprice'];
            $lims_product_data->usc_code =$data['usc_code'];
             $lims_product_data->inv_price =$data['inv_price_usc'];
        }
        
        $lims_product_data->is_active = true;
         
if(isset($data['ConsumerPrice']))
{
    $lims_product_data->is_regular =$data['ConsumerPrice'];
}else
{
    $lims_product_data->is_regular=0;
}

         
         
         $lims_product_data->save();
       
         if($data['custgroup_id']==7 ||$data['custgroup_id']==2 ){
            return redirect('price_struct')->with('create_message', 'Price Structure created successfully');
         }else
         {
            return redirect('price_struct/usc_csd')->with('create_message', 'Price Structure created successfully');
         }
        // \Session::flash('create_message', 'Price Structure created successfully');
       
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Price_structure  $price_structure
     * @return \Illuminate\Http\Response
     */
    public function show(Price_structure $price_structure)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Price_structure  $price_structure
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $role = Role::firstOrCreate(['id' => Auth::user()->role_id]);
        if ($role->hasPermissionTo('products-edit')) {
           
            $lims_product_list_without_variant = $this->productWithoutVariant();
            $lims_product_list_with_variant = $this->productWithVariant();
            $lims_brand_list = Brand::where('is_active', true)->get();
            $lims_Product_list = Product::where('is_active', true)->get();

            //dd($lims_Product_list);
            $lims_customer_list = Customer::where('is_active', true)->get();
            $lims_custgroup_list = CustomerGroup::where('is_active', true)->get();
            $lims_category_list = Category::where('is_active', true)->get();
            $lims_unit_list = Unit::where('is_active', true)->get();
            $lims_tax_list = Tax::where('is_active', true)->get();
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            $price_structure = Price_structure::where('id', $id)->with('CustomerGroup')->with('Product')->first();
           
           //dd( $price_structure);
            return view('product.price_struc_edit',compact('price_structure','lims_product_list_without_variant','lims_Product_list', 'lims_customer_list','lims_custgroup_list','lims_product_list_with_variant', 'lims_brand_list', 'lims_category_list', 'lims_unit_list', 'lims_tax_list', 'lims_warehouse_list'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Price_structure  $price_structure
     * @return \Illuminate\Http\Response
     */
    public function updatePrice(Request $request)
    {
        
        $data=$request->all();

      
   
        $lims_product_data = new Price_structure();
        $lims_product_data->exists = true;
        $lims_product_data->id =$data['id'];
        $lims_product_data->group_id =$data['custgroup_id'];
        $lims_product_data->product_id =$data['product_id'];
        $lims_product_data->price_code =$data['product_code'];
        $lims_product_data->distributor_margin =$data['DistributorMargin'];
        $lims_product_data->retailer_margin =$data['RetailerMargin'];
         $lims_product_data->factory_price =$data['FactoryPrice'];

      

        $lims_product_data->txt_sales_tax =$data['txt_sales_tax'];
        $lims_product_data->retail_price =$data['price'];
        $lims_product_data->txt_dist_price =$data['txt_dist_price'];
        $lims_product_data->txt_dist_margin =$data['txt_dist_margin'];
        $lims_product_data->txt_trade_price =$data['txt_trade_price'];
        $lims_product_data->txt_retailer_margin =$data['txt_retailer_margin'];
       

        $lims_product_data->retail_price_exc_tax =$data['retail_price_exc_tax'];
        $lims_product_data->txt_trade_price_exc_tax =$data['txt_trade_price_exc_tax'];
        $lims_product_data->txt_dist_excl =$data['txt_dist_excl'];
        $lims_product_data->inv_price_excl =$data['inv_price_excl'];


        $lims_product_data->is_active = true;
        

         if($data['custgroup_id']==7 ||  $data['custgroup_id']==2 ||  $data['custgroup_id']==11  ){
            $lims_product_data->offer_value =$data['TO_Value'];
            $lims_product_data->buy =$data['TO_Buy'];
            $lims_product_data->get_free =$data['TO_GetFree'];
             $lims_product_data->inv_price =$data['inv_price'];
        }else{
            $lims_product_data->offer_value =$data['usc_margin'];
            $lims_product_data->buy =$data['usc_saleprice'];
            $lims_product_data->usc_code =$data['usc_code'];
             $lims_product_data->inv_price =$data['inv_price_usc'];
        }
        



         if(isset($data['ConsumerPrice']))
{
    $lims_product_data->is_regular =$data['ConsumerPrice'];
}else
{
    $lims_product_data->is_regular=0;
}
         $lims_product_data->save();
        
         if($data['custgroup_id']==7 ||$data['custgroup_id']==2 ){
            return redirect('price_struct')->with('create_message', 'Price Structure updated successfully');
         }
         
         else if($data['custgroup_id']==11){
            return redirect('price_struct/sub_distr/')->with('create_message', 'Price Structure updated successfully');
         }
         else
         {
            return redirect('price_struct/usc_csd')->with('create_message', 'Price Structure updated successfully');
         }
         
        // \Session::flash('edit_message', 'Price strct updated successfully');
      
    }



    public function importPriceStruct(Request $request)
    {
        //get file
        $upload=$request->file('file');
        $ext = pathinfo($upload->getClientOriginalName(), PATHINFO_EXTENSION);
        if($ext != 'csv')
            return redirect()->back()->with('not_permitted', 'Please upload a CSV file');
        $filename =  $upload->getClientOriginalName();
        $upload=$request->file('file');
        $filePath=$upload->getRealPath();
        //open and read
        $file=fopen($filePath, 'r');
        $header= fgetcsv($file);
        $escapedHeader=[];
        //validate
        foreach ($header as $key => $value) {
            $lheader=strtolower($value);
            $escapedItem=preg_replace('/[^a-z]/', '', $lheader);
            array_push($escapedHeader, $escapedItem);
        }
        //looping through othe columns
        while($columns=fgetcsv($file))
        {
            if($columns[0]=="")
                continue;
            foreach ($columns as $key => $value) {
                $value=preg_replace('/\D/','',$value);
            }
           $data= array_combine($escapedHeader, $columns);

         $lims_category_list = Category::where('is_active', true)->where('name',$data['categoryname'] )->first();
      

          $lims_Product_list = Product::where(['is_active'=> true,'code'=>$data['productcode']])->first();

       //  dd($lims_Product_list->id );
       $lims_custgroup_list = CustomerGroup::where('is_active', true)->where('name',$data['groupname'])->first();
 
         
           $lims_product_data= Price_structure::firstOrNew(['is_active'=>true,'group_id'=>$lims_custgroup_list->id] );
          
        
           $lims_product_data->group_id =$lims_custgroup_list->id;
           $lims_product_data->product_id =$lims_Product_list->id;
           $lims_product_data->price_code =$lims_Product_list->code;
           $lims_product_data->distributor_margin =$data['distributormargin'];
           $lims_product_data->retailer_margin =$data['retailermargin'];
            $lims_product_data->factory_price =$data['factoryprice'];
   
            $lims_product_data->offer_value =$data['togetfree'];
           $lims_product_data->buy =$data['tobuy'];
           $lims_product_data->is_active = true;;
            $lims_product_data->get_free =$data['tovalue'];
          
           $lims_product_data->save();
        }
        
        return redirect('price_struct')->with('message', 'Price Structure imported successfully');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Price_structure  $price_structure
     * @return \Illuminate\Http\Response
     */
    public function destroy(Price_structure $price_structure,$id)
    {
        $lims_product_data = Price_structure::findOrFail($id);
        
        $lims_product_data->is_active = false;
        
        $lims_product_data->save();
        return redirect('price_struct')->with('message', 'Prod deleted successfully');
        //
    }



    public function factory_price(Request $request)
    {

   

        $data = json_decode($request->getContent(), true);
       
        $isTaxOnRetail = (isset($data['gst_caculation'])) ? ($data['gst_caculation']) : false;
        $GST = (isset($data['gst'])) ? ($data['gst']) : 17;
        $DistributorMargin = (isset($data['dist_margin'])) ? ($data['dist_margin']) : 11;
        $RetailerMargin = (isset($data['retailor_margin'])) ? ($data['retailor_margin']) : 10.5;
        $price = (isset($data['price'])) ? ($data['price']) : 0;

      


        $result = new GSeek();
        $result->GST = $GST;
        $result->Distributor_Margin_Percentage=$DistributorMargin;
        $result->Retailer_Margin_Percentage=$RetailerMargin;
        $result->is_Sale_TAX_On_Retail_Price=$isTaxOnRetail;
        $result->goal_target=$price;

        $res = $result->calculate();
      

        

        $result_gst = ($isTaxOnRetail===true) ? ($price * ($GST / ($GST + 100))) : ($res * ($GST / 100));
        $result_dist_margin = ($res + $result_gst) * ($DistributorMargin / 100);
        $result_retailer_margin = ($res + $result_gst + $result_dist_margin) * ($RetailerMargin / 100);

        // setQueryLog();
       // $Retailer= ($result->goal_target*$RetailerMargin)/100+$RetailerMargin;

        return response()->json([
            "factory_price" => $res,
            "calc_gst" => $result_gst,
            "dist_margin" => $result_dist_margin,
            "retailer_margin" => $result_retailer_margin
        ]);

    }


    public function calc_trade_offer(Request $request)
    {

        $data = json_decode($request->getContent(), true);
        $isTaxOnRetail = (isset($data['gst_caculation'])) ? ($data['gst_caculation']) : false;
        $GST = (isset($data['gst'])) ? ($data['gst']) : 17;
        $DistributorMargin = (isset($data['dist_margin'])) ? ($data['dist_margin']) : 11;
        $RetailerMargin = (isset($data['retailor_margin'])) ? ($data['retailor_margin']) : 10.5;
        $price = (isset($data['price'])) ? ($data['price']) : 0;
        $buy = (isset($data['buy'])) ? ($data['buy']) : 0;
        $get_free = (isset($data['get_free'])) ? ($data['get_free']) : 0;

        $result = new GSeek();
        $result->GST = $GST;
        $result->Distributor_Margin_Percentage=$DistributorMargin;
        $result->Retailer_Margin_Percentage=$RetailerMargin;
        $result->is_Sale_TAX_On_Retail_Price=$isTaxOnRetail;
        $result->goal_target=$price;
        $result->buy=$buy;
        $result->get_free=$get_free;

        $res = $result->calc_trade_offer();

        return response()->json([
            "offer_value" => $res
        ]);

    }


   public function product_detail(Request $request){

    $lims_Product_list = Product::where('is_active', true)->where('id',$request->product_id)->first();
    $lims_Category_list = Category::where('is_active', true)->where('id',$lims_Product_list->category_id)->first();

   // dd($lims_Product_list);
    return response()->json([

        'price'=>$lims_Product_list->price,
        'GST'=>$lims_Product_list->GST_BaseValue,
        'product_code'=>$lims_Product_list->code,
        'UnitPerCTRN'=>$lims_Product_list->UnitPerCTRN,
        'categoryName'=>$lims_Category_list->name,
        'ProductWeight'=>$lims_Product_list->ProductWeight,
//'price'=>$lims_Product_list->price,
        "lims_Product_list" => $lims_Product_list
    ]);

   }

}

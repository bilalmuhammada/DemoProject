<?php

namespace App\Http\Controllers;

use App\CliamHead;
use App\Customer;
use App\Company_Head;
use App\Ledger;
use Auth;
use DB;
use App\CustomerGroup;
use App\order_detail;
use App\Town;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Product_Sale;
use Illuminate\Http\Request;

class CliamHeadController extends Controller
{
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('unit')) {
           
            $distributer_all = Customer::get();
            $town_all = Town::get();
            $custgrp_all = CustomerGroup::get();
            $cliam_head=CliamHead::get();
 
            return view('Cliam_Head.create', 
            ['distributer_all'=>$distributer_all,
            'town_all'=> $town_all,
            'cliam_head'=>$cliam_head,
            'custgrp_all'=> $custgrp_all,
            
         ]);
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }
 
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
 
    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreZoneRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // $this->validate($request, [
        //     'cliam' => [
        //         'max:255',
        //             Rule::unique('cliamheads')->where(function ($query) {
        //             return $query->where('is_active', 1);
        //         }),
        //     ],
           
        // ]);
        $input = $request->all();
    
        $model = new CliamHead();
        
        $model->cliam =$input['cliam'];
        
       // $model->HeadType =$input['online'];
       
       
        $model->save();
        return redirect('cliam_head')->with('message', 'Data inserted successfully');
    }
 
 
    public function deleteBySelection(Request $request)
    {
        $distributer_id = $request['zoneIdArray'];
        foreach ($zone_id as $id) {
            $Distributor_data = Account_head::find($id);
            $Distributor_data->is_active = false;
            $Distributor_data->save();
        }
        return 'Distributor deleted successfully!';
    }
 
    /**
     * Display the specified resource.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        //
    }
 
  
     
    public function edit($id)
    {
        $data = CliamHead::findOrFail($id);
        return $data;
    }
   
    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateZoneRequest  $request
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
 
        // $this->validate($request, [
        //     'DistributorName' => [
        //         'max:255',
        //         Rule::unique('zones')->ignore($request->zone_id)->where(function ($query) {
        //             return $query->where('is_active', 1);
        //         }),
        //     ],
           
        // ]);
       
        $input = $request->all();

       // dd( $input);
        $data1=[];

        $data1['claim_code'] =$input['cliam_code'];
        $data1['cliam'] =$input['cliam'];
        


        CliamHead::where('id', $request->id)->update($data1);
        
        return redirect('cliam_head')->with('message', 'Data updated successfully');
    }
 
    
    public function destroy($id)
    {
        $cliam_data = CliamHead::find($id);
        //$distributor_data->is_active = false;
        $cliam_data->delete();
        return redirect('cliam_head')->with('not_permitted', 'Data deleted successfully');
    }
}

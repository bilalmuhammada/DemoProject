<?php

namespace App\Http\Controllers;

use App\sector;
use App\cr;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\orderBooker;
use Auth;
use App\Roles;
use App\town;
use App\Customer;
use App\Warehouse;
use Illuminate\Http\Request;

class SectorController extends Controller
{
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('local_system')) {
 
            // setQueryLog();
            $sector_all = sector::where('dist_id', session('logged_session_data.customer_id'))->where('is_active', true)->with('towns')->get();
            // dd(getQueryLog());
            
 
            return view('local_distributor.sectors.create', compact('sector_all'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }
 
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
 
    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreTownRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => [
                'max:255',
                    Rule::unique('sectors')->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
            'code' => [
                'max:255',
                    Rule::unique('sectors')->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
        ]);
        $input = $request->all();
        $input['dist_id']= session('logged_session_data.customer_id');
       
        // $input['is_active'] = true;
        sector::create($input);
        return redirect('sectors')->with('message', 'Data inserted successfully');
    }
 
 
    public function deleteBySelection(Request $request)
    {
        $town_id = $request['townIdArray'];
        foreach ($town_id as $id) {
            $techxa_town_data = sector::find($id);
            $techxa_town_data->is_active = false;
            $techxa_town_data->save();
        }
        return 'Towns deleted successfully!';
    }
 
    /**
     * Display the specified resource.
     *
     * @param  \App\Town  $town
     * @return \Illuminate\Http\Response
     */
    public function show(Town $town)
    {
        //
    }
 
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Town  $town
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $techxa_sector_data = sector::findOrFail($id);

        //dd($techxa_sector_data);
        return $techxa_sector_data;
 
    }
   
    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateTownRequest  $request
     * @param  \App\Town  $town
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
 
        $this->validate($request, [
            'name' => [
                'max:255',
                Rule::unique('sectors')->ignore($request->town_id)->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
            'code' => [
                'max:255',
                Rule::unique('sectors')->ignore($request->town_id)->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
        ]);
        $input = $request->all();
        $techxa_town_data = sector::find($input['town_id']);
        // setQueryLog();
        $techxa_town_data->update($input);
        // dd(getQueryLog());
        return redirect('sector')->with('message', 'Data updated successfully');
    }
 
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Town  $town
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $techxa_town_data = sector::find($id);
        $techxa_town_data->is_active = false;
        $techxa_town_data->save();
        return redirect('town')->with('not_permitted', 'Data deleted successfully');
    }
 
 
    public function importsectors(Request $request)
    { 
        $upload=$request->file('file');
 
      
        $ext = pathinfo($upload->getClientOriginalName(), PATHINFO_EXTENSION);
        if($ext != 'csv')
            return redirect()->back()->with('not_permitted', 'Please upload a CSV file');
        $filename =  $upload->getClientOriginalName();
        $upload=$request->file('file');
        $filePath=$upload->getRealPath();
        //open and read
        $file=fopen($filePath, 'r');
        $header= fgetcsv($file);
        $escapedHeader=[];
        //validate
        foreach ($header as $key => $value) {
            $lheader=strtolower($value);
            $escapedItem=preg_replace('/[^a-z]/', '', $lheader);
            array_push($escapedHeader, $escapedItem);
        }
        //looping through othe columns
        while($columns=fgetcsv($file))
        {
            if($columns[0]=="")
                continue;
            foreach ($columns as $key => $value) {
                $value=preg_replace('/\D/','',$value);
            }
           $data= array_combine($escapedHeader, $columns);

           $lims_sector_data= sector::firstOrNew(['code'=>$data['code'],'is_active' => true]);
           
           $lims_sector_data->code =$data['code'];
           $lims_sector_data->name =$data['sector'];
           $lims_sector_data->dist_id =session('logged_session_data.customer_id') ;
           
           $lims_sector_data->town =48;
         
           $lims_sector_data->is_active=true;
           $lims_sector_data->save();
           
        }
        return redirect('sectors')->with('message', 'Price Structure imported successfully');
    }
}

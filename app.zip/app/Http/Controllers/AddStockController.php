<?php

namespace App\Http\Controllers;

use App\add_stock;
use App\Product;
use App\Category;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Auth;

use Illuminate\Http\Request;

class AddStockController extends Controller
{
    
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('unit')) {
            $stock = add_stock::get();
             $product = Product::where('is_active',true)->get();
             $category = Category::where('is_active',true)->get();
            // $custgrp_all = CustomerGroup::get();
            // $Account_head=Account_head::get();
 
            return view('Stock.create', 
            ['stock'=>$stock,
             'product'=> $product,
             'category'=> $category,
            // 'Account_head'=>$Account_head,
            // 'custgrp_all'=> $custgrp_all,
            
         ]);
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }
 
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
 
    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreZoneRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'ACHName' => [
                'max:255',
                    Rule::unique('account_heads')->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
           
        ]);
        $input = $request->all();
    
        $model = new Account_head();
        $model->ACHCode =$input['ac_code'];
        $model->ACHName =$input['ac_name'];
        $model->HeadType =$input['ac_num'];
       // $model->HeadType =$input['online'];
       
       
        $model->save();
        return redirect('add_stock')->with('message', 'Data inserted successfully');
    }
 
 
    public function deleteBySelection(Request $request)
    {
        $distributer_id = $request['zoneIdArray'];
        foreach ($zone_id as $id) {
            $Distributor_data = Account_head::find($id);
            $Distributor_data->is_active = false;
            $Distributor_data->save();
        }
        return 'Distributor deleted successfully!';
    }
 
    /**
     * Display the specified resource.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        //
    }
 
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Account_head::findOrFail($id);
        return $data;
    }
   
    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateZoneRequest  $request
     * @param  \App\Zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
 
        // $this->validate($request, [
        //     'DistributorName' => [
        //         'max:255',
        //         Rule::unique('zones')->ignore($request->zone_id)->where(function ($query) {
        //             return $query->where('is_active', 1);
        //         }),
        //     ],
           
        // ]);
       
        $input = $request->all();

       // dd( $input);
        $data1=[];

        $data1['ACHCode'] =$input['ac_code'];
        $data1['ACHName'] =$input['ac_name'];
        $data1['HeadType'] =$input['ac_num'];


        Account_head::where('id', $request->id)->update($data1);
        
        return redirect('add_stock')->with('message', 'Data updated successfully');
    }
 
    
    public function destroy($id)
    {
        $distributor_data = Account_head::find($id);
        //$distributor_data->is_active = false;
        $distributor_data->delete();
        return redirect('add_stock')->with('not_permitted', 'Data deleted successfully');
    }

    public function get_stock(Request $request)
    {
        dd($request['id']);
       // $distributor_data = Account_head::find($request->id);
        //$distributor_data->is_active = false;
        //$distributor_data->delete();
        return redirect('add_stock')->with('not_permitted', 'Data deleted successfully');
    }

    
}

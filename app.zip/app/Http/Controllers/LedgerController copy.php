<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Customer;
use App\Company_Head;
use App\Ledger;
use App\Product;
use Barryvdh\DomPDF\Facade as PDF;
use App\Town;
use App\order_detail;
use App\add_stock;
use App\StockReturn;
use App\Unit;
use App\Product_Sale;
use Auth;
class LedgerController extends Controller
{
    //
    
    public function index()
    {
        
        // $role = Role::find(Auth::user()->role_id);
        // if($role->hasPermissionTo('account-index')){
        //     $lims_account_all = Account::where('is_active', true)->get();
        $companyhead  = Company_Head::get();

        $distributer_all = Customer::where('is_active',1)->get();
            return view('report.user_report',[
                'distributer_all'=>$distributer_all,
                'companyhead'=>$companyhead
            ]);
        // }
        // else
        //     return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function ledgerReport(Request $request)
    {
        //cust_id == dist_id
       
       
         $ledger=[];
         $ledger_pre=[];
         $start_date=  $request->start_date ;
         $end_date=   $request->end_date ;
         $cust_id=    $request->user_id;
         $companyhead_user=    $request->companyhead;

        


         if($start_date!=null && $end_date!=null && $companyhead_user==null)
         {
       //dd('gg');

    //setQueryLog();
    $invoice = Ledger::where('distid',$cust_id)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',1)->sum('amount');
   
   
   $online = Ledger::where('distid',$cust_id)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',2)->sum('amount');
   $claim = Ledger::where('distid',$cust_id)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',3)->sum('amount');
   
   $ledger_pre=  ($claim +$online)-$invoice;
    //    $ledger_pre = Ledger::orderBy('recdate','ASC')->where([['distid',$cust_id]])
    //    ->whereRaw("recdate< STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d')")
    //    ->sum('amount');
       
       //dd(getQueryLog());

        $ledger = Ledger::orderBy('recdate','ASC')
        ->where([['distid',$cust_id]])
        ->whereRaw("recdate BETWEEN STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d') AND STR_TO_DATE('" . date('Y-m-d' , strtotime($end_date)) . "', '%Y-%m-%d')")
        ->get();
       
       }else if($start_date!=null && $end_date!=null && $companyhead_user!=null){
        
        $ledger = Ledger::orderBy('recdate','ASC')
        ->where([['distid',$cust_id],['baltype',$companyhead_user]])
        ->whereRaw("recdate BETWEEN STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d') AND STR_TO_DATE('" . date('Y-m-d' , strtotime($end_date)) . "', '%Y-%m-%d')")
        ->get();
        
       //setQueryLog();
        $ledger_pre = Ledger::orderBy('recdate','ASC')->where([['distid',$cust_id]])
        ->whereRaw("recdate< STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d')")
        ->sum('amount');
    // dd(getQueryLog());
       }else{
        
       }


       $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));
   
       if($end_date==null && $start_date==null){

        $end_date=date('t-m-Y');
        $start_date=date('01-m-Y');
    }

      // $ledger = Ledger::where([['distid',$dis_id]])->whereBetween('recdate', [$start_date, $end_date])->get();

  

  
  
   
     $companyhead  = Company_Head::get();
     $townName='';
     $distributerName='';
      $distributer_all = Customer::where('is_active',1)->get();
      $customer = Customer::where('is_active',1)->where('id',$cust_id)->first();
      if($customer!=null){
       $distributerName= $customer->distribution_name;
        $town=Town::where('id',$customer->city)->first();
        $townName=$town->town_name;
      }
      
      return view('report.ledger',[
        'distributer_all'=>$distributer_all,
        
        'companyhead'=>$companyhead,
        'cust_id'=>$request->user_id,
        'companyhead_user'=>$companyhead_user,
        'ledger'=>$ledger,
        'customer'=>$distributerName,
        
        'town'=>$townName,
        'ledger_pre'=>$ledger_pre,
        'prevdate'=>$prevdate,
        'start_date'=>date('d-m-Y' , strtotime($start_date)),
       'end_date'=>date('d-m-Y' , strtotime($end_date)),


    ]);
        //dd( );
    }

    public function store(Request $request)
    {
        
        


       
    }

    public function makeDefault($id)
    {
        $lims_account_data = Account::where('is_default', true)->first();
        $lims_account_data->is_default = false;
        $lims_account_data->save();

        $lims_account_data = Account::find($id);
        $lims_account_data->is_default = true;
        $lims_account_data->save();

        return 'Account set as default successfully';
    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'account_no' => [
                'max:255',
                    Rule::unique('accounts')->ignore($request->account_id)->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
        ]);

        $data = $request->all();
        $lims_account_data = Account::find($data['account_id']);
        if($data['initial_balance'])
            $data['total_balance'] = $data['initial_balance'];
        else
            $data['total_balance'] = 0;
        $lims_account_data->update($data);
        return redirect('accounts')->with('message', 'Account updated successfully');
    }

    public function balanceSheet()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('balance-sheet')){
            $lims_account_list = Account::where('is_active', true)->get();
            $debit = [];
            $credit = [];
            foreach ($lims_account_list as $account) {
                $payment_recieved = Payment::whereNotNull('sale_id')->where('account_id', $account->id)->sum('amount');
                $payment_sent = Payment::whereNotNull('purchase_id')->where('account_id', $account->id)->sum('amount');
                $returns = DB::table('returns')->where('account_id', $account->id)->sum('grand_total');
                $return_purchase = DB::table('return_purchases')->where('account_id', $account->id)->sum('grand_total');
                $expenses = DB::table('expenses')->where('account_id', $account->id)->sum('amount');
                $payrolls = DB::table('payrolls')->where('account_id', $account->id)->sum('amount');
                $sent_money_via_transfer = MoneyTransfer::where('from_account_id', $account->id)->sum('amount');
                $recieved_money_via_transfer = MoneyTransfer::where('to_account_id', $account->id)->sum('amount');

                $credit[] = $payment_recieved + $return_purchase + $recieved_money_via_transfer + $account->initial_balance;
                $debit[] = $payment_sent + $returns + $expenses + $payrolls + $sent_money_via_transfer;

                /*$credit[] = $payment_recieved + $return_purchase + $account->initial_balance;
                $debit[] = $payment_sent + $returns + $expenses + $payrolls;*/
            }
            return view('account.balance_sheet', compact('lims_account_list', 'debit', 'credit'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function accountStatement(Request $request)
    {
        $data = $request->all();
        $lims_account_data = Account::find($data['account_id']);
        $credit_list = [];
        $debit_list = [];
        $expense_list = [];
        $return_list = [];
        $purchase_return_list = [];
        $payroll_list = [];
        $recieved_money_transfer_list = [];
        $sent_money_transfer_list = [];
        
        if($data['type'] == '0' || $data['type'] == '2') {
            $credit_list = Payment::whereNotNull('sale_id')->where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $recieved_money_transfer_list = MoneyTransfer::where('to_account_id', $data['account_id'])->get();
        }
        if($data['type'] == '0' || $data['type'] == '1'){
            $debit_list = Payment::whereNotNull('purchase_id')->where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $expense_list = Expense::where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $return_list = Returns::where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $purchase_return_list = ReturnPurchase::where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $payroll_list = Payroll::where('account_id', $data['account_id'])->whereDate('created_at', '>=' , $data['start_date'])->whereDate('created_at', '<=' , $data['end_date'])->get();

            $sent_money_transfer_list = MoneyTransfer::where('from_account_id', $data['account_id'])->get();
        }
        $balance = 0;
        return view('account.account_statement', compact('lims_account_data', 'credit_list', 'debit_list', 'expense_list', 'return_list', 'purchase_return_list', 'payroll_list', 'recieved_money_transfer_list', 'sent_money_transfer_list', 'balance'));
    }

    public function destroy($id)
    {
        if(!env('USER_VERIFIED'))
            return redirect()->back()->with('not_permitted', 'This feature is disable for demo!');
        $lims_account_data = Account::find($id);
        if(!$lims_account_data->is_default){
            $lims_account_data->is_active = false;
            $lims_account_data->save();
            return redirect('accounts')->with('not_permitted', 'Account deleted successfully!');
        }
        else
            return redirect('accounts')->with('not_permitted', 'Please make another account default first!');
    }

// ledgeruserReport Report User
    public function ledgeruserReport(Request $request)
    {
        $data = $request->all();
        
        $ledger=[];
        $start_date=  $request->start_date ;
        $end_date=  $request->end_date ;
        $cust_id=    $request->user_id;
      
        if($start_date!=null && $end_date!=null )
        {
      //dd('gg');
      
       $ledger = Ledger::orderBy('id','ASC')->where([['distid',$cust_id]])->whereBetween('recdate', [date('Y-m-d' , strtotime($start_date)), date('Y-m-d' , strtotime($end_date))])->get();
      
        }else{
      
      
      }
    // if($end_date==null && $start_date==null){

    //     $end_date=date('d-m-Y');
    //     $start_date=date('01-m-Y');
    // }
     
  // dd($start_date);
     // $ledger = Ledger::where([['distid',$dis_id]])->whereBetween('recdate', [$start_date, $end_date])->get();
    // dd($start_date);
  
    

          
 
      $distributer_all = Customer::where('is_active',1)->with('town')->where('territory',Auth::user()->territory)->get();
       
       return view('report.user_ledger',[
        'distributer_all'=>$distributer_all,
        
        
        'cust_id'=>$request->user_id,
       
        'ledger'=>$ledger,
        'start_date'=>date('d-m-Y' , strtotime($start_date)),
       'end_date'=>date('d-m-Y' , strtotime($end_date)),
 
     ]);
         
    }




// fgs Report admin
    public function fgs_Report(Request $request)
    {
        $data = $request->all();
        
        $ledger=[];

        $totalData = Product::where('is_active', true)->count();
        $lims_product_all = Product::select('id', 'name', 'price','unit_id','qty', 'is_variant')
                                ->where('is_active', true)
                                ->limit($totalData)
                                ->orderBy('id', 'ASC')
                                ->get();

                               
                                   

                                
$data=[];
foreach($lims_product_all as $product){
    
    $nestedData['key']=count($data);
    $nestedData['name']=$product->name;
    $nestedData['price']=$product->price;
    $nestedData['id']=$product->id;
    $nestedData['invoice_qty_prev'] = order_detail::select('qty')->whereDate('created_at',date('Y-m-d',strtotime("-1 days")))->where('prod_id', $product->id)->sum('qty');
                  
    $nestedData['stock_qty_prev'] = add_stock::select('stock_qty')->whereDate('date',date('Y-m-d',strtotime("-1 days")))->where('prod_id', $product->id)->sum('stock_qty');

    $nestedData['invoice_qty'] = order_detail::select('qty')->whereDate('created_at',date('Y-m-d'))->where('prod_id', $product->id)->sum('qty');
                  
    $nestedData['stock_qty'] = add_stock::select('stock_qty')->whereDate('date',date('Y-m-d'))->where('prod_id', $product->id)->sum('stock_qty');
    $nestedData['unit'] = Unit::where('id', $product->unit_id)->pluck('unit_code')->toArray();
    $nestedData['stockReturn']=  StockReturn::where('product_id',$nestedData['id'])->where('return_type',1)->first();
    $data[]=  $nestedData;
}
// dd($data);





                        
        $start_date=  $request->start_date ;
        $end_date=  $request->end_date ;
      
        if($start_date!=null && $end_date!=null )
        {
      //dd('gg');
      
      $data=[];
      foreach($lims_product_all as $product){
          
          $nestedData['key']=count($data);
          $nestedData['name']=$product->name;
          $nestedData['price']=$product->price;
          $nestedData['id']=$product->id;
        //   $nestedData['invoice_qty_prev'] = order_detail::select('qty')->whereDate('created_at','>=',$start_date)->whereDate('created_at','<=',$end_date)->where('prod_id', $product->id)->sum('qty');
                        
        //   $nestedData['stock_qty_prev'] = add_stock::select('stock_qty')->whereDate('created_at','>=',$start_date)->whereDate('created_at','<=',$end_date)->where('prod_id', $product->id)->sum('stock_qty');
      
         $nestedData['invoice_qty'] = order_detail::select('qty')->whereDate('created_at','>=',$start_date)->whereDate('created_at','<=',$end_date)->where('prod_id', $product->id)->sum('qty');
                        
         $nestedData['stock_qty'] = add_stock::select('stock_qty')->whereDate('created_at','>=',$start_date)->whereDate('created_at','<=',$end_date)->where('prod_id', $product->id)->sum('stock_qty');
          $nestedData['unit'] = Unit::where('id', $product->unit_id)->pluck('unit_code')->toArray();
          $nestedData['stockReturn']=  StockReturn::where('product_id',$nestedData['id'])->where('return_type',1)->first();
          $data[]=  $nestedData;
      }
      
    // dd($data);
          
      }else{
        $data=[];
        foreach($lims_product_all as $product){
            
            $nestedData['key']=count($data);
            $nestedData['name']=$product->name;
            $nestedData['price']=$product->price;
            $nestedData['id']=$product->id;
            $nestedData['invoice_qty_prev'] = order_detail::select('qty')->whereDate('created_at','<=',date('Y-m-d',strtotime("-1 days")))->where('prod_id', $product->id)->sum('qty');
                          
            $nestedData['stock_qty_prev'] = add_stock::select('stock_qty')->whereDate('date','<=',date('Y-m-d',strtotime("-1 days")))->where('prod_id', $product->id)->sum('stock_qty');
        
            $nestedData['invoice_qty'] = order_detail::select('qty')->whereDate('created_at',date('Y-m-d'))->where('prod_id', $product->id)->sum('qty');
                          
            $nestedData['stock_qty'] = add_stock::select('stock_qty')->whereDate('date',date('Y-m-d'))->where('prod_id', $product->id)->sum('stock_qty');
            $nestedData['unit'] = Unit::where('id', $product->unit_id)->pluck('unit_code')->toArray();
            $nestedData['stockReturn']=  StockReturn::where('product_id',$nestedData['id'])->where('return_type',1)->first();

         
            $data[]=  $nestedData;
        }
      
      }
 
 

      
    
    $end_date=date('d-m-Y');
        $start_date=date('01-m-Y');
     
     // $ledger = Ledger::where([['distid',$dis_id]])->whereBetween('recdate', [$start_date, $end_date])->get();
    // dd($start_date);
  
    $companyhead  = Company_Head::get();

          
 
      $distributer_all = Customer::where('is_active',1)->with('town')->where('territory',Auth::user()->territory)->get();
       
       return view('report.fgs_report',[
        'distributer_all'=>$distributer_all,
        
        'companyhead'=>$companyhead,
        // 'cust_id'=>$request->user_id,
        // 'companyhead_user'=>$companyhead_user,
        'fgs_report'=>$data,
        'start_date'=>date('d-m-Y' , strtotime($start_date)),
       'end_date'=>date('d-m-Y' , strtotime($end_date)),
 
     ]);
         
    }

    function  get_distributor_name_ledger($id)
{
      $distributor_detail=  Customer::where('id',$id)->first();
    // dd($distributor_detail);
    return $distributor_detail->distribution_name;
}


function  print_history(Request $request) 
{


    $recent_sale=[];
   
    $start_date= date('Y-m-d', strtotime($request->start_date )) ;
    $end_date=   date('Y-m-d', strtotime($request->end_date)) ;
   
    $invoice_type=    $request->invoice_type;

 //  dd($start_date);


    if($start_date!=null && $end_date!=null && $invoice_type==null)
    {
  //dd('gg');

///setQueryLog();

$recent_sale = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date,$end_date])->with('orderdetail')->where('status',1)->get();
  


  //dd(getQueryLog());

 
  
  }else if($start_date!=null && $end_date!=null && $invoice_type!=null){
   
   
$recent_sale = Product_Sale::orderBy('id', 'desc')->whereBetween('created_at',[$start_date,$end_date])->where('account',$invoice_type)->with('orderdetail')->where('status',1)->get();
  

// dd(getQueryLog());
  }else{
   
  }


  $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));

//   if($end_date==null && $start_date==null){

//    $end_date=date('t-m-Y');
//    $start_date=date('01-m-Y');
// }





$companyhead  = Company_Head::get();
$townName='';
$distributerName='';
 $distributer_all = Customer::where('is_active',1)->get();
 
 
 return view('report.print_history',[
   'distributer_all'=>$distributer_all,
   
   'companyhead'=>$companyhead,
  
   'invoice_type'=>$invoice_type,
   
   'customer'=>$distributerName,
   'invoice'=>$recent_sale,
   
  
   'prevdate'=>$prevdate,
   'start_date'=>date('d-m-Y' , strtotime($start_date)),
  'end_date'=>date('d-m-Y' , strtotime($end_date)),


]);



}
   

public function printing_invoice(Request $request)
    {
        
        
        // if( $request->st=="true" ){
       // dd($request->invoice_from);
            $prod_sale_data = Product_Sale::where('invoice',$request->invoice_from)->first();
        // dd($prod_sale_data.length);
        
            
              $order= order_detail::with('customer')->with('productsale')->with('product')->where('prod_sale_id',$prod_sale_data->id)
              
              ->with(['product'=>function($query){
                $query->with('category');
              }])
              
              ->get();

            // dd($order );


             
              $town_name=Town::where('id',$order[0]->customer->city)->first();
               
              $order_date=$order[0]->productsale->created_at;
              $order_invoice=$order[0]->productsale->invoice;
              $cust_name= $order[0]->customer->distribution_name;
              $cust_address= $order[0]->customer->address;
              $ntn= $order[0]->customer->ntn;
              $cust_city= $town_name->town_name;
              $cust_num= $order[0]->customer->cust_num;
              $cust_state= $order[0]->customer->state;
              $cust_pakistan= $order[0]->customer->country;
              $cust_phone= $order[0]->customer->phone_number;
              $cnic= $order[0]->customer->cnic;            
              
              $regular= "S-F";
                $data=[
                    'order'=>$order,
                    'regular'=>$regular,
                    'cust_name'=>$cust_name,
                    'cust_num'=>$cust_num,
                    'ntn'=>$ntn,
                    'cnic'=>$cnic,
                    'order_invoice'=>$order_invoice,
                     'order_date'=>$order_date,
                    'cust_address'=>$cust_address,
                    'cust_city'=>$cust_city,
                    'cust_state'=>$cust_state,
                    'cust_pakistan'=>$cust_pakistan,
                    'cust_phone'=>$cust_phone,
                ];

                $pdf = PDF::loadView('sale.index1',$data);
        $pdf->setPaper('A4', 'Portriate');

        return $pdf->download("Invoce.pdf");
         
         
    
    }

    
}

<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Customer;
use App\sub_distributor_ledger;
use App\local_distr_orderdetail;
use App\local_distr_product_sales;
use App\local_distr_return_orderdetails;
use App\CustomerGroup;
use App\Warehouse;
use App\Biller;
use App\Brand;
use App\Town;
use App\Recovery;
use Carbon\Carbon;
use App\Category;
use App\Product;
use App\Unit;
use Barryvdh\DomPDF\Facade as PDF;
use App\Tax;
use App\order_detail;

use App\Sale;

use App\draftorder;

use App\draftProduct;
use App\Delivery;
use App\PosSetting;
use App\Online_cash;
use App\Product_Sale;
use App\Product_Warehouse;
use App\Payment;
use App\Account;
use App\cashReceived;
use App\Coupon;
use App\GiftCard;
use App\PaymentWithCheque;
use App\PaymentWithGiftCard;
use App\PaymentWithCreditCard;
use App\PaymentWithPaypal;
use App\User;
use App\Variant;
use App\Ledger;
use App\ProductVariant;
use App\CashRegister;
use App\Returns;
use App\Expense;
use App\ProductPurchase;
use App\ProductBatch;
use App\DeliveryName;
use App\orderBooker;
use App\sector;
// use App\Product_Warehouse;

use App\shops;
use App\CusotomerGroup;

use App\RewardPointSetting;
use App\Price_structure;
use DB;
use App\GeneralSetting;
use Stripe\Stripe;
use NumberToWords\NumberToWords;
use Auth;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Mail\UserNotification;
use Illuminate\Support\Facades\Mail;
use Srmklive\PayPal\Services\ExpressCheckout;
use Srmklive\PayPal\Services\AdaptivePayments;
use GeniusTS\HijriDate\Date;
use Illuminate\Support\Facades\Validator;

class Sale_sub_DistributorController extends Controller
{
   
    public function Sub_dis_posSale()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('local_system')){
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if(empty($all_permission))
                $all_permission[] = 'dummy text';
//dd(Auth::user()->role_id);
                if (Auth::user()->role_id==5) {
                    $lims_customer_list = Customer::where('is_active', true)->where('id',session('logged_session_data.customer_id'))->first();
                }
                else
                {
                    $lims_customer_list = Customer::where('is_active', true)->get();
                }
            
            $lims_orderBooker_all = orderBooker::where('is_active', true)->get();
            $lims_sector_all = sector::where('is_active', true)->get();
           
        //    dd($lims_sector_all);
            $lims_shops_list = shops::where('is_active', true)->get();
            $lims_DeliveryName_list = DeliveryName::where('is_active', true)->get();
            $lims_customer_group_all = CustomerGroup::where('is_active', true)->get();
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            $lims_biller_list = Biller::where('is_active', true)->get();
            $lims_reward_point_setting_data = RewardPointSetting::latest()->first();
            $lims_tax_list = Tax::where('is_active', true)->get();
            // setQueryLog();
            // $lims_product_list = Product::select('id', 'name', 'code', 'image')->ActiveFeatured()->whereNull('is_variant')->get();
            // $lims_product_list = Product::select('id', 'name', 'code','ProductWeight', 'image')->where('is_active', true)->get();
            $lims_product_list = Product::select('products.id' ,'products.price','products.qty_list', 'products.name','products.urdu_name', 'products.code','products.ProductWeight', 'products.color_code','products.image','categories.bg_color_code','categories.product_bg_color','categories.urdu_name_cat as catergoryname','categories.prefix','categories.name as catenglishname','categories.fore_color_code')
            ->join('categories', 'products.category_id', '=', 'categories.id')
            ->orderBy('products.category_id', 'ASC')
            ->where('products.is_active', true)->get();
           
    


            
           $pro=Product_Sale::with('orderdetail')->get()->last();
         

     

            
            foreach ($lims_product_list as $key => $product) {
                $images = explode(",", $product->image);
                $product->base_image = $images[0];
            }
            $lims_product_list_with_variant = Product::select('id', 'name', 'code','color_code', 'image')->ActiveFeatured()->whereNotNull('is_variant')->get();
//dd($lims_product_list_with_variant);
            foreach ($lims_product_list_with_variant as $product) {
                $images = explode(",", $product->image);
                $product->base_image = $images[0];
                $lims_product_variant_data = $product->variant()->orderBy('position')->get();
                $main_name = $product->name;
                $product->ProductWeight = $product->ProductWeight;
                $temp_arr = [];

                foreach ($lims_product_variant_data as $key => $variant) {
                    $product->name = $main_name.' ['.$variant->name.']';
                    $product->code = $variant->pivot['item_code'];
                    
                    $lims_product_list[] = clone($product);
                }
            }
           // dd($lims_product_list[0]);
            $product_number = count($lims_product_list);
            $lims_pos_setting_data = PosSetting::latest()->first();
            $lims_brand_list = Brand::where('is_active',true)->get();
            $lims_category_list = Category::where('is_active',true)->get();
          //  dd(Auth::user()->role_id);
            if(Auth::user()->role_id ==1 || config('staff_access') == 'own') {
               
               




            //     $recent_sale= order_detail::orderBy('id', 'desc')->with('productsale')->where('order_status',1)->take(10)->get();
            //  // dd($recent_sale);
               $recent_draft= Product_Sale::orderBy('id', 'desc')->with('orderdetail')->where('status',2)->take(500)->get();
                $recent_sale = Product_Sale::orderBy('id', 'desc')->with('orderdetail')->where('status',1)->take(500)->get();
                
                // $recent_sale = Sale::where([
                //     ['sale_status', 1],
                //     ['user_id', Auth::id()]
                // ])->orderBy('id', 'desc')->take(10)->get();
                // $recent_draft = Sale::where([
                //     ['sale_status', 3],
                //     ['user_id', Auth::id()]
                // ])->orderBy('id', 'desc')->take(10)->get();
            }
            else {
                $recent_sale= order_detail::orderBy('id', 'desc')->with('productsale')->where('cust_id',session('logged_session_data.customer_id'))->take(10)->get();
                $recent_draft= order_detail::orderBy('id', 'desc')->with('productsale')->where('cust_id',session('logged_session_data.customer_id'))->where('order_status',2)->take(10)->get();
             // dd( $recent_sale);
              //$recent_sale= order_detail::orderBy('id', 'desc')->with('productsale')->where('cust_id',session('logged_session_data.customer_id'))->take(10)->get();
                // $recent_sale = Sale::where('sale_status', 1)->orderBy('id', 'desc')->take(10)->get();
                // $recent_draft = Sale::where('sale_status', 3)->orderBy('id', 'desc')->take(10)->get();
            }
            $prod_sale='';
            $prod_sale_data = Product_Sale::get()->last();
            if($prod_sale_data!=null){
                $prod_sale = $prod_sale_data->id;
            }

      
           
            $lims_coupon_list = Coupon::where('is_active',true)->get();
            $flag = 0;

            return view('local_distributor.create_order.pos', compact('prod_sale','lims_customer_group_all','recent_draft','all_permission', 'lims_customer_list', 'lims_warehouse_list', 'lims_reward_point_setting_data', 'lims_product_list', 'product_number', 'lims_tax_list', 'lims_biller_list', 'lims_pos_setting_data', 'lims_brand_list', 'lims_category_list', 'recent_sale', 'lims_coupon_list','lims_sector_all', 'flag', 'lims_orderBooker_all','lims_shops_list','lims_DeliveryName_list','pro'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }


  public function  get_invoice_detail($id){

    $local_distr_product_sales = local_distr_product_sales::where('invoice_no',$id)->where('token',1)->first();

   
    $lims_orderBooker_all = orderBooker::where('is_active', true)->where('id',$local_distr_product_sales->orderbooker_id)->first();
    $lims_sector_all = sector::where('is_active', true)->where('id',$local_distr_product_sales->sector_id)->first();
   
//    dd($lims_sector_all);
    $lims_shops_list= shops::where('is_active', true)->where('id',$local_distr_product_sales->shop_id)->first();
    $lims_DeliveryName_list = DeliveryName::where('is_active', true)->where('id',$local_distr_product_sales->dm_id)->first();
 
 
 return $local_distr_product_sales;
//  'lims_orderBooker_all'=>$lims_orderBooker_all,
//  'lims_shops_list'=>$lims_shops_list,
//  'lims_sector_all'=>$lims_sector_all,
//  'lims_DeliveryName_list'=>$lims_DeliveryName_list,

 
 
    }

    public function returnpos(){
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('local_system')){
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if(empty($all_permission))
                $all_permission[] = 'dummy text';
//dd(Auth::user()->role_id);
                if (Auth::user()->role_id==5) {
                    $lims_customer_list = Customer::where('is_active', true)->where('id',session('logged_session_data.customer_id'))->first();
                }
                else
                {
                    $lims_customer_list = Customer::where('is_active', true)->get();
                }
            
            $lims_orderBooker_all = orderBooker::where('is_active', true)->get();
            $lims_sector_all = sector::where('is_active', true)->get();
           
        //    dd($lims_sector_all);
            $lims_shops_list = shops::where('is_active', true)->get();
            $lims_DeliveryName_list = DeliveryName::where('is_active', true)->get();
            $lims_customer_group_all = CustomerGroup::where('is_active', true)->get();
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            $lims_biller_list = Biller::where('is_active', true)->get();
            $lims_reward_point_setting_data = RewardPointSetting::latest()->first();
            $lims_tax_list = Tax::where('is_active', true)->get();
            // setQueryLog();
            // $lims_product_list = Product::select('id', 'name', 'code', 'image')->ActiveFeatured()->whereNull('is_variant')->get();
            // $lims_product_list = Product::select('id', 'name', 'code','ProductWeight', 'image')->where('is_active', true)->get();
            $lims_product_list = Product::select('products.id', 'products.qty_list', 'products.name','products.urdu_name', 'products.code','products.ProductWeight', 'products.color_code','products.image','categories.bg_color_code','categories.product_bg_color','categories.urdu_name_cat as catergoryname','categories.prefix','categories.fore_color_code')
            ->join('categories', 'products.category_id', '=', 'categories.id')
            ->orderBy('products.category_id', 'ASC')
            ->where('products.is_active', true)->get();
           
    


            
           $pro=Product_Sale::with('orderdetail')->get()->last();
         

     

            
            foreach ($lims_product_list as $key => $product) {
                $images = explode(",", $product->image);
                $product->base_image = $images[0];
            }
            $lims_product_list_with_variant = Product::select('id', 'name', 'code','color_code', 'image')->ActiveFeatured()->whereNotNull('is_variant')->get();
//dd($lims_product_list_with_variant);
            foreach ($lims_product_list_with_variant as $product) {
                $images = explode(",", $product->image);
                $product->base_image = $images[0];
                $lims_product_variant_data = $product->variant()->orderBy('position')->get();
                $main_name = $product->name;
                $product->ProductWeight = $product->ProductWeight;
                $temp_arr = [];

                foreach ($lims_product_variant_data as $key => $variant) {
                    $product->name = $main_name.' ['.$variant->name.']';
                    $product->code = $variant->pivot['item_code'];
                    
                    $lims_product_list[] = clone($product);
                }
            }
           // dd($lims_product_list[0]);
            $product_number = count($lims_product_list);
            $lims_pos_setting_data = PosSetting::latest()->first();
            $lims_brand_list = Brand::where('is_active',true)->get();
            $lims_category_list = Category::where('is_active',true)->get();
          //  dd(Auth::user()->role_id);
            if(Auth::user()->role_id ==1 || config('staff_access') == 'own') {
               
               




            //     $recent_sale= order_detail::orderBy('id', 'desc')->with('productsale')->where('order_status',1)->take(10)->get();
            //  // dd($recent_sale);
               $recent_draft= Product_Sale::orderBy('id', 'desc')->with('orderdetail')->where('status',2)->take(500)->get();
                $recent_sale = Product_Sale::orderBy('id', 'desc')->with('orderdetail')->where('status',1)->take(500)->get();
                
                // $recent_sale = Sale::where([
                //     ['sale_status', 1],
                //     ['user_id', Auth::id()]
                // ])->orderBy('id', 'desc')->take(10)->get();
                // $recent_draft = Sale::where([
                //     ['sale_status', 3],
                //     ['user_id', Auth::id()]
                // ])->orderBy('id', 'desc')->take(10)->get();
            }
            else {
                $recent_sale= order_detail::orderBy('id', 'desc')->with('productsale')->where('cust_id',session('logged_session_data.customer_id'))->take(10)->get();
                $recent_draft= order_detail::orderBy('id', 'desc')->with('productsale')->where('cust_id',session('logged_session_data.customer_id'))->where('order_status',2)->take(10)->get();
             // dd( $recent_sale);
              //$recent_sale= order_detail::orderBy('id', 'desc')->with('productsale')->where('cust_id',session('logged_session_data.customer_id'))->take(10)->get();
                // $recent_sale = Sale::where('sale_status', 1)->orderBy('id', 'desc')->take(10)->get();
                // $recent_draft = Sale::where('sale_status', 3)->orderBy('id', 'desc')->take(10)->get();
            }
            $prod_sale='';
            $prod_sale_data = Product_Sale::get()->last();
            if($prod_sale_data!=null){
                $prod_sale = $prod_sale_data->id;
            }

            $local_distr_product_sales = local_distr_product_sales::where('token',1)->get();
           
            $lims_coupon_list = Coupon::where('is_active',true)->get();
            $flag = 0;

            return view('local_distributor.create_order.returnpos', compact('prod_sale','local_distr_product_sales','lims_customer_group_all','recent_draft','all_permission', 'lims_customer_list', 'lims_warehouse_list', 'lims_reward_point_setting_data', 'lims_product_list', 'product_number', 'lims_tax_list', 'lims_biller_list', 'lims_pos_setting_data', 'lims_brand_list', 'lims_category_list', 'recent_sale', 'lims_coupon_list','lims_sector_all', 'flag', 'lims_orderBooker_all','lims_shops_list','lims_DeliveryName_list','pro'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }



    public function edit($id)
    {
        $lims_pos_setting_data = PosSetting::latest()->first();
        $lims_brand_list = Brand::where('is_active',true)->get();
        $lims_category_list = Category::where('is_active',true)->get();
        
        $local_distr_product_sales = local_distr_product_sales::find($id);
        $local_distr_orderdetail = local_distr_orderdetail::where('prod_sale_id', $id)->get();
        $lims_orderBooker_all = orderBooker::where('is_active', true)->get();
        $lims_sector_all = sector::where('is_active', true)->get();
       
    //    dd($lims_sector_all);
        $lims_shops_list = shops::where('is_active', true)->get();
        $lims_DeliveryName_list = DeliveryName::where('is_active', true)->get();
        $shops = shops::where('is_active', true)->get();


        $lims_warehouse_list = Warehouse::where('is_active', true)->get();
     
            $lims_biller_list = Biller::where('is_active', true)->get();
            $lims_reward_point_setting_data = RewardPointSetting::latest()->first();
            $lims_tax_list = Tax::where('is_active', true)->get();
            // setQueryLog();
            // $lims_product_list = Product::select('id', 'name', 'code', 'image')->ActiveFeatured()->whereNull('is_variant')->get();
            // $lims_product_list = Product::select('id', 'name', 'code','ProductWeight', 'image')->where('is_active', true)->get();
            $lims_product_list = Product::select('products.id', 'products.qty_list', 'products.name','products.urdu_name', 'products.code','products.ProductWeight', 'products.color_code','products.image','categories.bg_color_code','categories.product_bg_color','categories.urdu_name_cat as catergoryname','categories.prefix','categories.fore_color_code')
            ->join('categories', 'products.category_id', '=', 'categories.id')
            ->orderBy('products.category_id', 'ASC')
            ->where('products.is_active', true)->get();
            $product_number = count($lims_product_list);
        return view('local_distributor.create_order.edit1', compact('local_distr_product_sales','lims_pos_setting_data','lims_DeliveryName_list','lims_sector_all','lims_orderBooker_all', 'lims_shops_list', 'local_distr_orderdetail' ,'lims_warehouse_list', 'lims_reward_point_setting_data', 'lims_product_list', 'product_number', 'lims_tax_list', 'lims_biller_list', 'lims_pos_setting_data', 'lims_brand_list', 'lims_category_list',));
    }
    


    public function local_distribuotr_return_store(Request $request)
    {

        $data = $request->all();

 

 
        $model = new local_distr_product_sales();
     //    $model=new ();
       
     
    
        
 
 
        $sub_ledger = new sub_distributor_ledger();
 
        $sub_ledger->shop_id=$data['shop_id'];
        $sub_ledger->invoice_no=$data['invoice'];
        $sub_ledger->discribtion='Invoice';
        $sub_ledger->recdate=date('Y-m-d',strtotime($data['created_at']));
        $sub_ledger->amount=$data['grand_total'];
        $sub_ledger->type=6;
        
 
 
         $model->orderbooker_id= $data['orderbooker'];
         $model->invoice_no =$data['invoice'];
         $model->sector_id= $data['sector_id'];
         $model->shop_id= $data['shop_id'];
         $model->dist_id=     session('logged_session_data.customer_id');
         
         $model->dm_id= $data['dm_id'];
         $model->qty= $data['total_qty'];
         $model->status= 1;
         $model->token= 0;
         $model->created_at=  date('Y-m-d',strtotime($data['created_at']));
         $model->total= $data['grand_total'];
         $model->save();
 

         $lims_adjustment_data = local_distr_product_sales::where('invoice_no',$data['invoice_no'])->first();
        
        //$local_distr_orderdetail = local_distr_orderdetail::where('prod_sale_id',  $lims_adjustment_data->id)->get();
        // dd($local_distr_orderdetail);
        
  
         $prod_sale_id=$model->id;
      $shop_id=$data['shop_id'];
        $qty= $data['quantity'];
        $prod_name= $data['product_name'];
        
        $prod_code= $data['product_code'];
        $prod_id= $data['product_id'];
        $price= $data['net_unit_price'];
        $subtotal= $data['subtotal'];
        $ctunit= $data['product_batch_id'];
      
        $valueoffer= $data['offervalue'];
        $unit_price= $data['tax'];
        $ctn= $data['ctn'];
        $qty_only= $data['qty'];
        $tax_rate_unit_price= $data['tax_rate'];
        $retail_price= $data['retail_price'];
        $product_per= $data['product_per'];
        
        $invoice_price= $data['invoice_price'];
        $tp_price= $data['tp_price'];
        $distr_price= $data['distr_price'];
        $factory_price= $data['factory_price'];
 
      
 
 
 
 
       foreach($qty as $key =>$value){
           $order=[];
           $prodWh=[];
           $qty_unit;
           $vexc_tax;
           $sale_tax;
           $vinc_tax;
           $amount;
           $tval_tradeoff;
           $vex_tradoff;
           $unit_price;
 
           $lims_product_data = Price_structure::where('product_id',$prod_id[$key])->first();
           
           $lims_product = Product::where('id',$prod_id[$key])->first();
         //   $input1['qty_list'] = $lims_product->qty_list- $qty[$key] ;
         //   Product::where('id', $prod_id[$key])->update($input1);
           $category = Category::where('id',$lims_product->category_id)->first();
 
           $order['prod_sale_id']=$prod_sale_id;
           $order['prod_id']=$prod_id[$key];
 
           $order['shop_id']= $shop_id;
          
           $order['ctunit']=$ctunit[$key];
           $order['prod_name']=$prod_name[$key];
           $order['prod_code']=$prod_code[$key];
           
           $order['qty']=$qty[$key];
           $order['total_ctn']=$ctn[$key];
           $qty_unit=$qty[$key];
         
          $sale_unit=$tax_rate_unit_price[$key];
         
           $col_tax=0.17;
           $dis_factory_price=(float)$factory_price[$key];
           $distributor_price=$price[$key];
         //   ist
           $total_tradeoffer= (int)$qty_unit*$valueoffer[$key];
           $total_tprice=  (int)$qty_unit* $tp_price[$key];
 
           $totalval_wo_disc=$total_tprice-$total_tradeoffer;
           
           
           $total_discount=($totalval_wo_disc*$product_per[$key])/100;
           $total_net_value=$totalval_wo_disc-$total_discount;
           $tval_tradeoff=(int)$qty_unit*$valueoffer[$key];
           $amount =((int)$qty_unit*$dis_factory_price)-$tval_tradeoff;
           $vex_tradoff=  $amount-$total_tradeoffer;
 
 
 
           $order['vex_tradoff']=$vex_tradoff;
           $order['qty_in_unit']=$qty_only[$key];
           $order['discountvalue']=$product_per[$key];
           
           $order['amount']=$total_net_value;
           $order['tval_tradeoff']=$tval_tradeoff;
           $order['fact_price']=$dis_factory_price;
           $order['total_discount']=$total_discount;
           $order['totalval_wo_disc']=$total_tprice;
       
           $order['price']= $distributor_price;
 
           $order['invoice_price']=$invoice_price[$key];
           $order['tp_price']=$tp_price[$key];
           $order['distr_price']= $distr_price[$key];
 
           $order['valueoffer']=$valueoffer[$key];
         //   $order['tradeoffer']=$tradeoffer[$key];
           $order['subtotal']=$subtotal[$key];
           $order['retail_price']=$retail_price[$key];
           $order['tax_rate_unit_price']= $tax_rate_unit_price[$key];
           $order['order_status']=1;
           $model->created_at=  date('Y-m-d',strtotime($data['created_at']));
           //replace shoop  dist_id
         //   $prodWh['warehouse_id']=$shop_id;
         //   $prodWh['type']=3;
         //   $prodWh['qty']=$qty[$key];
         //   $prodWh['product_id']=$prod_id[$key];
         //    Product_Warehouse::insert($prodWh);


        
         local_distr_return_orderdetails::insert($order);
       }
     //   $customer=  Customer::where('id', $data['customer_id'])->first();
    
 
            $sub_ledger->save();
         // dd($data);
         $data['user_id'] = Auth::id();
     
             return redirect('sub_Pos_return');

    }



    public function local_distribuotr_store(Request $request)
    {
        
        $data = $request->all();

        

 
       $model = new local_distr_product_sales();
    //    $model=new ();
      
    
   
       
  

       $sub_ledger = new sub_distributor_ledger();

       $sub_ledger->shop_id=$data['shop'];
       $sub_ledger->invoice_no=$data['invoice'];
       $sub_ledger->discribtion='Invoice';
       

     
       $sub_ledger->recdate=  date('Y-m-d',strtotime($data['created_at']));
       $sub_ledger->amount=$data['grand_total'];
       $sub_ledger->type=4;
       


        $model->orderbooker_id= $data['orderbooker'];
        $model->invoice_no =$data['invoice'];
        $model->sector_id= $data['sector_id'];
        $model->shop_id= $data['shop'];
        $model->dist_id=     session('logged_session_data.customer_id');
        
        $model->dm_id= $data['dm_id'];
        $model->qty= $data['total_qty'];
        $model->status= 1;
        $model->token= 1;
        $model->total= $data['grand_total'];
        $model->created_at=  date('Y-m-d',strtotime($data['created_at']));
        $model->save();

       // $darte = DB::table('atten_creates')->where('user_id', $emmid)->where('date',  date("Y-m-d", strtotime($strdate)))->get();
       // order_detail::insert();
        $prod_sale_id=$model->id;
     $shop_id=$data['shop'];
       $qty= $data['quantity'];
       $prod_name= $data['product_name'];
       
       $prod_code= $data['product_code'];
       $prod_id= $data['product_id'];
       $price= $data['net_unit_price'];
       $subtotal= $data['subtotal'];
       $ctunit= $data['product_batch_id'];
     
       $valueoffer= $data['offervalue'];
       $unit_price= $data['tax'];
       $ctn= $data['ctn'];
       $qty_only= $data['qty'];
       $tax_rate_unit_price= $data['tax_rate'];
       $retail_price= $data['retail_price'];
       $product_per= $data['product_per'];
       
       $invoice_price= $data['invoice_price'];
       $tp_price= $data['tp_price'];
       $distr_price= $data['distr_price'];
       $factory_price= $data['factory_price'];

     




      foreach($qty as $key =>$value){
          $order=[];
          $prodWh=[];
          $qty_unit;
          $vexc_tax;
          $sale_tax;
          $vinc_tax;
          $amount;
          $tval_tradeoff;
          $vex_tradoff;
          $unit_price;

          $lims_product_data = Price_structure::where('product_id',$prod_id[$key])->first();
          
          $lims_product = Product::where('id',$prod_id[$key])->first();
        //   $input1['qty_list'] = $lims_product->qty_list- $qty[$key] ;
        //   Product::where('id', $prod_id[$key])->update($input1);
          $category = Category::where('id',$lims_product->category_id)->first();
//dd($lims_product->qty_list);
        //  if($lims_product->qty_list!='' && $lims_product->qty_list>$qty[$key] ){
             
        //   
        //   // dd( $lims_product_data);
        //  }
        //  else
        //  {
        //     return redirect()->back()->with('not_permitted', 'The Stock Quantity Not Suffient');
        //  }
          $order['prod_sale_id']=$prod_sale_id;
          $order['prod_id']=$prod_id[$key];

          $order['shop_id']= $shop_id;
         
          $order['ctunit']=$ctunit[$key];
          $order['prod_name']=$prod_name[$key];
          $order['prod_code']=$prod_code[$key];
          
          $order['qty']=$qty[$key];
          $order['total_ctn']=$ctn[$key];
          $qty_unit=$qty[$key];
         
        //   $ctunit[$key]*
         $sale_unit=$tax_rate_unit_price[$key];
        
          $col_tax=0.17;
          $dis_factory_price=(float)$factory_price[$key];
          $distributor_price=$price[$key];
        //   ist
          $total_tradeoffer= (int)$qty_unit*$valueoffer[$key];
          $total_tprice=  (int)$qty_unit* $tp_price[$key];

          $totalval_wo_disc=$total_tprice-$total_tradeoffer;
          
          
          $total_discount=($totalval_wo_disc*$product_per[$key])/100;
          $total_net_value=$totalval_wo_disc-$total_discount;
          $tval_tradeoff=(int)$qty_unit*$valueoffer[$key];
          $amount =((int)$qty_unit*$dis_factory_price)-$tval_tradeoff;
          $vex_tradoff=  $amount-$total_tradeoffer;



          $order['vex_tradoff']=$vex_tradoff;
          $order['qty_in_unit']=$qty_only[$key];
          $order['discountvalue']=$product_per[$key];
          
          $order['amount']=$total_net_value;
          $order['tval_tradeoff']=$tval_tradeoff;
          $order['fact_price']=$dis_factory_price;
          $order['total_discount']=$total_discount;
          $order['totalval_wo_disc']=$total_tprice;
      
          $order['price']= $distributor_price;

          $order['invoice_price']=$invoice_price[$key];
          $order['tp_price']=$tp_price[$key];
          $order['distr_price']= $distr_price[$key];

          $order['valueoffer']=$valueoffer[$key];
        //   $order['tradeoffer']=$tradeoffer[$key];
          $order['subtotal']=$subtotal[$key];
          $order['retail_price']=$retail_price[$key];
          $order['tax_rate_unit_price']= $tax_rate_unit_price[$key];
          $order['order_status']=1;
          $order['created_at']=  date('Y-m-d',strtotime($data['created_at']));
          //replace shoop  dist_id
        //   $prodWh['warehouse_id']=$shop_id;
        //   $prodWh['type']=3;
        //   $prodWh['qty']=$qty[$key];
        //   $prodWh['product_id']=$prod_id[$key];
        //    Product_Warehouse::insert($prodWh);
          local_distr_orderdetail::insert($order);
      }
    //   $customer=  Customer::where('id', $data['customer_id'])->first();
    //   if($data['cashtype']=='2')
    //   {
         

    //      $st_balanca= $customer->reqular_account;
       
    //       $data1['reqular_account'] = floatval($data['balance']-$st_balanca);
    //       Customer::where('id', $data['customer_id'])->update($data1);

    //   }
    //   elseif($data['cashtype']=='1'){
    //       $ft_balanca= $customer->reqular_account;
    //       $data1['bulk_account'] = floatval($data['balance']-$ft_balanca);
    //       Customer::where('id', $data['customer_id'])->update($data1);

    //   }

           $sub_ledger->save();
        // dd($data);
        $data['user_id'] = Auth::id();
    
            return redirect('pos');
    }


    public function print_inv(Request $request)
    {

        
       
if($request->id==1){


    $prod_sale_data = local_distr_product_sales::where('invoice_no',$request->inv_id)->first();
          
              $order= local_distr_return_orderdetails::orderBy('prod_code','ASC')->orderBy('id',"ASC")->with('shop')->with('local_distr_product_sales')->with('product')->where('prod_sale_id',$prod_sale_data->id)
              
              ->with(['product'=>function($query){
                $query->with('category');
              }])
              
              ->get();

//  dd($order);
             
             $town_name=sector::where('id',$order[0]->shop->sectors)->first();
             $lims_orderBooker=orderBooker::where('id',$order[0]->local_distr_product_sales->orderbooker_id)->first();
             $lims_DeliveryName_list=DeliveryName::where('id',$order[0]->local_distr_product_sales->dm_id)->first();
        //    dd($lims_DeliveryName_list);     
              $order_date=$order[0]->local_distr_product_sales->created_at;
              $order_invoice=$order[0]->local_distr_product_sales->invoice;
              $cust_name= $order[0]->shop->name;
              $cust_address= $order[0]->shop->address;
              $ntn= 'null';
              $cust_city= $town_name->name;
          
              $lims_orderBooker_name= $lims_orderBooker->name;
              $orphone= $lims_orderBooker->phone_number;

              $lims_DeliveryName= $lims_DeliveryName_list->name;
              $dlphone= $lims_DeliveryName_list->phone_number;
              $invoice_no= $request->inv_id;
              $customer_detail= Customer::where('id',session('logged_session_data.customer_id'))->firstOrFail();
            //   $cnic= $order[0]->customer->cnic;  
            //   $customer_group_id= $order[0]->customer->customer_group_id;  
                        
              
              $regular= "S-F";
                $data=[
                    ' $customer_detail'=> $customer_detail,
                    'order'=>$order,
                    'regular'=>$regular,
                    'cust_name'=>$cust_name,
                     'invoice_no'=>$invoice_no,
                     'lims_orderBooker_name'=>$lims_orderBooker_name,
                     'orphone'=>$orphone,
                     'lims_DeliveryName'=>$lims_DeliveryName,
                     'dlphone'=>$dlphone,
                    'ntn'=>$ntn,
                    'request_id'=>$request->id,
                    // 'customer_group_id'=>$customer_group_id,
                    // 'cnic'=>$cnic,
                    'order_invoice'=>$order_invoice,
                     'order_date'=>$order_date,
                    'cust_address'=>$cust_address,
                    'cust_city'=>$cust_city,
                    // 'cust_state'=>$cust_state,
                    // 'cust_pakistan'=>$cust_pakistan,
                    // 'cust_phone'=>$cust_phone,
                ];
                // if($customer_group_id==2  || $customer_group_id==7){
                //     return view("sale.index1",$data);
                // }
                // else{
                    return view("local_distributor.create_order.print_invoice",$data);
}else{
                 $prod_sale_data = local_distr_product_sales::where('invoice_no',$request->inv_id)->first();
          
              $order= local_distr_orderdetail::orderBy('prod_code','ASC')->orderBy('id',"ASC")->with('shop')->with('local_distr_product_sales')->with('product')->where('prod_sale_id',$prod_sale_data->id)
              
              ->with(['product'=>function($query){
                $query->with('category');
              }])
              
              ->get();

//  dd($order);
             
             $town_name=sector::where('id',$order[0]->shop->sectors)->first();
             $lims_orderBooker=orderBooker::where('id',$order[0]->local_distr_product_sales->orderbooker_id)->first();
             $lims_DeliveryName_list=DeliveryName::where('id',$order[0]->local_distr_product_sales->dm_id)->first();
        //    dd($lims_DeliveryName_list);     
              $order_date=$order[0]->local_distr_product_sales->created_at;
              $order_invoice=$order[0]->local_distr_product_sales->invoice;
              $cust_name= $order[0]->shop->name;
              $cust_address= $order[0]->shop->address;
              $ntn= 'null';
              $cust_city= $town_name->name;
          
              $lims_orderBooker_name= $lims_orderBooker->name;
              $orphone= $lims_orderBooker->phone_number;

              $lims_DeliveryName= $lims_DeliveryName_list->name;
              $dlphone= $lims_DeliveryName_list->phone_number;
              $invoice_no= $request->inv_id;
            //   $cnic= $order[0]->customer->cnic;  
            //   $customer_group_id= $order[0]->customer->customer_group_id;  
                        
            $customer_detail= Customer::where('id',session('logged_session_data.customer_id'))->firstOrFail();
              $regular= "S-F";
                $data=[
                    '$customer_detail'=>$customer_detail,
                    'order'=>$order,
                    'regular'=>$regular,
                    'cust_name'=>$cust_name,
                     'invoice_no'=>$invoice_no,
                     'lims_orderBooker_name'=>$lims_orderBooker_name,
                     'orphone'=>$orphone,
                     'lims_DeliveryName'=>$lims_DeliveryName,
                     'dlphone'=>$dlphone,
                    'ntn'=>$ntn,
                    'request_id'=>2,
                    'order_invoice'=>$order_invoice,
                     'order_date'=>$order_date,
                    'cust_address'=>$cust_address,
                    'cust_city'=>$cust_city,
                    
                ];
                // if($customer_group_id==2  || $customer_group_id==7){
                //     return view("sale.index1",$data);
                // }
                // else{
                    return view("local_distributor.create_order.print_invoice",$data);
                // }

                } 
        // }
        // elseif($request->inv=="fasle"){

        //     $prod_sale_data = local_distr_product_sales::where('invoice',$request->inv_id)->first();
        //    // 
        //       $order= local_distr_orderdetail::orderBy('id','ASC')->orderBy('id',"ASC")->with('customer')->with('product')->with('productsale')->where('prod_sale_id',$prod_sale_data->id)->get();
             
        //       $town_name=Town::where('id',$order[0]->customer->city)->first();
        //       $order_date=$order[0]->productsale->created_at;
        //       $order_invoice=$order[0]->productsale->invoice;
        //       $cust_name= $order[0]->customer->distribution_name;
        //       $cust_num= $order[0]->customer->cust_num;
        //       $cust_address= $order[0]->customer->address;
        //        $cust_city= $town_name->town_name;
        //       $ntn= $order[0]->customer->ntn;
        //       $cust_state= $order[0]->customer->state;
        //       $cust_pakistan= $order[0]->customer->country;
        //       $cust_phone= $order[0]->customer->phone_number;
        //       $cnic= $order[0]->customer->cnic;   
        //       $regular= "F-T";
        //         $data=[
        //             'order'=>$order,
        //             'regular'=>$regular,
        //             'cust_num'=>$cust_num,
        //             'cust_name'=>$cust_name,
        //             'ntn'=>$ntn,
        //             'cnic'=>$cnic,
        //             'order_invoice'=>$order_invoice,
        //              'order_date'=>$order_date,
        //             'cust_address'=>$cust_address,
        //             'cust_city'=>$cust_city,
        //             'cust_state'=>$cust_state,
        //             'cust_pakistan'=>$cust_pakistan,
        //             'cust_phone'=>$cust_phone,
        //         ];

        //        return view("sale.index1",$data); 

        // }





        

        

       
    
       
       



    }





    public function limsProductSearch_subDistributor(Request $request)
    {
        

       
        $todayDate = date('Y-m-d');
        $product_code = explode("(", $request['data']);
        
        $product_code[0] = rtrim($product_code[0], " ");
        $product_variant_id = null;
        
       $lims_customer_data = Customer::where('id',session('logged_session_data.customer_id'))->with('CustomerGroup')->first();
      // $lims_pricestruc_data=Price_structure::where('group_id',$lims_customer_data->customer_group_id)->with('Product')->get();
    //  $cust_code1= $lims_customer_data->customer_group_id;
      // $lims_customer_data->customer_group_id
    
    $lims_product_data = Product::where('code', $product_code[0])->with('category')->with(['Price_structure' => function ($q) {
        $q->where('group_id',11)->where('dist_id', session('logged_session_data.customer_id'))->where('is_active',true);
    }])->first();


   $discountval=0;
   $offerval=0;

if(isset($request->id)){
    $prod_sale_data= local_distr_product_sales::where('invoice_no',$request->id)->first();
  
    $prod_ledger_data= local_distr_orderdetail::where('prod_code',$product_code[0])->where('prod_sale_id',$prod_sale_data->id)->first();
   
    if( $prod_ledger_data!=null ){
        $discountval=$prod_ledger_data->discountvalue;
        $offerval=$prod_ledger_data->valueoffer;
    }else{
        $discountval=0;
        $offerval= $lims_product_data->Price_structure[0]->offer_value;
        
    }




   
  
}

   

    //   $bulk_account= $lims_customer_data->bulk_account;
    //   $reqular_account=$lims_customer_data->reqular_account;
    
    
 //$CustomerGroup = CustomerGroup::where('distid',$request->id)->first();
        // $lims_product_data = Product::where([
        //     ['code', $product_code[0]],
        //     ['is_active', true]
        // ])->first();
        if(!$lims_product_data) {
            $lims_product_data = Product::join('product_variants', 'products.id', 'product_variants.product_id')
                ->select('products.*', 'product_variants.id as product_variant_id', 'product_variants.item_code', 'product_variants.additional_price')
                ->where([
                    ['product_variants.item_code', $product_code[0]],
                    ['products.is_active', true]
                ])->first();
            $product_variant_id = $lims_product_data->product_variant_id;
        }

        $product[] = $lims_product_data->name;
       
        if($lims_product_data->is_variant){
            $product[] = $lims_product_data->item_code;
            $lims_product_data->price += $lims_product_data->additional_price;
        }
        else
            $product[] = $lims_product_data->code;
           // 
        if($lims_product_data->promotion && $todayDate <= $lims_product_data->last_date){
           
            $product[] = $lims_product_data->promotion_price; 
        }
        else
        
        $product[] = $lims_product_data->Price_structure[0]->retail_price;
        // $product[] = $lims_product_data->price;
        
        if($lims_product_data->tax_id) {
            $lims_tax_data = Tax::find($lims_product_data->tax_id);
            $product[] = $lims_tax_data->rate;
            $product[] = $lims_tax_data->name;
        }
        else{
            $product[] = 0;
            $product[] = 'No Tax';
        }
        $product[] = $lims_product_data->tax_method;
        if($lims_product_data->type == 'standard'){
            $units = Unit::where("base_unit", $lims_product_data->unit_id)
                    ->orWhere('id', $lims_product_data->unit_id)
                    ->get();
            $unit_name = array();
            $unit_operator = array();
            $unit_operation_value = array();
            foreach ($units as $unit) {
                if($lims_product_data->sale_unit_id == $unit->id) {
                    array_unshift($unit_name, $unit->unit_name);
                    array_unshift($unit_operator, $unit->operator);
                    array_unshift($unit_operation_value, $unit->operation_value);
                }
                else {
                    $unit_name[]  = $unit->unit_code;
                    $unit_operator[] = $unit->operator;
                    $unit_operation_value[] = $unit->operation_value;
                }
            }
            $product[] = implode(",",$unit_name);
            $product[] = implode(",",$unit_operator) . ',';
            $product[] = implode(",",$unit_operation_value) . ',';     
        }
        else{
            $product[] = 'n/a'. ',';
            $product[] = 'n/a'. ',';
            $product[] = 'n/a'. ',';
        }


        $lims_product_warehouse_data = Product::join('add_stocks', 'products.id', '=', 'add_stocks.prod_id'
        )->where([
            ['products.is_active', true],
            ['products.id', $lims_product_data->id],
            ['add_stocks.warehouse_id', 1],
            ['add_stocks.stock_qty', '>', 0]
        ])->select(DB::raw('add_stocks.*,SUM(add_stocks.stock_qty) as qty'))->groupBy('prod_id')->first();


        $product_sale=Product_Sale::join('order_details','product_sales.id','=','order_details.prod_sale_id')
        ->where([
            ['product_sales.status', 1],
            ['product_sales.warehouse', 1],
            ['product_sales.qty', '>', 0],
            ['order_details.prod_id', $lims_product_data->id],
        ])->select(DB::raw('order_details.*, SUM(order_details.qty) as solid_qty'))->groupBy('prod_id')
        ->first();
        $product[] = $lims_product_data->id;
        $product[] = $product_variant_id;
        $product[] = $lims_product_data->promotion;
        $product[] = $lims_product_data->is_batch;
        $product[] = $lims_product_data->is_imei;
       
        $product[] = $lims_product_data->UnitPerCTRN;
       // dd($lims_product_data);
       //dd($lims_product_data);
        $product[] = $lims_product_data->Price_structure[0]->buy+$lims_product_data->Price_structure[0]->get_free;
        $product[] = $lims_product_data->Price_structure[0]->offer_value;
        $product[] = $lims_product_data->Price_structure[0]->txt_sales_tax;
        $product[] = $lims_product_data->Price_structure[0]->factory_price;
     
        $product[] = $lims_product_data->qty_list;
        $product[] =$lims_product_data->category->name;
        $product[] =$lims_product_data->ProductWeight;

        $product[] = $lims_product_data->Price_structure[0]->txt_dist_price;
        $product[] = $lims_product_data->Price_structure[0]->txt_trade_price;
        $product[] = $lims_product_data->Price_structure[0]->inv_price;
        $product[] = $lims_product_data->unit_id;
        $product[]=$discountval;
        $product[]=$offerval;
        $lims_product_warehouse_data==null ? $lims_product_warehouse_data1=0 : $lims_product_warehouse_data1=$lims_product_warehouse_data->qty;
       
        $product[] = $lims_product_warehouse_data1-$product_sale->solid_qty;
        
        return $product;

    }









    public function orderbooker(Request $request){

        


     $orderbooker=   orderBooker::where('id',$request->orderbooker_id)->first();
$sector=explode(",",$orderbooker->sectors);
$sectors=sector::whereIn('id',$sector)->get();

return $sectors;
    }

    
    public function sector_id(Request $request){

        


         $sectors=sector::where('id',$request->sector_id)->first();
        
   $shops=shops::where('sectors',$sectors->id)->get();
   //dd($shops);
   return $shops;
       }


public function shop_id(Request $request){

        
// dd($request->shop_id);

$month = date('m');
$year = date('y');



$shops=local_distr_product_sales::get()->last();


if($shops!=null)
{
    $counter_val = sprintf('%05d', $shops->id+1);

    $shops1=   $month . '-' . $year . '-'.$counter_val;
}
else{
    $shops1=$month . '-' . $year . '-0000' . 1;
}
       

 
  return $shops1;
      }
     
      

  public function  sub_distr_ledger_bal(Request $request,$id){
$ledgerbal=sub_distributor_ledger::where('shop_id',$id)->first();


return $ledgerbal->amount;

      }

      public function  crieditupdate(Request $request,$id){

        $sub_ledger = new sub_distributor_ledger();
       
              $prod_sale_data= local_distr_product_sales::where('id',$id)->first();
                //   dd($prod_sale_data);
               
                     $sub_ledger->shop_id=$prod_sale_data->shop_id;
                     $sub_ledger->invoice_no= 'Cr-'.$prod_sale_data->invoice_no;
                     $sub_ledger->discribtion='Criedit';
                     $sub_ledger->amount=$prod_sale_data->total;
                     $sub_ledger->type=2;
                     $sub_ledger->save();
                     return redirect()->back()->with('massage', 'Data update Successfully');

      }
      public function  CashReceived(Request $request){

        $invoiceIdArray1 = $request['invoiceIdArray'];
        $val_type1= $request['val_type'];
   //dd($invoiceIdArray1);
       $prod_sale_data = [];


       try{
              foreach ($invoiceIdArray1 as $id) {
                  
                
            $sub_ledger = new sub_distributor_ledger();
       
              $prod_sale_data= local_distr_product_sales::where('id',$id)->first();

             
              $prod_ledger_data= sub_distributor_ledger::where('invoice_no',$prod_sale_data->invoice_no)->whereIn('type',[1,2,3,5])->first();
                 


            //   dd($prod_ledger_data);
            

               if(!isset($prod_ledger_data)){

              
                 $input['discountvalue']=0;

            $input['cash']=$prod_sale_data->total;
            $input['payment_type']=1;
            local_distr_product_sales::where('invoice_no', $prod_sale_data->invoice_no)->update($input);

                $sub_ledger->shop_id=$prod_sale_data->shop_id;
                $sub_ledger->invoice_no= $prod_sale_data->invoice_no;
                $sub_ledger->discribtion='Cash Received';
                $sub_ledger->amount=$prod_sale_data->total;
                $sub_ledger->recdate=date('Y-m-d');
                $sub_ledger->type=1;
                $sub_ledger->save();
               }
                    
             
       
                     
                
                 
                      
                   //   $order_date=$order[0]->productsale->created_at;
                   //   $order_invoice=$order[0]->productsale->invoice;
                   //   $cust_name= $order[0]->customer->distribution_name;
                   //   $cust_address= $order[0]->customer->address;
                   //   $ntn= $order[0]->customer->ntn;
                   //   $cust_city= $town_name->town_name;
                   //   $cust_num= $order[0]->customer->cust_num;
                   //   $cust_state= $order[0]->customer->state;
                   //   $cust_pakistan= $order[0]->customer->country;
                   //   $cust_phone= $order[0]->customer->phone_number;
                   //   $cnic= $order[0]->customer->cnic;            
               //  dd($prod_sale_data);
                     $regular= "S-F";
                    
                  
       
                       
                

      }
    
} catch(Exception $e)
{

    $s = $e->getMessage();
    
    $d=$s;
}

      

    
}


public function Recovery(Request $request){

$date=$request->all();
$month = date('m');
$year = date('y');
$model1=new Recovery();
$model1->dm_id=$date['dm_id'];
$model1->date=$date['date'];
$model1->shop_id=$date['inv_id'];
$model1->amount=$date['amount'];
$model1->save();
$id=$model1->id;

// dd($id);

$model= new sub_distributor_ledger();
// $model->dm_id=$date['dm_id'];
$model->invoice_no='Rec-'.$month.'-'.$year.'-'.$id;
// $model->date=$date['date'];
$model->shop_id=$date['inv_id'];
$model->amount=$date['amount'];
$model->discribtion="Recovery";
$model->type=5;
$model->save();
return redirect()->back()->with('massage', 'Data update Successfully');
}


public function cash_recevied(Request $request){


    $data=$request->all();
   
    $month = date('m');
    $year = date('y');
    $cashReceived = new cashReceived();
    
    $prod_sale_data= local_distr_product_sales::where('id',$data['id'])->first();
//    dd( $data);
     
           $cashReceived->shop_id=$prod_sale_data->shop_id;
           $cashReceived->invoice_no=$prod_sale_data->invoice_no;
          
           $cashReceived->amount=$prod_sale_data->total;
           $cashReceived->type=1;
           $cashReceived->save();
           $input['discountvalue']=$data['extra_discount'];

           $input['cash']=$data['cash_rec'];
           $input['payment_type']=1;
           local_distr_product_sales::where('id',$data['id'])->update($input);
          
           $prod_ledger_data= sub_distributor_ledger::where('invoice_no',$prod_sale_data->invoice_no)->whereIn('type',[1,2,3,5])->first();
           if(!isset($prod_ledger_data)){      
      $sub_ledger=new sub_distributor_ledger();
      if($data['credit']>0 && $data['cash_rec']==0){
        $sub_ledger->invoice_no=$prod_sale_data->invoice_no;
        // $model->date=$date['date'];
        $sub_ledger->recdate=date('Y-m-d');
        $sub_ledger->shop_id=$prod_sale_data->shop_id;
        $sub_ledger->amount=$data['credit'];
        $sub_ledger->discribtion="Credit";
        $sub_ledger->type=2;
        $sub_ledger->save();
      }else if($data['credit']>0 && $data['cash_rec']>0){
        $sub_ledger->invoice_no=$prod_sale_data->invoice_no;
        // $model->date=$date['date'];
        $sub_ledger->recdate=date('Y-m-d');
        $sub_ledger->shop_id=$prod_sale_data->shop_id;
        $sub_ledger->amount=$data['cash_rec'];
        $sub_ledger->discribtion="Partial Credit";
        $sub_ledger->type=3;
        $sub_ledger->save();
      }else{
        $sub_ledger->invoice_no=$prod_sale_data->invoice_no;
        // $model->date=$date['date'];
        $sub_ledger->recdate=date('Y-m-d');
        $sub_ledger->shop_id=$prod_sale_data->shop_id;
        $sub_ledger->amount=$data['cash_rec'];
        $sub_ledger->discribtion="Cash Received";
        $sub_ledger->type=1;
        $sub_ledger->save();
      }
    }


}



public function sub_distr_ledgerReport(Request $request)
{
    $ledger=[];
    $ledger_pre=[];
    $start_date=  $request->start_date ;
    $end_date=   $request->end_date ;
    $shop_id=    $request->shop_id;
    $shop_name='';
    $sector_name='';
    // $companyhead_user=    $request->companyhead;
    if($start_date!=null && $end_date!=null )
    {
  //dd('gg');

//setQueryLog();
$invoice = sub_distributor_ledger::where('shop_id',$shop_id)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',1)->sum('amount');


$online = sub_distributor_ledger::where('shop_id',$shop_id)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',2)->sum('amount');
$claim = sub_distributor_ledger::where('shop_id',$shop_id)->whereDate('recdate','<',date('Y-m-d' , strtotime($start_date)))->where('type',3)->sum('amount');

$ledger_pre=  ($claim +$online)-$invoice;


   $ledger = sub_distributor_ledger::orderBy('recdate','ASC')
   ->where([['shop_id',$shop_id]])
   ->whereRaw("recdate BETWEEN STR_TO_DATE('" . date('Y-m-d' , strtotime($start_date)) . "', '%Y-%m-%d') AND STR_TO_DATE('" . date('Y-m-d' , strtotime($end_date)) . "', '%Y-%m-%d')")
   ->get();
  

   $shop_name1=shops::where('id',$shop_id)->first();
$sector_name1=sector::where('id',$shop_name1->sectors)->first();
$shop_name=$shop_name1->name;
$sector_name=$sector_name1->name;
  }else{
   
  }


  $prevdate=date('d-m-Y' , strtotime($start_date .' -1 day'));

  if($end_date==null && $start_date==null){

   $end_date=date('Y-m-t');
   $start_date=date('Y-m-01');
}
$shop=shops::all();


return view('local_distributor.reports.ledger',[
    'shops'=>$shop,
    'shops_name'=>$shop_name,
    'shops_sector'=>$sector_name,
    'cust_id'=>$request->user_id,
    
    'ledger'=>$ledger,
    
    
  
    'ledger_pre'=>$ledger_pre,
    'prevdate'=>$prevdate,
    'start_date'=>$start_date,
   'end_date'=>$end_date,


]);
}


public function destroy($id)

    {
       

        $result= local_distr_product_sales::find($id);
        
       $result->delete();
         $order_detail = local_distr_orderdetail::where('prod_sale_id', $id)->get();
       //  dd($result->invoice);
         sub_distributor_ledger::where('invoice_no',$result->invoice_no)->delete();
         foreach($order_detail as $value)
        {
            $value=0;
            local_distr_orderdetail::where('prod_sale_id', $id)->delete();

        }
        return redirect()->back()->with('massage', 'Delete  Successfully');

    }

}

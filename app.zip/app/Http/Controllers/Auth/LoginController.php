<?php

  

namespace App\Http\Controllers\Auth;

  

use App\Http\Controllers\Controller;

use Illuminate\Foundation\Auth\AuthenticatesUsers;

use Illuminate\Http\Request;
use App\Customer;
use Auth;
use Hash;
use App\User;
class LoginController extends Controller

{

  

    use AuthenticatesUsers;

    

    protected $redirectTo = '/';

    /**

     * Create a new controller instance.

     *

     * @return void

     */

    public function __construct()

    {

        $this->middleware('guest')->except('logout');

    }

  

    /**

     * Create a new controller instance.

     *

     * @return void

     */

    public function login(Request $request)

    {   

        $input = $request->all();

        $this->validate($request, [

            'name' => 'required',

            'password' => 'required',

        ]);
      //  dd($request->name);
     $id= User::where('name',$request->name)->first();
    // dd($id->password);
     //  dd(Hash::check( 'admin12', $id->password));
//   if($id->name==$request->name)
//   {
//       dd('hhh');
//   }
  

//dd((['password'=>$request->password]));
        $fieldType = filter_var($request->name, FILTER_VALIDATE_EMAIL) ? 'email' : 'name';

        if(auth()->attempt(array($fieldType => $request->name, 'password' => $request->password)))

        {
            $cust_id=0;
            $cusotmer = Customer::where('user_id',Auth::user()->id)->first();
        //   dd($cusotmer );
            //$id= User::where('name',$request->name)->first();
            if($cusotmer==null){
               $cust_id= null;
            }
            else{
                $cust_id= $cusotmer->id;
            }
            $user_data = [
              
                "customer_id"       => $cust_id,
                "user_id"       => Auth::user()->id,
                "user_name"     => Auth::user()->name,
                "role_id"       => Auth::user()->role_id,
                
            ];
            
            session()->put('logged_session_data', $user_data);
            //
            //dd( $input);

            return redirect('/');

        }else{
          //  dd( $input);
            return redirect()->route('login')->with('error','Email-Address And Password Are Wrong.');
               
        }

          

    }

}
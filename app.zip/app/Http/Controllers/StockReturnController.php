<?php

namespace App\Http\Controllers;
use App\Customer;
use App\CustomerGroup;
use App\StockReturn;
use App\Product;
use Illuminate\Http\Request;

class StockReturnController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $distributer_all = Customer::where('is_active',true)->with('CustomerGroup')->get();
        $product = Product::where('is_active',true)->get();


        $stock_return=StockReturn::where('is_active',true)->get();
        return view('Stock_Return.create',[
            'stockReturn'=>$stock_return,
            'distributer_all'=>$distributer_all,
            'product'=>$product
        ]);
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data=$request->all();

        $modal= new StockReturn();


        $modal->return_type=$data['return_type'];
        $modal->dist_id=$data['dist_id'];
        $modal->qty=$data['qty'];
        $modal->price=$data['price'];
        $modal->date=$data['date'];
        $modal->product_id=$data['product_id'];
        $modal->is_active=true;
        $modal->remarks=$data['remarks'];
        $modal->save();
       

        return redirect()->back()->with('message', 'Stock Return Added Successfully');

        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\StockReturn  $stockReturn
     * @return \Illuminate\Http\Response
     */
    public function show(StockReturn $stockReturn)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\StockReturn  $stockReturn
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
      $stock_return = StockReturn::findOrFail($id);
        return $stock_return;
    }

    public function update(Request $request, StockReturn $stockReturn)
    {
        $input = $request->all();
        $StockReturn = StockReturn::find($input['id']);
        
        $StockReturn->update($input);

        return redirect()->back()->with('message', 'Stock Return Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\StockReturn  $stockReturn
     * @return \Illuminate\Http\Response
     */
    public function destroy(StockReturn $stockReturn)
    {
        //
    }


    
    public function deleteBySelection(Request $request)
    {
        $stock_id = $request['zoneIdArray'];

        
        foreach ($stock_id as $id) {
            $stock_return = StockReturn::find($id);
            $stock_return->is_active = false;
            $stock_return->save();
        }
        return 'stock deleted successfully!';
    }
}

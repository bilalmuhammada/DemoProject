<?php

namespace App\Http\Controllers;

use App\Distributor;
use App\Zone;
use App\CustomerGroup;
use App\Town;
use App\Http\Requests\StoreZoneRequest;
use App\Http\Requests\UpdateZoneRequest;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Auth;

use Illuminate\Http\Request;

class DistributorController extends Controller
{
    
   public function index()
   {
       $role = Role::find(Auth::user()->role_id);
       if($role->hasPermissionTo('unit')) {
           $distributer_all = Distributor::get();
           $town_all = Town::get();
           $custgrp_all = CustomerGroup::get();

           return view('Distributer.create', 
           ['distributer_all'=>$distributer_all,
           'town_all'=> $town_all,
           'custgrp_all'=> $custgrp_all,
           
        ]);
       }
       else
           return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
   }

   /**
    * Show the form for creating a new resource.
    *
    * @return \Illuminate\Http\Response
    */
   public function create()
   {
       //
   }

   /**
    * Store a newly created resource in storage.
    *
    * @param  \App\Http\Requests\StoreZoneRequest  $request
    * @return \Illuminate\Http\Response
    */
   public function store(Request $request)
   {
       $this->validate($request, [
           'DistributorName' => [
               'max:255',
                   Rule::unique('distributers')->where(function ($query) {
                   return $query->where('is_active', 1);
               }),
           ],
          
       ]);
       $input = $request->all();
       
       $model = new Distributor();
       $model->DistributorName =$input['dis_name'];
       $model->DistributorAddress =$input['dis_address'];
       $model->TownID =$input['town_id'];
       $model->DistributorEmail =$input['dis_email'];
       $model->DistributorPhone =$input['dis_phone'];
       $model->DistributorFax =$input['dis_fax'];
       $model->DistributorTypeID =$input['custgrp_id'];
       $model->Active =$input['is_active'];
       $model->save();
       return redirect('distributer')->with('message', 'Data inserted successfully');
   }


   public function deleteBySelection(Request $request)
   {
       $distributer_id = $request['zoneIdArray'];
       foreach ($zone_id as $id) {
           $Distributor_data = Distributor::find($id);
           $Distributor_data->is_active = false;
           $Distributor_data->save();
       }
       return 'Distributor deleted successfully!';
   }

   /**
    * Display the specified resource.
    *
    * @param  \App\Zone  $zone
    * @return \Illuminate\Http\Response
    */
   public function show(Zone $zone)
   {
       //
   }

   /**
    * Show the form for editing the specified resource.
    *
    * @param  \App\Zone  $zone
    * @return \Illuminate\Http\Response
    */
   public function edit($id)
   {
       $techxa_zone_data = Distributor::findOrFail($id);
       return $techxa_zone_data;
   }
  
   /**
    * Update the specified resource in storage.
    *
    * @param  \App\Http\Requests\UpdateZoneRequest  $request
    * @param  \App\Zone  $zone
    * @return \Illuminate\Http\Response
    */
   public function update(Request $request, $id)
   {

       $this->validate($request, [
           'DistributorName' => [
               'max:255',
               Rule::unique('zones')->ignore($request->zone_id)->where(function ($query) {
                   return $query->where('is_active', 1);
               }),
           ],
          
       ]);
       $input = $request->all();
       $distributor_data= Distributor::find($input['zone_id']);
       // setQueryLog();
       $distributor_data->update($input);
       // dd(getQueryLog());
       return redirect('distributor')->with('message', 'Data updated successfully');
   }

   /**
    * Remove the specified resource from storage.
    *
    * @param  \App\Zone  $zone
    * @return \Illuminate\Http\Response
    */
   public function destroy($id)
   {
       $distributor_data = Distributor::find($id);
       $distributor_data->is_active = false;
       $distributor_data->save();
       return redirect('distributor')->with('not_permitted', 'Data deleted successfully');
   }
}
